
# MyCab360 — V1 Build Plan

A multi-tenant SaaS CRM for French chartered accountants. One owner manages multiple firms; each firm has isolated clients, documents, members, integrations.

## Stack & setup
- React + TypeScript + TanStack Start (already scaffolded)
- Enable **Lovable Cloud** (Supabase) for auth + Postgres + Storage + RLS
- Tailwind v4 design system in `src/styles.css` (emerald/teal primary, dark navy sidebar)
- Shadcn components, lucide icons

## Design system
- Sidebar: dark navy (`oklch(~0.20 0.04 250)`) with emerald active states
- Background: off-white `oklch(0.985 0.005 250)`; cards pure white, `rounded-xl`, subtle shadow
- Primary: emerald-teal `oklch(0.65 0.14 175)`
- Typography: Inter (body) + display tracking-tight for headings
- French UI labels throughout

## Database schema (single migration)

```text
profiles (id=auth.uid, full_name, email, avatar_url)
firms (id, owner_id, name, siret, address, logo_url, primary_color, created_at)
app_role enum: owner | admin | manager | collaborator | viewer
firm_members (id, firm_id, user_id, role app_role, created_at) UNIQUE(firm_id,user_id)
companies (id, firm_id, name, siret, siren, vat_number, legal_form, address, city, postal_code, naf_code, share_capital, created_at, pappers_synced_at)
clients (id, firm_id, company_id nullable, status enum[prospect|active|inactive|archived], assigned_to, notes, created_at)
contacts (id, firm_id, client_id nullable, company_id nullable, first_name, last_name, email, phone, role_title, created_at)
document_templates (id, firm_id, name, category, file_path, background_path nullable, variables jsonb, created_at)
generated_documents (id, firm_id, template_id, client_id nullable, file_path, status, generated_by, created_at)
integrations (id, firm_id, provider enum[pappers|yousign|docusign|google_drive|sharepoint|gmail_smtp|inpi], status enum[connected|disconnected], config jsonb, connected_at)
api_keys (id, firm_id, name, key_hash, last_used_at, created_at, created_by)
audit_logs (id, firm_id, user_id, action, entity_type, entity_id, metadata jsonb, created_at)
```

- All tables RLS-enabled
- `has_firm_access(firm_id, user_id)` and `has_firm_role(firm_id, user_id, role)` SECURITY DEFINER helpers
- Policies: members can SELECT firm data; admin/owner can mutate; owners manage members
- Trigger: auto-create `profiles` row + auto-create first firm + owner membership on signup
- Storage buckets: `firm-logos` (public), `templates` (private), `generated-docs` (private)

## Routes

```text
/login, /signup, /reset-password
/_authenticated/
  dashboard           — KPIs, recent activity
  firms               — list + create/edit firms (owner)
  firms/$firmId       — firm detail / settings
  /_firm/$firmId/     — scoped layout w/ sidebar + firm switcher
    overview
    companies         — list, create, detail (mock Pappers lookup button)
    companies/$id
    clients           — list, create, detail
    clients/$id
    contacts
    prospects
    documents         — templates list, upload DOCX + background, variables editor
    documents/generated
    integrations      — 7 provider cards w/ connect modal placeholder
    settings          — firm info, branding, members & roles, API keys, audit log
```

## Components
- `AppSidebar` (collapsible, navy, lucide icons, French labels)
- `TopHeader` with `FirmSwitcher` (dropdown of firms + "Créer un cabinet")
- `KpiCard`, `DataTable` (TanStack Table light wrapper), `EmptyState`, `PageHeader`
- `IntegrationCard` (logo, status badge, connect button → placeholder dialog)
- `TemplateUploader` (DOCX + optional PNG/PDF background, variable extraction stub)

## Server functions (`src/lib/*.functions.ts`)
- `firms.functions.ts` — list/create/update firms, switch active firm
- `members.functions.ts` — invite/list/update role
- `companies.functions.ts`, `clients.functions.ts`, `contacts.functions.ts` — CRUD
- `templates.functions.ts` — upload, list, delete
- `integrations.functions.ts` — list, toggle status (no real API yet)
- All protected with `requireSupabaseAuth`, scoped via `has_firm_access`

## State
- `useActiveFirm` hook persists selected firm id in localStorage + URL param
- React Query for data fetching

## Out of scope (v1)
- Real Pappers / YouSign / DocuSign / etc. API calls — buttons open "Bientôt disponible" dialog
- Real document generation engine — upload + variable storage only
- Email invites — admins create members from existing auth users by email lookup

## Deliverables this turn
1. Enable Lovable Cloud
2. Migration with full schema + RLS + triggers + buckets
3. Design system in `styles.css`
4. Auth pages + `_authenticated` guard + `onAuthStateChange` wiring
5. Sidebar + header + firm switcher
6. All listed routes with working CRUD on companies/clients/contacts/templates/integrations
7. Settings: firm info, members, API keys, audit log viewer
8. Seed empty states with French copy

Estimated ~40 files. I'll work in batches: schema → auth → layout → modules.
