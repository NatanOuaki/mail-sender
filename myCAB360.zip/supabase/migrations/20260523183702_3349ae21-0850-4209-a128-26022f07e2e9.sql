-- Update create_firm to accept all firm fields
CREATE OR REPLACE FUNCTION public.create_firm(
  firm_name text,
  firm_siret text DEFAULT NULL,
  firm_city text DEFAULT NULL,
  firm_address text DEFAULT NULL,
  firm_postal_code text DEFAULT NULL,
  firm_phone text DEFAULT NULL,
  firm_email text DEFAULT NULL,
  firm_website text DEFAULT NULL,
  firm_siren text DEFAULT NULL,
  firm_legal_form text DEFAULT NULL,
  firm_share_capital text DEFAULT NULL,
  firm_vat_number text DEFAULT NULL,
  firm_iban text DEFAULT NULL,
  firm_bic text DEFAULT NULL,
  firm_ics text DEFAULT NULL
)
RETURNS firms
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  new_firm public.firms;
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF firm_name IS NULL OR length(trim(firm_name)) = 0 THEN
    RAISE EXCEPTION 'Firm name is required';
  END IF;

  INSERT INTO public.firms (
    name, siret, city, address, postal_code, phone, email, website,
    siren, legal_form, share_capital, vat_number, iban, bic, ics, owner_id
  ) VALUES (
    trim(firm_name),
    nullif(trim(coalesce(firm_siret,'')),''),
    nullif(trim(coalesce(firm_city,'')),''),
    nullif(trim(coalesce(firm_address,'')),''),
    nullif(trim(coalesce(firm_postal_code,'')),''),
    nullif(trim(coalesce(firm_phone,'')),''),
    nullif(trim(coalesce(firm_email,'')),''),
    nullif(trim(coalesce(firm_website,'')),''),
    nullif(trim(coalesce(firm_siren,'')),''),
    nullif(trim(coalesce(firm_legal_form,'')),''),
    nullif(trim(coalesce(firm_share_capital,'')),''),
    nullif(trim(coalesce(firm_vat_number,'')),''),
    nullif(trim(coalesce(firm_iban,'')),''),
    nullif(trim(coalesce(firm_bic,'')),''),
    nullif(trim(coalesce(firm_ics,'')),''),
    uid
  )
  RETURNING * INTO new_firm;

  INSERT INTO public.firm_members (firm_id, user_id, role)
  VALUES (new_firm.id, uid, 'owner')
  ON CONFLICT (firm_id, user_id) DO NOTHING;

  RETURN new_firm;
END;
$$;

GRANT EXECUTE ON FUNCTION public.create_firm(text,text,text,text,text,text,text,text,text,text,text,text,text,text,text) TO authenticated;

-- Delete firm only if no clients/companies attached, owner only
CREATE OR REPLACE FUNCTION public.delete_firm(firm_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  uid uuid := auth.uid();
  client_count int;
  company_count int;
  is_owner boolean;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  SELECT EXISTS(SELECT 1 FROM public.firms WHERE id = firm_id AND owner_id = uid) INTO is_owner;
  IF NOT is_owner THEN
    RAISE EXCEPTION 'Seul le propriétaire peut supprimer ce cabinet';
  END IF;

  SELECT count(*) INTO client_count FROM public.clients WHERE clients.firm_id = delete_firm.firm_id;
  SELECT count(*) INTO company_count FROM public.companies WHERE companies.firm_id = delete_firm.firm_id;

  IF client_count > 0 OR company_count > 0 THEN
    RAISE EXCEPTION 'Impossible de supprimer : ce cabinet contient des clients ou entreprises';
  END IF;

  DELETE FROM public.firm_members WHERE firm_members.firm_id = delete_firm.firm_id;
  DELETE FROM public.firms WHERE id = delete_firm.firm_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.delete_firm(uuid) TO authenticated;