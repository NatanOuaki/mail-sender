
-- Install pgcrypto in public so public.digest / public.pgp_sym_* resolve
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;

CREATE OR REPLACE FUNCTION public.set_firm_smtp_password(_firm_id uuid, _password text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  uid uuid := auth.uid();
  pwd_key text;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF NOT public.has_firm_role(_firm_id, uid, ARRAY['owner'::app_role,'admin'::app_role]) THEN
    RAISE EXCEPTION 'Forbidden: owner or admin only';
  END IF;
  pwd_key := encode(
    public.digest(convert_to('lovable-smtp-' || _firm_id::text, 'UTF8'), 'sha256'::text),
    'hex'
  );

  IF _password IS NULL OR length(_password) = 0 THEN
    UPDATE public.firm_email_settings SET smtp_password_encrypted = NULL WHERE firm_id = _firm_id;
  ELSE
    UPDATE public.firm_email_settings
       SET smtp_password_encrypted = public.pgp_sym_encrypt(_password, pwd_key)
     WHERE firm_id = _firm_id;
  END IF;
END;
$function$;

CREATE OR REPLACE FUNCTION public.get_firm_smtp_password(_firm_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  enc bytea;
  pwd_key text;
BEGIN
  SELECT smtp_password_encrypted INTO enc FROM public.firm_email_settings WHERE firm_id = _firm_id;
  IF enc IS NULL THEN RETURN NULL; END IF;
  pwd_key := encode(
    public.digest(convert_to('lovable-smtp-' || _firm_id::text, 'UTF8'), 'sha256'::text),
    'hex'
  );
  RETURN public.pgp_sym_decrypt(enc, pwd_key);
END;
$function$;
