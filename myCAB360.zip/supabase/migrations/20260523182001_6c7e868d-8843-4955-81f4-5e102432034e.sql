-- Storage: firm-scoped policies (path convention: <firm_id>/...)
DROP POLICY IF EXISTS firm_logos_authenticated_write ON storage.objects;
DROP POLICY IF EXISTS firm_logos_authenticated_update ON storage.objects;
DROP POLICY IF EXISTS firm_logos_authenticated_delete ON storage.objects;
DROP POLICY IF EXISTS firm_logos_public_read ON storage.objects;
DROP POLICY IF EXISTS templates_auth_all ON storage.objects;

-- firm-logos: public read (bucket is public), writes restricted to admin/owner of that firm
CREATE POLICY firm_logos_public_read ON storage.objects
  FOR SELECT TO public
  USING (bucket_id = 'firm-logos');

CREATE POLICY firm_logos_admin_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'firm-logos'
    AND public.has_firm_role(((storage.foldername(name))[1])::uuid, auth.uid(), ARRAY['owner','admin']::public.app_role[])
  );

CREATE POLICY firm_logos_admin_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'firm-logos'
    AND public.has_firm_role(((storage.foldername(name))[1])::uuid, auth.uid(), ARRAY['owner','admin']::public.app_role[])
  );

CREATE POLICY firm_logos_admin_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'firm-logos'
    AND public.has_firm_role(((storage.foldername(name))[1])::uuid, auth.uid(), ARRAY['owner','admin']::public.app_role[])
  );

-- templates + generated-docs: only firm members may read/write objects under their firm folder
CREATE POLICY templates_firm_select ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id IN ('templates','generated-docs')
    AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
  );

CREATE POLICY templates_firm_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id IN ('templates','generated-docs')
    AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
  );

CREATE POLICY templates_firm_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id IN ('templates','generated-docs')
    AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
  );

CREATE POLICY templates_firm_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id IN ('templates','generated-docs')
    AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
  );

-- Integrations: restrict reading config (contains credentials) to owner/admin only
DROP POLICY IF EXISTS integrations_select ON public.integrations;
CREATE POLICY integrations_select ON public.integrations
  FOR SELECT TO authenticated
  USING (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));
