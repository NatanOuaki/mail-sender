
-- Fix search_path
create or replace function public.set_updated_at()
returns trigger language plpgsql security invoker set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

-- Lock down SECURITY DEFINER helpers (only used by RLS policies)
revoke execute on function public.has_firm_access(uuid, uuid) from public, anon, authenticated;
revoke execute on function public.has_firm_role(uuid, uuid, app_role[]) from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;

-- Restrict firm-logos bucket listing: only allow direct file access via URL, not listing
drop policy if exists "firm_logos_public_read" on storage.objects;
create policy "firm_logos_public_read" on storage.objects for select
  using (bucket_id = 'firm-logos' and auth.uid() is not null);
