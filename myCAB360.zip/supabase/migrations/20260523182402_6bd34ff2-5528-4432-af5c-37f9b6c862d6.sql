CREATE OR REPLACE FUNCTION public.create_firm(
  firm_name text,
  firm_siret text DEFAULT NULL,
  firm_city text DEFAULT NULL
)
RETURNS public.firms
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_firm public.firms;
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF firm_name IS NULL OR length(trim(firm_name)) = 0 THEN
    RAISE EXCEPTION 'Firm name is required';
  END IF;

  INSERT INTO public.firms (name, siret, city, owner_id)
  VALUES (trim(firm_name), nullif(trim(coalesce(firm_siret,'')),''), nullif(trim(coalesce(firm_city,'')),''), uid)
  RETURNING * INTO new_firm;

  INSERT INTO public.firm_members (firm_id, user_id, role)
  VALUES (new_firm.id, uid, 'owner')
  ON CONFLICT (firm_id, user_id) DO NOTHING;

  RETURN new_firm;
END;
$$;

REVOKE ALL ON FUNCTION public.create_firm(text, text, text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.create_firm(text, text, text) TO authenticated;
