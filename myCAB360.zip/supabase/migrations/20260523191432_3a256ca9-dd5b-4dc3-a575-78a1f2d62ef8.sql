
ALTER TABLE public.companies
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'prospect',
  ADD COLUMN IF NOT EXISTS rep_civility text,
  ADD COLUMN IF NOT EXISTS rep_first_name text,
  ADD COLUMN IF NOT EXISTS rep_last_name text,
  ADD COLUMN IF NOT EXISTS rep_email text,
  ADD COLUMN IF NOT EXISTS rep_phone text,
  ADD COLUMN IF NOT EXISTS activity text,
  ADD COLUMN IF NOT EXISTS creation_date date,
  ADD COLUMN IF NOT EXISTS takeover_date date,
  ADD COLUMN IF NOT EXISTS first_closing_date date,
  ADD COLUMN IF NOT EXISTS tax_regime text,
  ADD COLUMN IF NOT EXISTS vat_regime text,
  ADD COLUMN IF NOT EXISTS headcount integer,
  ADD COLUMN IF NOT EXISTS takeover_colleague text,
  ADD COLUMN IF NOT EXISTS ldm_date date,
  ADD COLUMN IF NOT EXISTS sepa_mandate boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS lmnp_sci text,
  ADD COLUMN IF NOT EXISTS fees_accounting numeric,
  ADD COLUMN IF NOT EXISTS fees_periodicity text,
  ADD COLUMN IF NOT EXISTS fees_balance numeric,
  ADD COLUMN IF NOT EXISTS fees_legal numeric,
  ADD COLUMN IF NOT EXISTS fees_payroll numeric,
  ADD COLUMN IF NOT EXISTS payslips_count integer,
  ADD COLUMN IF NOT EXISTS software_provided text,
  ADD COLUMN IF NOT EXISTS fees_software numeric,
  ADD COLUMN IF NOT EXISTS observations text;

ALTER TABLE public.companies
  DROP CONSTRAINT IF EXISTS companies_status_check;
ALTER TABLE public.companies
  ADD CONSTRAINT companies_status_check
  CHECK (status IN ('prospect','client','ancien_client','lead','suspendu','archive'));

CREATE INDEX IF NOT EXISTS idx_companies_firm_id ON public.companies(firm_id);
CREATE INDEX IF NOT EXISTS idx_companies_status ON public.companies(status);
