
-- Fix 1: Restrict banking credentials (iban, bic, ics) to owner/admin only
-- Move banking fields to a dedicated table with stricter RLS

CREATE TABLE IF NOT EXISTS public.firm_banking (
  firm_id uuid PRIMARY KEY REFERENCES public.firms(id) ON DELETE CASCADE,
  iban text,
  bic text,
  ics text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);

ALTER TABLE public.firm_banking ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS firm_banking_select ON public.firm_banking;
CREATE POLICY firm_banking_select ON public.firm_banking
  FOR SELECT TO authenticated
  USING (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

DROP POLICY IF EXISTS firm_banking_insert ON public.firm_banking;
CREATE POLICY firm_banking_insert ON public.firm_banking
  FOR INSERT TO authenticated
  WITH CHECK (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

DROP POLICY IF EXISTS firm_banking_update ON public.firm_banking;
CREATE POLICY firm_banking_update ON public.firm_banking
  FOR UPDATE TO authenticated
  USING (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]))
  WITH CHECK (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

DROP POLICY IF EXISTS firm_banking_delete ON public.firm_banking;
CREATE POLICY firm_banking_delete ON public.firm_banking
  FOR DELETE TO authenticated
  USING (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

-- Migrate existing banking data from firms to firm_banking
INSERT INTO public.firm_banking (firm_id, iban, bic, ics)
SELECT id, iban, bic, ics FROM public.firms
WHERE iban IS NOT NULL OR bic IS NOT NULL OR ics IS NOT NULL
ON CONFLICT (firm_id) DO NOTHING;

-- Drop sensitive columns from firms (where they were readable by all members)
ALTER TABLE public.firms DROP COLUMN IF EXISTS iban;
ALTER TABLE public.firms DROP COLUMN IF EXISTS bic;
ALTER TABLE public.firms DROP COLUMN IF EXISTS ics;

-- Update create_firm RPC to write banking fields into firm_banking (admin/owner only path)
CREATE OR REPLACE FUNCTION public.create_firm(
  firm_name text,
  firm_siret text DEFAULT NULL::text,
  firm_city text DEFAULT NULL::text,
  firm_address text DEFAULT NULL::text,
  firm_postal_code text DEFAULT NULL::text,
  firm_phone text DEFAULT NULL::text,
  firm_email text DEFAULT NULL::text,
  firm_website text DEFAULT NULL::text,
  firm_siren text DEFAULT NULL::text,
  firm_legal_form text DEFAULT NULL::text,
  firm_share_capital text DEFAULT NULL::text,
  firm_vat_number text DEFAULT NULL::text,
  firm_iban text DEFAULT NULL::text,
  firm_bic text DEFAULT NULL::text,
  firm_ics text DEFAULT NULL::text
)
RETURNS firms
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  new_firm public.firms;
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF firm_name IS NULL OR length(trim(firm_name)) = 0 THEN
    RAISE EXCEPTION 'Firm name is required';
  END IF;

  INSERT INTO public.firms (
    name, siret, city, address, postal_code, phone, email, website,
    siren, legal_form, share_capital, vat_number, owner_id
  ) VALUES (
    trim(firm_name),
    nullif(trim(coalesce(firm_siret,'')),''),
    nullif(trim(coalesce(firm_city,'')),''),
    nullif(trim(coalesce(firm_address,'')),''),
    nullif(trim(coalesce(firm_postal_code,'')),''),
    nullif(trim(coalesce(firm_phone,'')),''),
    nullif(trim(coalesce(firm_email,'')),''),
    nullif(trim(coalesce(firm_website,'')),''),
    nullif(trim(coalesce(firm_siren,'')),''),
    nullif(trim(coalesce(firm_legal_form,'')),''),
    nullif(trim(coalesce(firm_share_capital,'')),''),
    nullif(trim(coalesce(firm_vat_number,'')),''),
    uid
  )
  RETURNING * INTO new_firm;

  INSERT INTO public.firm_members (firm_id, user_id, role)
  VALUES (new_firm.id, uid, 'owner')
  ON CONFLICT (firm_id, user_id) DO NOTHING;

  IF coalesce(firm_iban,'') <> '' OR coalesce(firm_bic,'') <> '' OR coalesce(firm_ics,'') <> '' THEN
    INSERT INTO public.firm_banking (firm_id, iban, bic, ics, updated_by)
    VALUES (
      new_firm.id,
      nullif(trim(coalesce(firm_iban,'')),''),
      nullif(trim(coalesce(firm_bic,'')),''),
      nullif(trim(coalesce(firm_ics,'')),''),
      uid
    );
  END IF;

  RETURN new_firm;
END;
$function$;

GRANT EXECUTE ON FUNCTION public.create_firm(text, text, text, text, text, text, text, text, text, text, text, text, text, text, text) TO authenticated;

-- Fix 2: Drop the public-listing policy on firm-logos storage bucket
-- The bucket remains publicly accessible via direct URLs (public=true), but
-- listing all objects (which uses RLS) is no longer allowed for anonymous users.
DROP POLICY IF EXISTS firm_logos_public_read ON storage.objects;

-- Replace with a scoped read policy: authenticated firm members can list their firm's logos.
-- Public direct-URL access continues to work via the public bucket flag.
CREATE POLICY firm_logos_member_read ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'firm-logos'
    AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
  );
