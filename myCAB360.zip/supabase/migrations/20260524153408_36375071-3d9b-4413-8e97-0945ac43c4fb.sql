
-- 1. Companies: restrict UPDATE to manager+
DROP POLICY IF EXISTS companies_update ON public.companies;
CREATE POLICY companies_update ON public.companies
  FOR UPDATE USING (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'manager'::app_role]));

-- 2. Contacts: restrict DELETE to manager+
DROP POLICY IF EXISTS contacts_delete ON public.contacts;
CREATE POLICY contacts_delete ON public.contacts
  FOR DELETE USING (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'manager'::app_role]));

-- 3. firm_integration_secrets: deny all direct access (managed via SECURITY DEFINER RPCs only)
ALTER TABLE public.firm_integration_secrets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS fis_no_select ON public.firm_integration_secrets;
DROP POLICY IF EXISTS fis_no_insert ON public.firm_integration_secrets;
DROP POLICY IF EXISTS fis_no_update ON public.firm_integration_secrets;
DROP POLICY IF EXISTS fis_no_delete ON public.firm_integration_secrets;
CREATE POLICY fis_no_select ON public.firm_integration_secrets FOR SELECT USING (false);
CREATE POLICY fis_no_insert ON public.firm_integration_secrets FOR INSERT WITH CHECK (false);
CREATE POLICY fis_no_update ON public.firm_integration_secrets FOR UPDATE USING (false) WITH CHECK (false);
CREATE POLICY fis_no_delete ON public.firm_integration_secrets FOR DELETE USING (false);

-- 4. firms: remove direct INSERT policy; creation must go through create_firm RPC
DROP POLICY IF EXISTS firms_insert_owner ON public.firms;

-- 5. profiles: allow firm members to view co-member profiles
CREATE OR REPLACE FUNCTION public.shares_firm_with(_other_user uuid, _viewer uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.firm_members fm1
    JOIN public.firm_members fm2 ON fm1.firm_id = fm2.firm_id
    WHERE fm1.user_id = _viewer AND fm2.user_id = _other_user
  );
$$;

DROP POLICY IF EXISTS profiles_select_firm_members ON public.profiles;
CREATE POLICY profiles_select_firm_members ON public.profiles
  FOR SELECT USING (auth.uid() = id OR public.shares_firm_with(id, auth.uid()));

DROP POLICY IF EXISTS profiles_select_own ON public.profiles;
