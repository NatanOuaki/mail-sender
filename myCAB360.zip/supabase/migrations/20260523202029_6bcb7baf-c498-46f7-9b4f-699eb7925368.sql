
-- Add pappers to integration_provider enum if not present
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_enum e
    JOIN pg_type t ON t.oid = e.enumtypid
    WHERE t.typname = 'integration_provider' AND e.enumlabel = 'pappers'
  ) THEN
    ALTER TYPE public.integration_provider ADD VALUE 'pappers';
  END IF;
END $$;

-- last_sync_at on integrations
ALTER TABLE public.integrations
  ADD COLUMN IF NOT EXISTS last_sync_at timestamptz;

-- Secrets table: firm-scoped API keys, NO client RLS access.
CREATE TABLE IF NOT EXISTS public.firm_integration_secrets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  firm_id uuid NOT NULL,
  provider text NOT NULL,
  api_key text NOT NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(firm_id, provider)
);

ALTER TABLE public.firm_integration_secrets ENABLE ROW LEVEL SECURITY;
-- Intentionally NO policies: only the service role (server-side) can read/write.

CREATE INDEX IF NOT EXISTS firm_integration_secrets_firm_provider_idx
  ON public.firm_integration_secrets (firm_id, provider);

-- SECURITY DEFINER: only owner/admin can set; api_key is written but never returned.
CREATE OR REPLACE FUNCTION public.set_integration_api_key(
  _firm_id uuid,
  _provider text,
  _api_key text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF NOT public.has_firm_role(_firm_id, uid, ARRAY['owner'::app_role,'admin'::app_role]) THEN
    RAISE EXCEPTION 'Forbidden: owner or admin only';
  END IF;
  IF _api_key IS NULL OR length(trim(_api_key)) = 0 THEN
    RAISE EXCEPTION 'API key required';
  END IF;

  INSERT INTO public.firm_integration_secrets (firm_id, provider, api_key, created_by)
  VALUES (_firm_id, _provider, trim(_api_key), uid)
  ON CONFLICT (firm_id, provider)
  DO UPDATE SET api_key = EXCLUDED.api_key, updated_at = now();

  INSERT INTO public.integrations (firm_id, provider, status, connected_at)
  VALUES (_firm_id, _provider::integration_provider, 'connected'::integration_status, now())
  ON CONFLICT (firm_id, provider)
  DO UPDATE SET status = 'connected'::integration_status, connected_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION public.clear_integration_api_key(
  _firm_id uuid,
  _provider text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF NOT public.has_firm_role(_firm_id, uid, ARRAY['owner'::app_role,'admin'::app_role]) THEN
    RAISE EXCEPTION 'Forbidden: owner or admin only';
  END IF;

  DELETE FROM public.firm_integration_secrets
   WHERE firm_id = _firm_id AND provider = _provider;

  UPDATE public.integrations
     SET status = 'disconnected'::integration_status, connected_at = NULL
   WHERE firm_id = _firm_id AND provider = _provider::integration_provider;
END;
$$;

-- Ensure unique constraint exists for upsert on integrations
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'integrations_firm_provider_uniq'
  ) THEN
    ALTER TABLE public.integrations
      ADD CONSTRAINT integrations_firm_provider_uniq UNIQUE (firm_id, provider);
  END IF;
END $$;

GRANT EXECUTE ON FUNCTION public.set_integration_api_key(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.clear_integration_api_key(uuid, text) TO authenticated;
