
-- Extend integration secrets storage
ALTER TABLE public.firm_integration_secrets
  ADD COLUMN IF NOT EXISTS config jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS last_test_at timestamptz,
  ALTER COLUMN api_key DROP NOT NULL;

-- ============= signature_requests =============
CREATE TABLE IF NOT EXISTS public.signature_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  firm_id uuid NOT NULL,
  company_id uuid,
  generated_document_id uuid,
  provider text NOT NULL CHECK (provider IN ('yousign','docusign')),
  mode text NOT NULL DEFAULT 'simulated' CHECK (mode IN ('simulated','live')),
  provider_request_id text,
  status text NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','sent','viewed','signed','refused','expired','cancelled')),
  signature_url text,
  subject text,
  message text,
  signing_order_mode text NOT NULL DEFAULT 'parallel' CHECK (signing_order_mode IN ('parallel','sequential')),
  sent_at timestamptz,
  viewed_at timestamptz,
  completed_at timestamptz,
  expires_at timestamptz,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS sigreq_firm_idx ON public.signature_requests(firm_id);
CREATE INDEX IF NOT EXISTS sigreq_company_idx ON public.signature_requests(company_id);
CREATE INDEX IF NOT EXISTS sigreq_doc_idx ON public.signature_requests(generated_document_id);
CREATE INDEX IF NOT EXISTS sigreq_provider_request_idx
  ON public.signature_requests(provider, provider_request_id);

ALTER TABLE public.signature_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY sigreq_select ON public.signature_requests
  FOR SELECT USING (public.has_firm_access(firm_id, auth.uid()));
CREATE POLICY sigreq_insert ON public.signature_requests
  FOR INSERT WITH CHECK (public.has_firm_access(firm_id, auth.uid()));
CREATE POLICY sigreq_update ON public.signature_requests
  FOR UPDATE USING (public.has_firm_access(firm_id, auth.uid()));
CREATE POLICY sigreq_delete ON public.signature_requests
  FOR DELETE USING (public.has_firm_role(firm_id, auth.uid(),
    ARRAY['owner'::app_role,'admin'::app_role,'manager'::app_role]));

CREATE TRIGGER sigreq_updated_at BEFORE UPDATE ON public.signature_requests
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============= signature_signers =============
CREATE TABLE IF NOT EXISTS public.signature_signers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  signature_request_id uuid NOT NULL REFERENCES public.signature_requests(id) ON DELETE CASCADE,
  firstname text NOT NULL,
  lastname text NOT NULL,
  email text NOT NULL,
  phone text,
  signing_order int NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','sent','viewed','signed','refused','expired')),
  provider_signer_id text,
  signed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS sigsign_request_idx ON public.signature_signers(signature_request_id);

ALTER TABLE public.signature_signers ENABLE ROW LEVEL SECURITY;

CREATE POLICY sigsign_select ON public.signature_signers
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.signature_requests r
    WHERE r.id = signature_signers.signature_request_id
      AND public.has_firm_access(r.firm_id, auth.uid())
  ));
CREATE POLICY sigsign_insert ON public.signature_signers
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.signature_requests r
    WHERE r.id = signature_signers.signature_request_id
      AND public.has_firm_access(r.firm_id, auth.uid())
  ));
CREATE POLICY sigsign_update ON public.signature_signers
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.signature_requests r
    WHERE r.id = signature_signers.signature_request_id
      AND public.has_firm_access(r.firm_id, auth.uid())
  ));
CREATE POLICY sigsign_delete ON public.signature_signers
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.signature_requests r
    WHERE r.id = signature_signers.signature_request_id
      AND public.has_firm_access(r.firm_id, auth.uid())
  ));

-- ============= signature_events =============
CREATE TABLE IF NOT EXISTS public.signature_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  signature_request_id uuid NOT NULL REFERENCES public.signature_requests(id) ON DELETE CASCADE,
  provider text NOT NULL CHECK (provider IN ('yousign','docusign','system')),
  event_type text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS sigev_request_idx ON public.signature_events(signature_request_id);

ALTER TABLE public.signature_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY sigev_select ON public.signature_events
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.signature_requests r
    WHERE r.id = signature_events.signature_request_id
      AND public.has_firm_access(r.firm_id, auth.uid())
  ));
CREATE POLICY sigev_insert ON public.signature_events
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.signature_requests r
    WHERE r.id = signature_events.signature_request_id
      AND public.has_firm_access(r.firm_id, auth.uid())
  ));

-- ============= Helpers =============
CREATE OR REPLACE FUNCTION public.set_integration_credentials(
  _firm_id uuid,
  _provider text,
  _api_key text,
  _config jsonb DEFAULT '{}'::jsonb
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF NOT public.has_firm_role(_firm_id, uid, ARRAY['owner'::app_role,'admin'::app_role]) THEN
    RAISE EXCEPTION 'Forbidden: owner or admin only';
  END IF;

  INSERT INTO public.firm_integration_secrets (firm_id, provider, api_key, config, created_by)
  VALUES (_firm_id, _provider, nullif(trim(coalesce(_api_key,'')),''), coalesce(_config,'{}'::jsonb), uid)
  ON CONFLICT (firm_id, provider)
  DO UPDATE SET
    api_key = EXCLUDED.api_key,
    config = EXCLUDED.config,
    updated_at = now();

  INSERT INTO public.integrations (firm_id, provider, status, connected_at)
  VALUES (_firm_id, _provider::integration_provider, 'connected'::integration_status, now())
  ON CONFLICT (firm_id, provider)
  DO UPDATE SET status = 'connected'::integration_status, connected_at = now();

  INSERT INTO public.audit_logs (firm_id, user_id, action, entity_type, metadata)
  VALUES (_firm_id, uid, 'integration.credentials_set', 'integration', jsonb_build_object('provider', _provider));
END;
$$;

CREATE OR REPLACE FUNCTION public.touch_integration_test(_firm_id uuid, _provider text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF NOT public.has_firm_access(_firm_id, uid) THEN RAISE EXCEPTION 'Forbidden'; END IF;

  UPDATE public.firm_integration_secrets
     SET last_test_at = now(), updated_at = now()
   WHERE firm_id = _firm_id AND provider = _provider;

  UPDATE public.integrations
     SET last_sync_at = now()
   WHERE firm_id = _firm_id AND provider = _provider::integration_provider;
END;
$$;
