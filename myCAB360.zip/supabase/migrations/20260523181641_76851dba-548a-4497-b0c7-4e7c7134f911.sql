-- Re-affirm SECURITY DEFINER + safe search_path on helper functions
CREATE OR REPLACE FUNCTION public.has_firm_access(_firm_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  select exists (select 1 from public.firm_members where firm_id = _firm_id and user_id = _user_id)
      or exists (select 1 from public.firms where id = _firm_id and owner_id = _user_id);
$$;

CREATE OR REPLACE FUNCTION public.has_firm_role(_firm_id uuid, _user_id uuid, _roles app_role[])
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  select exists (
    select 1 from public.firm_members
    where firm_id = _firm_id and user_id = _user_id and role = any(_roles)
  ) or exists (
    select 1 from public.firms where id = _firm_id and owner_id = _user_id
  );
$$;

-- Grant EXECUTE to authenticated role
GRANT EXECUTE ON FUNCTION public.has_firm_access(uuid, uuid) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.has_firm_role(uuid, uuid, app_role[]) TO authenticated, anon;

-- Auto-create firm_members owner row when a firm is created
CREATE OR REPLACE FUNCTION public.handle_new_firm()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.firm_members (firm_id, user_id, role)
  VALUES (NEW.id, NEW.owner_id, 'owner')
  ON CONFLICT (firm_id, user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_firm_created ON public.firms;
CREATE TRIGGER on_firm_created
  AFTER INSERT ON public.firms
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_firm();
