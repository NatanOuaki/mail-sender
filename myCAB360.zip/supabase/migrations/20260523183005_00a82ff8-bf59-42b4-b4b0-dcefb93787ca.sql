ALTER TABLE public.firms
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS siren text,
  ADD COLUMN IF NOT EXISTS legal_form text,
  ADD COLUMN IF NOT EXISTS share_capital text,
  ADD COLUMN IF NOT EXISTS vat_number text,
  ADD COLUMN IF NOT EXISTS iban text,
  ADD COLUMN IF NOT EXISTS bic text,
  ADD COLUMN IF NOT EXISTS ics text;