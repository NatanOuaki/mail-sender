-- document_templates: add columns
ALTER TABLE public.document_templates
  ADD COLUMN IF NOT EXISTS file_url text,
  ADD COLUMN IF NOT EXISTS file_type text,
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;

CREATE INDEX IF NOT EXISTS idx_document_templates_firm ON public.document_templates(firm_id);
CREATE INDEX IF NOT EXISTS idx_document_templates_category ON public.document_templates(category);

-- generated_documents: add columns
ALTER TABLE public.generated_documents
  ADD COLUMN IF NOT EXISTS company_id uuid,
  ADD COLUMN IF NOT EXISTS file_url text,
  ADD COLUMN IF NOT EXISTS file_type text,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_generated_documents_firm ON public.generated_documents(firm_id);
CREATE INDEX IF NOT EXISTS idx_generated_documents_company ON public.generated_documents(company_id);

-- updated_at trigger
DROP TRIGGER IF EXISTS trg_generated_documents_updated_at ON public.generated_documents;
CREATE TRIGGER trg_generated_documents_updated_at
  BEFORE UPDATE ON public.generated_documents
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_document_templates_updated_at ON public.document_templates;
CREATE TRIGGER trg_document_templates_updated_at
  BEFORE UPDATE ON public.document_templates
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Storage policies: templates bucket (private)
-- Path convention: {firm_id}/...
DROP POLICY IF EXISTS "templates_select_member" ON storage.objects;
CREATE POLICY "templates_select_member" ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'templates'
  AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
);

DROP POLICY IF EXISTS "templates_insert_member" ON storage.objects;
CREATE POLICY "templates_insert_member" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'templates'
  AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
);

DROP POLICY IF EXISTS "templates_update_member" ON storage.objects;
CREATE POLICY "templates_update_member" ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'templates'
  AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
);

DROP POLICY IF EXISTS "templates_delete_admin" ON storage.objects;
CREATE POLICY "templates_delete_admin" ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'templates'
  AND public.has_firm_role(((storage.foldername(name))[1])::uuid, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role])
);

-- Storage policies: generated-docs bucket (private)
-- Path convention: {firm_id}/{company_id}/...
DROP POLICY IF EXISTS "gendocs_select_member" ON storage.objects;
CREATE POLICY "gendocs_select_member" ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'generated-docs'
  AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
);

DROP POLICY IF EXISTS "gendocs_insert_member" ON storage.objects;
CREATE POLICY "gendocs_insert_member" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'generated-docs'
  AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
);

DROP POLICY IF EXISTS "gendocs_update_member" ON storage.objects;
CREATE POLICY "gendocs_update_member" ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'generated-docs'
  AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
);

DROP POLICY IF EXISTS "gendocs_delete_member" ON storage.objects;
CREATE POLICY "gendocs_delete_member" ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'generated-docs'
  AND public.has_firm_role(((storage.foldername(name))[1])::uuid, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'manager'::app_role])
);