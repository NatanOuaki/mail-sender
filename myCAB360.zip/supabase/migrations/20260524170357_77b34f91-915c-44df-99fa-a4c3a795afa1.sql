-- pgcrypto for symmetric encryption of SMTP password
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- =========================================================================
-- 1. Schema additions on signature_requests
-- =========================================================================
ALTER TABLE public.signature_requests
  ADD COLUMN IF NOT EXISTS reminder_count int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_reminder_at timestamptz,
  ADD COLUMN IF NOT EXISTS native_provider_email_enabled boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS custom_firm_email_enabled boolean NOT NULL DEFAULT true;

-- =========================================================================
-- 2. firm_email_settings
-- =========================================================================
CREATE TABLE IF NOT EXISTS public.firm_email_settings (
  firm_id uuid PRIMARY KEY REFERENCES public.firms(id) ON DELETE CASCADE,
  sender_name text,
  sender_email text,
  smtp_host text,
  smtp_port int,
  smtp_username text,
  smtp_password_encrypted bytea,
  smtp_secure boolean NOT NULL DEFAULT true,
  oauth_provider text, -- future: 'gmail' | 'microsoft'
  oauth_tokens jsonb,
  status text NOT NULL DEFAULT 'disconnected', -- 'disconnected' | 'connected' | 'error'
  last_test_at timestamptz,
  last_error text,
  native_provider_email_enabled boolean NOT NULL DEFAULT true,
  custom_firm_email_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);

ALTER TABLE public.firm_email_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "members read email settings (no password)" ON public.firm_email_settings;
CREATE POLICY "members read email settings (no password)"
  ON public.firm_email_settings FOR SELECT TO authenticated
  USING (public.has_firm_access(firm_id, auth.uid()));

DROP POLICY IF EXISTS "admins manage email settings" ON public.firm_email_settings;
CREATE POLICY "admins manage email settings"
  ON public.firm_email_settings FOR ALL TO authenticated
  USING (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]))
  WITH CHECK (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]));

CREATE TRIGGER trg_firm_email_settings_updated
  BEFORE UPDATE ON public.firm_email_settings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Encryption helpers (key derived from app secret stored as GUC; fallback hardcoded dev key)
-- We use a stable per-row key composed with firm_id to avoid global key.
CREATE OR REPLACE FUNCTION public.set_firm_smtp_password(_firm_id uuid, _password text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  pwd_key text;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF NOT public.has_firm_role(_firm_id, uid, ARRAY['owner'::app_role,'admin'::app_role]) THEN
    RAISE EXCEPTION 'Forbidden: owner or admin only';
  END IF;
  pwd_key := encode(digest('lovable-smtp-' || _firm_id::text, 'sha256'), 'hex');

  IF _password IS NULL OR length(_password) = 0 THEN
    UPDATE public.firm_email_settings SET smtp_password_encrypted = NULL WHERE firm_id = _firm_id;
  ELSE
    UPDATE public.firm_email_settings
       SET smtp_password_encrypted = pgp_sym_encrypt(_password, pwd_key)
     WHERE firm_id = _firm_id;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_firm_smtp_password(_firm_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  enc bytea;
  pwd_key text;
BEGIN
  -- Server-side only: callers must be authenticated firm members. The supabase
  -- service role bypasses auth.uid() (returns null) — that's expected for the
  -- server-side admin client which already enforces access checks before calling.
  SELECT smtp_password_encrypted INTO enc FROM public.firm_email_settings WHERE firm_id = _firm_id;
  IF enc IS NULL THEN RETURN NULL; END IF;
  pwd_key := encode(digest('lovable-smtp-' || _firm_id::text, 'sha256'), 'hex');
  RETURN pgp_sym_decrypt(enc, pwd_key);
END;
$$;

REVOKE ALL ON FUNCTION public.get_firm_smtp_password(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.set_firm_smtp_password(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_firm_smtp_password(uuid, text) TO authenticated;
-- get_firm_smtp_password remains callable only by service_role (default).

-- =========================================================================
-- 3. firm_email_templates
-- =========================================================================
CREATE TABLE IF NOT EXISTS public.firm_email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  firm_id uuid NOT NULL REFERENCES public.firms(id) ON DELETE CASCADE,
  template_key text NOT NULL,
  subject text NOT NULL,
  body_html text NOT NULL,
  body_text text,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid,
  UNIQUE (firm_id, template_key)
);

ALTER TABLE public.firm_email_templates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "members read templates" ON public.firm_email_templates;
CREATE POLICY "members read templates"
  ON public.firm_email_templates FOR SELECT TO authenticated
  USING (public.has_firm_access(firm_id, auth.uid()));

DROP POLICY IF EXISTS "admins manage templates" ON public.firm_email_templates;
CREATE POLICY "admins manage templates"
  ON public.firm_email_templates FOR ALL TO authenticated
  USING (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]))
  WITH CHECK (public.has_firm_role(firm_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]));

CREATE TRIGGER trg_firm_email_templates_updated
  BEFORE UPDATE ON public.firm_email_templates
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- =========================================================================
-- 4. email_logs
-- =========================================================================
CREATE TABLE IF NOT EXISTS public.email_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  firm_id uuid NOT NULL REFERENCES public.firms(id) ON DELETE CASCADE,
  company_id uuid REFERENCES public.companies(id) ON DELETE SET NULL,
  signature_request_id uuid REFERENCES public.signature_requests(id) ON DELETE SET NULL,
  template_key text,
  recipient_email text NOT NULL,
  subject text,
  status text NOT NULL DEFAULT 'queued',  -- queued | sent | failed | skipped
  provider_message_id text,
  error_message text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_logs_firm ON public.email_logs(firm_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_logs_company ON public.email_logs(company_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_logs_signature_request ON public.email_logs(signature_request_id);

ALTER TABLE public.email_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "members read email logs" ON public.email_logs;
CREATE POLICY "members read email logs"
  ON public.email_logs FOR SELECT TO authenticated
  USING (public.has_firm_access(firm_id, auth.uid()));

DROP POLICY IF EXISTS "members insert email logs" ON public.email_logs;
CREATE POLICY "members insert email logs"
  ON public.email_logs FOR INSERT TO authenticated
  WITH CHECK (public.has_firm_access(firm_id, auth.uid()));
-- no update / delete policies: append-only.