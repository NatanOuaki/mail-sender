
-- =========== ENUMS ===========
create type public.app_role as enum ('owner','admin','manager','collaborator','viewer');
create type public.client_status as enum ('prospect','active','inactive','archived');
create type public.integration_provider as enum ('pappers','yousign','docusign','google_drive','sharepoint','gmail_smtp','inpi');
create type public.integration_status as enum ('connected','disconnected','error');

-- =========== PROFILES ===========
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);

-- =========== FIRMS ===========
create table public.firms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  siret text,
  address text,
  city text,
  postal_code text,
  phone text,
  email text,
  logo_url text,
  primary_color text default '#10b981',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.firms enable row level security;

-- =========== FIRM MEMBERS ===========
create table public.firm_members (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null default 'collaborator',
  invited_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique(firm_id, user_id)
);
alter table public.firm_members enable row level security;

-- ===== Security definer helpers =====
create or replace function public.has_firm_access(_firm_id uuid, _user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.firm_members where firm_id = _firm_id and user_id = _user_id)
      or exists (select 1 from public.firms where id = _firm_id and owner_id = _user_id);
$$;

create or replace function public.has_firm_role(_firm_id uuid, _user_id uuid, _roles app_role[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.firm_members
    where firm_id = _firm_id and user_id = _user_id and role = any(_roles)
  ) or exists (
    select 1 from public.firms where id = _firm_id and owner_id = _user_id
  );
$$;

-- ===== Firms policies =====
create policy "firms_select_members" on public.firms for select
  using (public.has_firm_access(id, auth.uid()));
create policy "firms_insert_owner" on public.firms for insert
  with check (auth.uid() = owner_id);
create policy "firms_update_admin" on public.firms for update
  using (public.has_firm_role(id, auth.uid(), array['owner','admin']::app_role[]));
create policy "firms_delete_owner" on public.firms for delete
  using (auth.uid() = owner_id);

-- ===== Firm members policies =====
create policy "members_select_same_firm" on public.firm_members for select
  using (public.has_firm_access(firm_id, auth.uid()));
create policy "members_insert_admin" on public.firm_members for insert
  with check (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));
create policy "members_update_admin" on public.firm_members for update
  using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));
create policy "members_delete_admin" on public.firm_members for delete
  using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));

-- =========== COMPANIES ===========
create table public.companies (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  name text not null,
  siret text,
  siren text,
  vat_number text,
  legal_form text,
  address text,
  city text,
  postal_code text,
  country text default 'France',
  naf_code text,
  share_capital numeric,
  website text,
  email text,
  phone text,
  pappers_synced_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.companies enable row level security;
create policy "companies_select" on public.companies for select using (public.has_firm_access(firm_id, auth.uid()));
create policy "companies_insert" on public.companies for insert with check (public.has_firm_access(firm_id, auth.uid()));
create policy "companies_update" on public.companies for update using (public.has_firm_access(firm_id, auth.uid()));
create policy "companies_delete" on public.companies for delete using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin','manager']::app_role[]));

-- =========== CLIENTS ===========
create table public.clients (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  company_id uuid references public.companies(id) on delete set null,
  reference text,
  status client_status not null default 'prospect',
  assigned_to uuid references auth.users(id) on delete set null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.clients enable row level security;
create policy "clients_select" on public.clients for select using (public.has_firm_access(firm_id, auth.uid()));
create policy "clients_insert" on public.clients for insert with check (public.has_firm_access(firm_id, auth.uid()));
create policy "clients_update" on public.clients for update using (public.has_firm_access(firm_id, auth.uid()));
create policy "clients_delete" on public.clients for delete using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin','manager']::app_role[]));

-- =========== CONTACTS ===========
create table public.contacts (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  client_id uuid references public.clients(id) on delete set null,
  company_id uuid references public.companies(id) on delete set null,
  first_name text not null,
  last_name text not null,
  email text,
  phone text,
  role_title text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.contacts enable row level security;
create policy "contacts_select" on public.contacts for select using (public.has_firm_access(firm_id, auth.uid()));
create policy "contacts_insert" on public.contacts for insert with check (public.has_firm_access(firm_id, auth.uid()));
create policy "contacts_update" on public.contacts for update using (public.has_firm_access(firm_id, auth.uid()));
create policy "contacts_delete" on public.contacts for delete using (public.has_firm_access(firm_id, auth.uid()));

-- =========== DOCUMENT TEMPLATES ===========
create table public.document_templates (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  name text not null,
  category text,
  description text,
  file_path text,
  background_path text,
  variables jsonb not null default '[]'::jsonb,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.document_templates enable row level security;
create policy "templates_select" on public.document_templates for select using (public.has_firm_access(firm_id, auth.uid()));
create policy "templates_insert" on public.document_templates for insert with check (public.has_firm_access(firm_id, auth.uid()));
create policy "templates_update" on public.document_templates for update using (public.has_firm_access(firm_id, auth.uid()));
create policy "templates_delete" on public.document_templates for delete using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin','manager']::app_role[]));

-- =========== GENERATED DOCUMENTS ===========
create table public.generated_documents (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  template_id uuid references public.document_templates(id) on delete set null,
  client_id uuid references public.clients(id) on delete set null,
  name text not null,
  file_path text,
  status text default 'draft',
  generated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.generated_documents enable row level security;
create policy "gendocs_select" on public.generated_documents for select using (public.has_firm_access(firm_id, auth.uid()));
create policy "gendocs_insert" on public.generated_documents for insert with check (public.has_firm_access(firm_id, auth.uid()));
create policy "gendocs_update" on public.generated_documents for update using (public.has_firm_access(firm_id, auth.uid()));
create policy "gendocs_delete" on public.generated_documents for delete using (public.has_firm_access(firm_id, auth.uid()));

-- =========== INTEGRATIONS ===========
create table public.integrations (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  provider integration_provider not null,
  status integration_status not null default 'disconnected',
  config jsonb not null default '{}'::jsonb,
  connected_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(firm_id, provider)
);
alter table public.integrations enable row level security;
create policy "integrations_select" on public.integrations for select using (public.has_firm_access(firm_id, auth.uid()));
create policy "integrations_insert" on public.integrations for insert with check (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));
create policy "integrations_update" on public.integrations for update using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));
create policy "integrations_delete" on public.integrations for delete using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));

-- =========== API KEYS ===========
create table public.api_keys (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  name text not null,
  key_prefix text not null,
  key_hash text not null,
  last_used_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.api_keys enable row level security;
create policy "apikeys_select" on public.api_keys for select using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));
create policy "apikeys_insert" on public.api_keys for insert with check (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));
create policy "apikeys_delete" on public.api_keys for delete using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));

-- =========== AUDIT LOGS ===========
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references public.firms(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text,
  entity_id uuid,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.audit_logs enable row level security;
create policy "audit_select" on public.audit_logs for select using (public.has_firm_role(firm_id, auth.uid(), array['owner','admin']::app_role[]));
create policy "audit_insert" on public.audit_logs for insert with check (public.has_firm_access(firm_id, auth.uid()));

-- =========== updated_at trigger ===========
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create trigger trg_profiles_updated before update on public.profiles for each row execute function public.set_updated_at();
create trigger trg_firms_updated before update on public.firms for each row execute function public.set_updated_at();
create trigger trg_companies_updated before update on public.companies for each row execute function public.set_updated_at();
create trigger trg_clients_updated before update on public.clients for each row execute function public.set_updated_at();
create trigger trg_contacts_updated before update on public.contacts for each row execute function public.set_updated_at();
create trigger trg_templates_updated before update on public.document_templates for each row execute function public.set_updated_at();
create trigger trg_integrations_updated before update on public.integrations for each row execute function public.set_updated_at();

-- =========== Handle new user: profile + default firm + owner membership ===========
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare new_firm_id uuid;
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), new.email);

  insert into public.firms (owner_id, name)
  values (new.id, coalesce(new.raw_user_meta_data->>'firm_name', 'Mon Cabinet'))
  returning id into new_firm_id;

  insert into public.firm_members (firm_id, user_id, role)
  values (new_firm_id, new.id, 'owner');

  return new;
end; $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- =========== STORAGE BUCKETS ===========
insert into storage.buckets (id, name, public) values
  ('firm-logos', 'firm-logos', true),
  ('templates', 'templates', false),
  ('generated-docs', 'generated-docs', false)
on conflict (id) do nothing;

-- firm-logos policies (public read, member write)
create policy "firm_logos_public_read" on storage.objects for select using (bucket_id = 'firm-logos');
create policy "firm_logos_authenticated_write" on storage.objects for insert
  with check (bucket_id = 'firm-logos' and auth.uid() is not null);
create policy "firm_logos_authenticated_update" on storage.objects for update
  using (bucket_id = 'firm-logos' and auth.uid() is not null);
create policy "firm_logos_authenticated_delete" on storage.objects for delete
  using (bucket_id = 'firm-logos' and auth.uid() is not null);

-- templates / generated-docs: only authenticated; per-firm gating via app logic
create policy "templates_auth_all" on storage.objects for all
  using (bucket_id in ('templates','generated-docs') and auth.uid() is not null)
  with check (bucket_id in ('templates','generated-docs') and auth.uid() is not null);
