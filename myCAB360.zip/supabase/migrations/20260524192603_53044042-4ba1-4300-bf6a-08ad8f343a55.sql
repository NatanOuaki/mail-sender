-- Add provider abstraction columns to firm_email_settings.
ALTER TABLE public.firm_email_settings
  ADD COLUMN IF NOT EXISTS email_provider text NOT NULL DEFAULT 'smtp',
  ADD COLUMN IF NOT EXISTS provider_api_key_cipher text,
  ADD COLUMN IF NOT EXISTS provider_config jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.firm_email_settings
  DROP CONSTRAINT IF EXISTS firm_email_settings_provider_chk;
ALTER TABLE public.firm_email_settings
  ADD CONSTRAINT firm_email_settings_provider_chk
  CHECK (email_provider IN ('smtp','resend','sendgrid','mailgun','postmark'));
