
INSERT INTO storage.buckets (id, name, public)
VALUES ('signed-documents', 'signed-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Read access: firm members can read files under their firm's prefix
DROP POLICY IF EXISTS "signed_docs_select" ON storage.objects;
CREATE POLICY "signed_docs_select" ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'signed-documents'
  AND public.has_firm_access(((storage.foldername(name))[1])::uuid, auth.uid())
);

-- No client writes — writes happen via service role only
DROP POLICY IF EXISTS "signed_docs_no_insert" ON storage.objects;
DROP POLICY IF EXISTS "signed_docs_no_update" ON storage.objects;
DROP POLICY IF EXISTS "signed_docs_no_delete" ON storage.objects;

ALTER TABLE public.signature_requests
  ADD COLUMN IF NOT EXISTS signed_document_path text;
