
-- Drop SQL functions that rely on pgcrypto digest/encode; encryption now happens in app code.
DROP FUNCTION IF EXISTS public.set_firm_smtp_password(uuid, text);
DROP FUNCTION IF EXISTS public.get_firm_smtp_password(uuid);

-- New text column to hold app-side ciphertext for SMTP password.
ALTER TABLE public.firm_email_settings
  ADD COLUMN IF NOT EXISTS smtp_password_cipher text;

-- The legacy bytea column is no longer written to but we keep it to avoid data loss.
COMMENT ON COLUMN public.firm_email_settings.smtp_password_encrypted IS
  'Deprecated: legacy pgcrypto ciphertext. New code writes smtp_password_cipher instead.';
COMMENT ON COLUMN public.firm_email_settings.smtp_password_cipher IS
  'AES-256-GCM ciphertext (enc:v1:iv:tag:ct) produced by the server with APP_ENCRYPTION_KEY.';
