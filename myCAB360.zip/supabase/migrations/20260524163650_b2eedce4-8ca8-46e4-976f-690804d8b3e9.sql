ALTER TABLE public.generated_documents
  ADD COLUMN IF NOT EXISTS docx_path text,
  ADD COLUMN IF NOT EXISTS pdf_path text;

-- Backfill: existing rows used file_path for the DOCX
UPDATE public.generated_documents
   SET docx_path = file_path
 WHERE docx_path IS NULL AND file_path IS NOT NULL;

CREATE INDEX IF NOT EXISTS generated_documents_company_idx
  ON public.generated_documents (company_id, created_at DESC);
CREATE INDEX IF NOT EXISTS generated_documents_firm_idx
  ON public.generated_documents (firm_id, created_at DESC);