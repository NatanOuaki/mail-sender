import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, FileSignature, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { sendForSignature } from "@/lib/signatures.functions";

type Signer = { firstname: string; lastname: string; email: string; phone: string };

export function SendForSignatureDialog({
  open, onOpenChange, document, firmId, companyId,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  document: any;
  firmId: string;
  companyId: string;
}) {
  const qc = useQueryClient();
  const sendFn = useServerFn(sendForSignature);
  const [provider, setProvider] = useState<"yousign" | "docusign">("yousign");
  const [orderMode, setOrderMode] = useState<"parallel" | "sequential">("parallel");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [signers, setSigners] = useState<Signer[]>([]);

  // Fetch company representative for prefill
  const { data: company } = useQuery({
    queryKey: ["company-rep", companyId], enabled: open,
    queryFn: async () => {
      const { data } = await supabase.from("companies")
        .select("name, rep_first_name, rep_last_name, rep_email, rep_phone")
        .eq("id", companyId).maybeSingle();
      return data;
    },
  });

  // Fetch which providers are connected for this firm
  const { data: integrations = [] } = useQuery({
    queryKey: ["sig-integrations", firmId], enabled: open,
    queryFn: async () => {
      const { data } = await supabase.from("integrations")
        .select("provider, status")
        .eq("firm_id", firmId)
        .in("provider", ["yousign", "docusign"]);
      return data ?? [];
    },
  });

  // Fetch provider mode (sandbox/live) from the secret config
  const { data: secrets = [] } = useQuery({
    queryKey: ["sig-secrets-mode", firmId], enabled: open,
    queryFn: async () => {
      const { data } = await supabase.from("firm_integration_secrets")
        .select("provider, config")
        .eq("firm_id", firmId)
        .in("provider", ["yousign", "docusign"]);
      return data ?? [];
    },
  });

  useEffect(() => {
    if (!open) return;
    setSubject(`Signature : ${document?.name ?? ""}`);
    setMessage("");
    setOrderMode("parallel");
    if (company?.rep_email) {
      setSigners([{
        firstname: company.rep_first_name ?? "",
        lastname: company.rep_last_name ?? "",
        email: company.rep_email ?? "",
        phone: company.rep_phone ?? "",
      }]);
    } else {
      setSigners([{ firstname: "", lastname: "", email: "", phone: "" }]);
    }
  }, [open, company?.rep_email, document?.id]);

  const send = useMutation({
    mutationFn: () => sendFn({
      data: {
        documentId: document.id, provider,
        signingOrderMode: orderMode,
        subject: subject || undefined,
        message: message || undefined,
        signers: signers.map((s, i) => ({
          firstname: s.firstname, lastname: s.lastname, email: s.email,
          phone: s.phone || undefined, signing_order: i + 1,
        })),
      },
    }),
    onSuccess: (res: any) => {
      toast.success(res.mode === "live"
        ? "Demande de signature envoyée"
        : "Demande créée (mode simulé) — connectez le fournisseur pour un envoi réel");
      qc.invalidateQueries({ queryKey: ["gendocs", companyId] });
      qc.invalidateQueries({ queryKey: ["sig-requests", companyId] });
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const isConnected = (p: "yousign" | "docusign") =>
    integrations.some((i: any) => i.provider === p && i.status === "connected");

  const providerMode = (p: "yousign" | "docusign"): "production" | "sandbox" | "simulated" => {
    if (!isConnected(p)) return "simulated";
    const s = (secrets as any[]).find((x) => x.provider === p);
    const m = s?.config?.mode;
    return m === "live" || m === "production" ? "production" : "sandbox";
  };
  const currentMode = providerMode(provider);
  const modeStyle =
    currentMode === "production" ? "border-emerald-500 text-emerald-600"
    : currentMode === "sandbox" ? "border-blue-500 text-blue-600"
    : "border-amber-500 text-amber-600";
  const modeLabel =
    currentMode === "production" ? "Production"
    : currentMode === "sandbox" ? "Sandbox" : "Simulation";

  const valid = signers.length > 0 && signers.every(s =>
    s.firstname.trim() && s.lastname.trim() && /\S+@\S+\.\S+/.test(s.email));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Envoyer pour signature
            <Badge variant="outline" className={`text-[10px] ${modeStyle}`}>{modeLabel}</Badge>
          </DialogTitle>
          <DialogDescription>{document?.name}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Fournisseur</Label>
              <Select value={provider} onValueChange={v => setProvider(v as any)}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="yousign">YouSign {isConnected("yousign") ? "" : "(simulé)"}</SelectItem>
                  <SelectItem value="docusign">DocuSign {isConnected("docusign") ? "" : "(simulé)"}</SelectItem>
                </SelectContent>
              </Select>
              {currentMode === "simulated" && (
                <p className="text-[11px] text-amber-600 mt-1">
                  Fournisseur non connecté — envoi en mode simulé.
                </p>
              )}
              {currentMode === "sandbox" && (
                <p className="text-[11px] text-blue-600 mt-1">
                  Mode bac à sable — aucun envoi réel aux signataires.
                </p>
              )}
            </div>
            <div>
              <Label>Ordre de signature</Label>
              <Select value={orderMode} onValueChange={v => setOrderMode(v as any)}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="parallel">Tous en parallèle</SelectItem>
                  <SelectItem value="sequential">Un après l'autre</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Objet</Label>
            <Input value={subject} onChange={e => setSubject(e.target.value)}/>
          </div>
          <div>
            <Label>Message</Label>
            <Textarea rows={2} value={message} onChange={e => setMessage(e.target.value)}
              placeholder="Message envoyé aux signataires (optionnel)"/>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Signataires</Label>
              <Button size="sm" variant="outline" type="button"
                onClick={() => setSigners([...signers, { firstname:"", lastname:"", email:"", phone:"" }])}>
                <Plus className="size-3.5 mr-1"/>Ajouter
              </Button>
            </div>
            {signers.map((s, idx) => (
              <div key={idx} className="rounded-lg border p-2 space-y-2">
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="text-[10px]">
                    {orderMode === "sequential" ? `#${idx + 1}` : "Signataire"}
                  </Badge>
                  {signers.length > 1 && (
                    <Button size="icon" variant="ghost" type="button"
                      onClick={() => setSigners(signers.filter((_, i) => i !== idx))}>
                      <Trash2 className="size-4"/>
                    </Button>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="Prénom" value={s.firstname}
                    onChange={e => setSigners(signers.map((x,i) => i===idx ? {...x, firstname:e.target.value} : x))}/>
                  <Input placeholder="Nom" value={s.lastname}
                    onChange={e => setSigners(signers.map((x,i) => i===idx ? {...x, lastname:e.target.value} : x))}/>
                  <Input type="email" placeholder="Email" value={s.email}
                    onChange={e => setSigners(signers.map((x,i) => i===idx ? {...x, email:e.target.value} : x))}/>
                  <Input placeholder="Téléphone (optionnel)" value={s.phone}
                    onChange={e => setSigners(signers.map((x,i) => i===idx ? {...x, phone:e.target.value} : x))}/>
                </div>
              </div>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Annuler</Button>
          <Button onClick={() => send.mutate()} disabled={!valid || send.isPending}>
            {send.isPending
              ? <><Loader2 className="size-4 mr-1 animate-spin"/>Envoi…</>
              : <><FileSignature className="size-4 mr-1"/>Envoyer</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}