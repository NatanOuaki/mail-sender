import { Link, useRouterState } from "@tanstack/react-router";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter, useSidebar,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard, Building2, UserSquare, FileText, Plug, Settings,
  Building, ChevronRight, Mail, MessageCircle, Ticket, Target, Clock,
} from "lucide-react";

const main = [
  { title: "Tableau de bord", url: "/dashboard", icon: LayoutDashboard },
  { title: "Cabinets", url: "/firms", icon: Building },
];

const crm = [
  { title: "Entreprises", url: "/companies", icon: Building2 },
  { title: "Emails", url: "/emails", icon: Mail },
  { title: "Whatsapp", url: "/whatsapp", icon: MessageCircle },
  { title: "Tickets", url: "/tickets", icon: Ticket },
  { title: "Opportunités", url: "/opportunities", icon: Target },
  { title: "Temps", url: "/time", icon: Clock },
];

const tools = [
  { title: "Documents", url: "/documents", icon: FileText },
  { title: "Intégrations", url: "/integrations", icon: Plug },
  { title: "Paramètres", url: "/settings", icon: Settings },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const path = useRouterState({ select: r => r.location.pathname });
  const isActive = (u: string) => path === u || path.startsWith(u + "/");

  const renderItem = (item: typeof main[number]) => (
    <SidebarMenuItem key={item.url}>
      <SidebarMenuButton asChild isActive={isActive(item.url)}
        className="data-[active=true]:bg-sidebar-primary data-[active=true]:text-sidebar-primary-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground text-sidebar-foreground/80">
        <Link to={item.url} className="flex items-center gap-3">
          <item.icon className="size-4 shrink-0"/>
          {!collapsed && <span>{item.title}</span>}
          {!collapsed && isActive(item.url) && <ChevronRight className="ml-auto size-3 opacity-60"/>}
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );

  return (
    <Sidebar collapsible="icon" className="border-r-sidebar-border">
      <SidebarHeader className="border-b border-sidebar-border h-14 flex flex-row items-center gap-2 px-3">
        <div className="size-8 rounded-lg bg-primary grid place-items-center text-primary-foreground shrink-0">
          <UserSquare className="size-4"/>
        </div>
        {!collapsed && <span className="font-semibold tracking-tight text-sidebar-foreground">MyCab360</span>}
      </SidebarHeader>
      <SidebarContent className="bg-sidebar">
        <SidebarGroup>
          {!collapsed && <SidebarGroupLabel className="text-sidebar-foreground/50">Espace</SidebarGroupLabel>}
          <SidebarGroupContent><SidebarMenu>{main.map(renderItem)}</SidebarMenu></SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          {!collapsed && <SidebarGroupLabel className="text-sidebar-foreground/50">CRM</SidebarGroupLabel>}
          <SidebarGroupContent><SidebarMenu>{crm.map(renderItem)}</SidebarMenu></SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          {!collapsed && <SidebarGroupLabel className="text-sidebar-foreground/50">Outils</SidebarGroupLabel>}
          <SidebarGroupContent><SidebarMenu>{tools.map(renderItem)}</SidebarMenu></SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border p-3">
        {!collapsed && <p className="text-[11px] text-sidebar-foreground/50">v1.0 · MyCab360</p>}
      </SidebarFooter>
    </Sidebar>
  );
}