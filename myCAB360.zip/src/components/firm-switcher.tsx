import { Check, ChevronsUpDown, Plus, Building } from "lucide-react";
import { useActiveFirm } from "@/lib/use-active-firm";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator,
  DropdownMenuTrigger, DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Link } from "@tanstack/react-router";

export function FirmSwitcher() {
  const { firms, activeFirm, setActiveFirmId } = useActiveFirm();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="min-w-[220px] justify-between bg-card border-border h-9">
          <div className="flex items-center gap-2 truncate">
            <div className="size-6 rounded-md bg-primary/10 text-primary grid place-items-center"><Building className="size-3.5"/></div>
            <span className="truncate text-sm font-medium">{activeFirm?.name ?? "Aucun cabinet"}</span>
          </div>
          <ChevronsUpDown className="size-4 opacity-50"/>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="min-w-[260px]">
        <DropdownMenuLabel className="text-xs text-muted-foreground">Vos cabinets</DropdownMenuLabel>
        {firms.map(f => (
          <DropdownMenuItem key={f.id} onClick={() => setActiveFirmId(f.id)} className="gap-2">
            <Building className="size-4 text-muted-foreground"/>
            <span className="flex-1 truncate">{f.name}</span>
            {activeFirm?.id === f.id && <Check className="size-4 text-primary"/>}
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator/>
        <DropdownMenuItem asChild>
          <Link to="/firms" className="gap-2"><Plus className="size-4"/>Gérer / créer un cabinet</Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}