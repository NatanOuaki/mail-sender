import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Upload, Download, Trash2, Sparkles, Plus, MoreVertical, Eye, Pencil, Archive, FileSignature, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import {
  generateDocument,
  getDocumentSignedUrl,
  extractTemplateVariables,
  renameGeneratedDocument,
  setGeneratedDocumentStatus,
} from "@/lib/documents.functions";
import { SendForSignatureDialog } from "@/components/send-for-signature-dialog";

const DOC_STATUS_LABEL: Record<string, string> = {
  draft: "Brouillon", generated: "Généré", uploaded: "Importé",
  sent: "Envoyé", viewed: "Vu", signed: "Signé",
  refused: "Refusé", expired: "Expiré", cancelled: "Annulé", archived: "Archivé",
};
const DOC_STATUS_TONE: Record<string, string> = {
  generated: "bg-primary/10 text-primary",
  sent: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  viewed: "bg-amber-500/10 text-amber-700 dark:text-amber-300",
  signed: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300",
  refused: "bg-destructive/10 text-destructive",
  expired: "bg-muted text-muted-foreground",
};

export function CompanyDocumentsTab({ firmId, companyId, companyName }: { firmId: string; companyId: string; companyName: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [genOpen, setGenOpen] = useState(false);
  const [genTemplateId, setGenTemplateId] = useState<string>("");
  const [genName, setGenName] = useState("");
  const [overrides, setOverrides] = useState<Record<string, string>>({});
  const generateFn = useServerFn(generateDocument);
  const signedUrlFn = useServerFn(getDocumentSignedUrl);
  const extractFn = useServerFn(extractTemplateVariables);
  const renameFn = useServerFn(renameGeneratedDocument);
  const statusFn = useServerFn(setGeneratedDocumentStatus);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewName, setPreviewName] = useState<string>("");
  const [renameDoc, setRenameDoc] = useState<any | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [signDoc, setSignDoc] = useState<any | null>(null);

  const { data: docs = [] } = useQuery({
    queryKey: ["gendocs", companyId],
    queryFn: async () => {
      const { data, error } = await supabase.from("generated_documents").select("*").eq("company_id", companyId).order("created_at", { ascending: false });
      if (error) throw error; return data;
    },
  });

  const { data: templates = [] } = useQuery({
    queryKey: ["templates-active", firmId],
    queryFn: async () => {
      const { data, error } = await supabase.from("document_templates").select("*").eq("firm_id", firmId).eq("is_active", true).order("name");
      if (error) throw error; return data;
    },
  });

  const { data: company } = useQuery({
    queryKey: ["company-vars", companyId],
    queryFn: async () => {
      const { data, error } = await supabase.from("companies").select("*").eq("id", companyId).maybeSingle();
      if (error) throw error; return data;
    },
  });
  const { data: firm } = useQuery({
    queryKey: ["firm-vars", firmId],
    queryFn: async () => {
      const { data, error } = await supabase.from("firms").select("*").eq("id", firmId).maybeSingle();
      if (error) throw error; return data;
    },
  });

  const upload = useMutation({
    mutationFn: async (file: File) => {
      const path = `${firmId}/${companyId}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error: upErr } = await supabase.storage.from("generated-docs").upload(path, file);
      if (upErr) throw upErr;
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
      const { error } = await supabase.from("generated_documents").insert({
        firm_id: firmId, company_id: companyId, name: file.name, file_path: path, file_type: ext, status: "uploaded", generated_by: user!.id,
      });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Document ajouté"); qc.invalidateQueries({ queryKey: ["gendocs", companyId] }); if (fileRef.current) fileRef.current.value = ""; },
    onError: (e: Error) => toast.error(e.message),
  });

  const generate = useMutation({
    mutationFn: async () => {
      const tpl = templates.find((t: any) => t.id === genTemplateId);
      if (!tpl) throw new Error("Modèle introuvable");
      if (tpl.file_type !== "docx") throw new Error("Seuls les modèles DOCX peuvent être générés");
      return await generateFn({
        data: {
          templateId: tpl.id,
          companyId,
          name: genName || `${tpl.name} - ${companyName}`,
          overrides,
        },
      });
    },
    onSuccess: (res: any) => {
      const missing = res?.missingVariables?.length ?? 0;
      toast.success(missing > 0 ? `Document généré · ${missing} variable(s) manquante(s)` : "Document généré");
      qc.invalidateQueries({ queryKey: ["gendocs", companyId] });
      setGenOpen(false); setGenName(""); setGenTemplateId(""); setOverrides({});
      if (res?.pdfReady && res?.signedUrl) {
        setPreviewUrl(res.signedUrl);
        setPreviewName(res.document?.name ?? "Document");
      } else if (res?.signedUrl) {
        // PDF conversion failed — fall back to opening DOCX
        window.open(res.signedUrl, "_blank");
      }
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (d: any) => {
      // Only delete the storage file if it isn't the shared template file
      if (d.file_path && !d.template_id) await supabase.storage.from("generated-docs").remove([d.file_path]);
      const { error } = await supabase.from("generated_documents").delete().eq("id", d.id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Document supprimé"); qc.invalidateQueries({ queryKey: ["gendocs", companyId] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const downloadDoc = async (d: any, kind: "docx" | "pdf") => {
    try {
      const res = await signedUrlFn({ data: { documentId: d.id, kind } });
      if (res.signedUrl) window.open(res.signedUrl, "_blank");
      else toast.error("Lien indisponible");
    } catch (e: any) {
      toast.error(e?.message ?? "Lien indisponible");
    }
  };

  const previewPdf = async (d: any) => {
    if (!d.pdf_path) { toast.error("Pas de PDF disponible"); return; }
    try {
      const res = await signedUrlFn({ data: { documentId: d.id, kind: "pdf" } });
      if (res.signedUrl) { setPreviewUrl(res.signedUrl); setPreviewName(d.name); }
      else toast.error("Lien indisponible");
    } catch (e: any) {
      toast.error(e?.message ?? "Lien indisponible");
    }
  };

  const submitRename = async () => {
    if (!renameDoc || !renameValue.trim()) return;
    try {
      await renameFn({ data: { documentId: renameDoc.id, name: renameValue.trim() } });
      toast.success("Document renommé");
      qc.invalidateQueries({ queryKey: ["gendocs", companyId] });
      setRenameDoc(null); setRenameValue("");
    } catch (e: any) { toast.error(e?.message ?? "Erreur"); }
  };

  const updateStatus = async (d: any, status: string) => {
    try {
      await statusFn({ data: { documentId: d.id, status: status as any } });
      toast.success(
        status === "archived" ? "Document archivé" : status === "sent" ? "Document marqué envoyé pour signature" : "Statut mis à jour",
      );
      qc.invalidateQueries({ queryKey: ["gendocs", companyId] });
    } catch (e: any) { toast.error(e?.message ?? "Erreur"); }
  };

  const selectedTpl = templates.find((t: any) => t.id === genTemplateId);

  // Build a client-side preview of variable values (mirrors server logic).
  const fmtDate = (d?: string | null) => {
    if (!d) return "";
    try { return new Date(d).toLocaleDateString("fr-FR"); } catch { return ""; }
  };
  const variableMap = useMemo<Record<string, string>>(() => {
    const today = new Date();
    const c: any = company ?? {};
    const f: any = firm ?? {};
    const repFull = [c.rep_first_name, c.rep_last_name].filter(Boolean).join(" ").trim();
    const num = (v: any) => (v != null && v !== "" ? String(v) : "");
    return {
      firm_name: f.name ?? "", firm_address: f.address ?? "", firm_city: f.city ?? "",
      firm_postal_code: f.postal_code ?? "", firm_email: f.email ?? "", firm_phone: f.phone ?? "",
      firm_siret: f.siret ?? "", firm_siren: f.siren ?? "",
      vat_number: c.vat_number ?? f.vat_number ?? "",
      company_name: c.name ?? "", siren: c.siren ?? "", siret: c.siret ?? "",
      legal_form: c.legal_form ?? "", activity: c.activity ?? "",
      address: c.address ?? "", city: c.city ?? "", postal_code: c.postal_code ?? "",
      fiscal_regime: c.tax_regime ?? "", tax_regime: c.tax_regime ?? "", vat_regime: c.vat_regime ?? "",
      headcount: num(c.headcount), share_capital: num(c.share_capital), naf_code: c.naf_code ?? "",
      creation_date: fmtDate(c.creation_date),
      legal_firstname: c.rep_first_name ?? "", legal_lastname: c.rep_last_name ?? "",
      legal_email: c.rep_email ?? "", legal_phone: c.rep_phone ?? "",
      client_firstname: c.rep_first_name ?? "", client_lastname: c.rep_last_name ?? "",
      today_date: today.toLocaleDateString("fr-FR"),
      current_year: String(today.getFullYear()),
      // FR LDM aliases
      civilite: c.rep_civility ?? "", legal_representative_civility: c.rep_civility ?? "",
      representantlegal: repFull,
      raisonsociale: c.name ?? "", formejuridique: c.legal_form ?? "",
      numerorcs: c.siren ?? "", dateimmatriculation: fmtDate(c.creation_date),
      company_creation_date: fmtDate(c.creation_date),
      capital: num(c.share_capital), capital_social: num(c.share_capital),
      adresse1: c.address ?? "", codepostal: c.postal_code ?? "", ville: c.city ?? "",
      activite: c.activity ?? "", salarie: num(c.headcount),
      regimefiscal: c.tax_regime ?? "", regimeimposition: c.vat_regime ?? "",
      debutfacturation: fmtDate(c.takeover_date) || today.toLocaleDateString("fr-FR"),
      mission_start_date: fmtDate(c.takeover_date),
      datecloture: fmtDate(c.first_closing_date),
      fiscal_year_end_date: fmtDate(c.first_closing_date),
      dateLDM: fmtDate(c.ldm_date) || today.toLocaleDateString("fr-FR"),
      ldm_date: fmtDate(c.ldm_date),
      periodicite: c.fees_periodicity ?? "", billing_frequency: c.fees_periodicity ?? "",
      honorairescompta: num(c.fees_accounting), accounting_fees: num(c.fees_accounting),
      honorairesbilan: num(c.fees_balance), balance_sheet_fees: num(c.fees_balance),
      honorairesjuridique: num(c.fees_legal), legal_fees: num(c.fees_legal),
      nbBulletins: num(c.payslips_count), payslip_count: num(c.payslips_count),
      honorairesbs: num(c.fees_payroll), payslip_fees: num(c.fees_payroll),
      logicielDisposition: c.software_provided ?? "", software_provided: c.software_provided ?? "",
      honorairesLogiciel: num(c.fees_software), software_fees: num(c.fees_software),
      observations: c.observations ?? "",
    };
  }, [company, firm]);

  // Refresh template variables when opening the generation modal (re-parse DOCX).
  useEffect(() => {
    if (!genOpen || !genTemplateId) return;
    const tpl = templates.find((t: any) => t.id === genTemplateId);
    if (!tpl || tpl.file_type !== "docx") return;
    extractFn({ data: { templateId: genTemplateId } })
      .then(() => qc.invalidateQueries({ queryKey: ["templates-active", firmId] }))
      .catch(() => { /* silent */ });
    setOverrides({});
  }, [genOpen, genTemplateId]);

  const previewValues = useMemo(() => {
    if (!selectedTpl || !Array.isArray(selectedTpl.variables)) return null;
    return (selectedTpl.variables as string[]).map((v) => {
      const auto = variableMap[v] ?? "";
      const override = overrides[v];
      const value = override ?? auto;
      return { name: v, value, auto, missing: !value };
    });
  }, [selectedTpl, variableMap, overrides]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={() => setGenOpen(true)} disabled={templates.length === 0}>
          <Sparkles className="size-4 mr-1"/>Générer depuis modèle
        </Button>
        <label>
          <input ref={fileRef} type="file" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) upload.mutate(f); }}/>
          <Button size="sm" variant="outline" asChild><span><Upload className="size-4 mr-1"/>Importer un document</span></Button>
        </label>
      </div>

      {docs.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
          <FileText className="size-6 mx-auto mb-2 opacity-50"/>
          Aucun document pour cette entreprise.
        </CardContent></Card>
      ) : (
        <div className="space-y-2">
          {docs.map((d: any) => (
            <Card key={d.id} className={d.status === "archived" ? "opacity-60" : ""}><CardContent className="p-3 flex items-center gap-3">
              <div className="size-9 rounded-lg bg-primary/10 text-primary grid place-items-center"><FileText className="size-4"/></div>
              <div className="min-w-0 flex-1">
                <p className="font-medium text-sm truncate">{d.name}</p>
                <p className="text-xs text-muted-foreground">
                  {new Date(d.created_at).toLocaleDateString("fr-FR")}
                  {d.pdf_path ? " · DOCX + PDF" : d.docx_path || d.file_type === "docx" ? " · DOCX" : ` · ${(d.file_type ?? "—").toUpperCase()}`}
                </p>
              </div>
              <Badge className={`hidden sm:inline-flex ${DOC_STATUS_TONE[d.status] ?? ""}`}>
                {DOC_STATUS_LABEL[d.status] ?? d.status}
              </Badge>
              {d.pdf_path && (
                <Button size="icon" variant="ghost" onClick={() => previewPdf(d)} title="Aperçu PDF"><Eye className="size-4"/></Button>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon" variant="ghost"><MoreVertical className="size-4"/></Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-52">
                  {d.pdf_path && (
                    <DropdownMenuItem onClick={() => previewPdf(d)}><Eye className="size-4 mr-2"/>Aperçu PDF</DropdownMenuItem>
                  )}
                  {(d.docx_path || d.file_path) && (
                    <DropdownMenuItem onClick={() => downloadDoc(d, "docx")}><Download className="size-4 mr-2"/>Télécharger DOCX</DropdownMenuItem>
                  )}
                  {d.pdf_path && (
                    <DropdownMenuItem onClick={() => downloadDoc(d, "pdf")}><Download className="size-4 mr-2"/>Télécharger PDF</DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => { setRenameDoc(d); setRenameValue(d.name); }}><Pencil className="size-4 mr-2"/>Renommer</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSignDoc(d)} disabled={d.status === "signed"}>
                    <FileSignature className="size-4 mr-2"/>Envoyer pour signature
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => updateStatus(d, d.status === "archived" ? "generated" : "archived")}>
                    <Archive className="size-4 mr-2"/>{d.status === "archived" ? "Désarchiver" : "Archiver"}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => remove.mutate(d)}>
                    <Trash2 className="size-4 mr-2"/>Supprimer
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </CardContent></Card>
          ))}
        </div>
      )}

      <Dialog open={genOpen} onOpenChange={setGenOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Générer un document</DialogTitle>
            <DialogDescription>Choisissez un modèle. Les variables seront remplacées et un PDF généré automatiquement.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Modèle</Label>
              <Select value={genTemplateId} onValueChange={setGenTemplateId}>
                <SelectTrigger><SelectValue placeholder="Sélectionner un modèle"/></SelectTrigger>
                <SelectContent>
                  {templates.map((t: any) => <SelectItem key={t.id} value={t.id}>{t.name}{t.category ? ` — ${t.category}` : ""}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Nom du document</Label>
              <Input value={genName} onChange={e => setGenName(e.target.value)} placeholder={selectedTpl ? `${selectedTpl.name} – ${companyName}` : ""}/>
            </div>
            {selectedTpl && Array.isArray(selectedTpl.variables) && selectedTpl.variables.length > 0 && (
              <div className="rounded-lg border bg-muted/30 p-2 max-h-72 overflow-auto">
                <p className="text-xs text-muted-foreground mb-2">
                  Variables détectées · saisissez une valeur pour remplacer
                </p>
                <div className="space-y-1.5">
                  {previewValues?.map((v) => (
                    <div key={v.name} className="grid grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] items-center gap-2 text-xs">
                      <span className="font-mono text-muted-foreground truncate" title={`{{${v.name}}}`}>{`{{${v.name}}}`}</span>
                      <Input
                        value={overrides[v.name] ?? v.auto}
                        placeholder={v.missing ? "manquant — saisir une valeur" : ""}
                        className={`h-7 text-xs ${v.missing && !overrides[v.name] ? "border-destructive/60" : ""}`}
                        onChange={(e) => setOverrides((prev) => ({ ...prev, [v.name]: e.target.value }))}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
            {generate.isPending && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground rounded-md bg-muted/40 px-3 py-2">
                <Loader2 className="size-3.5 animate-spin"/>
                Génération du DOCX et conversion en PDF en cours…
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGenOpen(false)}>Annuler</Button>
            <Button onClick={() => generate.mutate()} disabled={!genTemplateId || generate.isPending}>
              {generate.isPending ? <Loader2 className="size-4 mr-1 animate-spin"/> : <Plus className="size-4 mr-1"/>}
              {generate.isPending ? "Génération…" : "Générer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* PDF Preview Modal */}
      <Dialog open={!!previewUrl} onOpenChange={(o) => { if (!o) { setPreviewUrl(null); setPreviewName(""); } }}>
        <DialogContent className="max-w-5xl w-[95vw] h-[90vh] p-0 flex flex-col gap-0">
          <DialogHeader className="px-4 py-3 border-b">
            <DialogTitle className="text-base truncate">{previewName}</DialogTitle>
          </DialogHeader>
          {previewUrl && (
            <iframe src={previewUrl} className="flex-1 w-full border-0" title="Aperçu PDF"/>
          )}
        </DialogContent>
      </Dialog>

      {/* Rename Modal */}
      <Dialog open={!!renameDoc} onOpenChange={(o) => { if (!o) { setRenameDoc(null); setRenameValue(""); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Renommer le document</DialogTitle>
          </DialogHeader>
          <Input value={renameValue} onChange={(e) => setRenameValue(e.target.value)} autoFocus/>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setRenameDoc(null); setRenameValue(""); }}>Annuler</Button>
            <Button onClick={submitRename} disabled={!renameValue.trim()}>Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {signDoc && (
        <SendForSignatureDialog
          open={!!signDoc}
          onOpenChange={(o) => { if (!o) setSignDoc(null); }}
          document={signDoc}
          firmId={firmId}
          companyId={companyId}
        />
      )}
    </div>
  );
}