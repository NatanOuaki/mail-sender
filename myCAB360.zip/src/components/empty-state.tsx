import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

export function EmptyState({ icon: Icon, title, description, action }: {
  icon: LucideIcon; title: string; description?: string; action?: ReactNode;
}) {
  return (
    <div className="text-center py-16 px-6 border border-dashed border-border rounded-xl bg-card/50">
      <div className="mx-auto size-12 rounded-xl bg-primary/10 text-primary grid place-items-center mb-4">
        <Icon className="size-6"/>
      </div>
      <h3 className="text-base font-semibold text-foreground">{title}</h3>
      {description && <p className="text-sm text-muted-foreground mt-1 max-w-sm mx-auto">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}