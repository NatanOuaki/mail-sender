import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { FileSignature, MoreVertical, X, Eye, Check, AlertTriangle, Clock, Bell } from "lucide-react";
import { toast } from "sonner";
import {
  listSignatureRequests, cancelSignatureRequest, simulateSignatureEvent, sendSignatureReminder,
} from "@/lib/signatures.functions";

const STATUS_LABEL: Record<string, string> = {
  draft: "Brouillon", sent: "Envoyé", viewed: "Vu", signed: "Signé",
  refused: "Refusé", expired: "Expiré", cancelled: "Annulé",
};
const STATUS_TONE: Record<string, string> = {
  sent: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  viewed: "bg-amber-500/10 text-amber-700 dark:text-amber-300",
  signed: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300",
  refused: "bg-destructive/10 text-destructive",
  expired: "bg-muted text-muted-foreground",
  cancelled: "bg-muted text-muted-foreground",
  draft: "bg-muted text-muted-foreground",
};

export function CompanySignaturesTab({ companyId }: { companyId: string }) {
  const qc = useQueryClient();
  const listFn = useServerFn(listSignatureRequests);
  const cancelFn = useServerFn(cancelSignatureRequest);
  const simFn = useServerFn(simulateSignatureEvent);
  const reminderFn = useServerFn(sendSignatureReminder);

  const { data, isLoading } = useQuery({
    queryKey: ["sig-requests", companyId],
    queryFn: () => listFn({ data: { companyId } }),
  });
  const requests = data?.requests ?? [];

  const pending = requests.filter((r: any) => ["sent","viewed","draft"].includes(r.status));
  const signed = requests.filter((r: any) => r.status === "signed");
  const failed = requests.filter((r: any) => ["refused","expired","cancelled"].includes(r.status));

  const cancel = useMutation({
    mutationFn: (id: string) => cancelFn({ data: { requestId: id } }),
    onSuccess: () => { toast.success("Demande annulée"); qc.invalidateQueries({ queryKey: ["sig-requests", companyId] }); qc.invalidateQueries({ queryKey: ["gendocs", companyId] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const simulate = useMutation({
    mutationFn: (v: { id: string; status: any }) => simFn({ data: { requestId: v.id, status: v.status } }),
    onSuccess: () => { toast.success("Statut simulé mis à jour"); qc.invalidateQueries({ queryKey: ["sig-requests", companyId] }); qc.invalidateQueries({ queryKey: ["gendocs", companyId] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const remind = useMutation({
    mutationFn: (id: string) => reminderFn({ data: { requestId: id } }),
    onSuccess: (r: any) => { toast.success(`Rappel envoyé à ${r?.sent ?? 0} signataire(s)`); qc.invalidateQueries({ queryKey: ["sig-requests", companyId] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Chargement…</p>;

  if (requests.length === 0) {
    return (
      <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
        <FileSignature className="size-6 mx-auto mb-2 opacity-50"/>
        Aucune demande de signature pour cette entreprise.
      </CardContent></Card>
    );
  }

  const renderGroup = (label: string, list: any[], icon: any) => list.length > 0 && (
    <div className="space-y-2">
      <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground uppercase tracking-wide">
        {icon}{label} ({list.length})
      </div>
      {list.map((r) => (
        <Card key={r.id}><CardContent className="p-3 space-y-2">
          <div className="flex items-start gap-2">
            <div className="size-8 rounded-lg bg-primary/10 text-primary grid place-items-center"><FileSignature className="size-4"/></div>
            <div className="min-w-0 flex-1">
              <p className="font-medium text-sm truncate">{r.subject ?? "Demande de signature"}</p>
              <p className="text-xs text-muted-foreground">
                {r.provider === "yousign" ? "YouSign" : "DocuSign"}
                {r.mode === "simulated" ? " · simulé" : ""}
                {r.sent_at ? ` · envoyé le ${new Date(r.sent_at).toLocaleDateString("fr-FR")}` : ""}
              </p>
            </div>
            <Badge className={`capitalize ${STATUS_TONE[r.status] ?? ""}`}>{STATUS_LABEL[r.status] ?? r.status}</Badge>
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button size="icon" variant="ghost"><MoreVertical className="size-4"/></Button></DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                {["sent","viewed"].includes(r.status) && (
                  <DropdownMenuItem onClick={() => remind.mutate(r.id)}><Bell className="size-4 mr-2"/>Envoyer un rappel{r.reminder_count ? ` (${r.reminder_count})` : ""}</DropdownMenuItem>
                )}
                {r.mode === "simulated" && r.status !== "signed" && (
                  <>
                    <DropdownMenuItem onClick={() => simulate.mutate({ id: r.id, status: "viewed" })}><Eye className="size-4 mr-2"/>Simuler vu</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => simulate.mutate({ id: r.id, status: "signed" })}><Check className="size-4 mr-2"/>Simuler signé</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => simulate.mutate({ id: r.id, status: "refused" })}><AlertTriangle className="size-4 mr-2"/>Simuler refusé</DropdownMenuItem>
                  </>
                )}
                {!["signed","cancelled"].includes(r.status) && (
                  <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => cancel.mutate(r.id)}>
                    <X className="size-4 mr-2"/>Annuler la demande
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {r.signers?.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-10">
              {r.signers.map((s: any) => (
                <div key={s.id} className="text-xs flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px] capitalize">{STATUS_LABEL[s.status] ?? s.status}</Badge>
                  <span className="truncate">{s.firstname} {s.lastname}</span>
                  <span className="text-muted-foreground truncate">{s.email}</span>
                </div>
              ))}
            </div>
          )}

          {r.events?.length > 0 && (
            <div className="pl-10 border-l-2 border-muted ml-4 space-y-0.5">
              {r.events.slice(0, 5).map((e: any) => (
                <div key={e.id} className="text-[11px] text-muted-foreground">
                  <span className="font-mono">{new Date(e.created_at).toLocaleString("fr-FR")}</span>
                  <span className="mx-1">·</span>
                  <span>{e.event_type}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent></Card>
      ))}
    </div>
  );

  return (
    <div className="space-y-5">
      {renderGroup("En cours", pending, <Clock className="size-3"/>)}
      {renderGroup("Signés", signed, <Check className="size-3"/>)}
      {renderGroup("Refusés / expirés / annulés", failed, <AlertTriangle className="size-3"/>)}
    </div>
  );
}