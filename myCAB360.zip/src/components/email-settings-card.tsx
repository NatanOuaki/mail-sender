import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mail, Check } from "lucide-react";
import { toast } from "sonner";
import {
  getEmailSettings, saveEmailSettings, testEmailConnection, sendTestEmail,
} from "@/lib/emails.functions";

export function EmailSettingsCard({ firmId }: { firmId?: string }) {
  const qc = useQueryClient();
  const getFn = useServerFn(getEmailSettings);
  const saveFn = useServerFn(saveEmailSettings);
  const testFn = useServerFn(testEmailConnection);
  const sendTestFn = useServerFn(sendTestEmail);

  const { data, refetch } = useQuery({
    queryKey: ["email-settings", firmId], enabled: !!firmId,
    queryFn: () => getFn({ data: { firmId: firmId! } }),
  });

  const [form, setForm] = useState({
    email_provider: "resend" as "smtp"|"resend"|"sendgrid"|"mailgun"|"postmark",
    sender_name: "", sender_email: "", smtp_host: "", smtp_port: 587,
    smtp_username: "", smtp_password: "", smtp_secure: true,
    provider_api_key: "",
    mailgun_domain: "", mailgun_region: "us" as "us"|"eu",
    postmark_stream: "outbound",
    native_provider_email_enabled: true, custom_firm_email_enabled: true,
  });
  const [testTo, setTestTo] = useState("");

  useEffect(() => {
    if (data?.settings) {
      const cfg = (data.settings as any).provider_config ?? {};
      setForm((f) => ({
        ...f,
        email_provider: ((data.settings as any).email_provider ?? "smtp"),
        sender_name: data.settings.sender_name ?? "",
        sender_email: data.settings.sender_email ?? "",
        smtp_host: data.settings.smtp_host ?? "",
        smtp_port: data.settings.smtp_port ?? 587,
        smtp_username: data.settings.smtp_username ?? "",
        smtp_secure: data.settings.smtp_secure ?? true,
        mailgun_domain: cfg.mailgun_domain ?? "",
        mailgun_region: cfg.mailgun_region === "eu" ? "eu" : "us",
        postmark_stream: cfg.postmark_stream ?? "outbound",
        native_provider_email_enabled: data.settings.native_provider_email_enabled ?? true,
        custom_firm_email_enabled: data.settings.custom_firm_email_enabled ?? true,
        smtp_password: "",
        provider_api_key: "",
      }));
    }
  }, [data?.settings?.firm_id]);

  const save = useMutation({
    mutationFn: () => {
      const provider_config: Record<string, any> = {};
      if (form.email_provider === "mailgun") {
        provider_config.mailgun_domain = form.mailgun_domain.trim();
        provider_config.mailgun_region = form.mailgun_region;
      }
      if (form.email_provider === "postmark") {
        provider_config.postmark_stream = form.postmark_stream.trim() || "outbound";
      }
      return saveFn({
        data: {
          firmId: firmId!,
          email_provider: form.email_provider,
          sender_name: form.sender_name || undefined,
          sender_email: form.sender_email,
          smtp_host: form.email_provider === "smtp" ? form.smtp_host : undefined,
          smtp_port: form.email_provider === "smtp" ? Number(form.smtp_port) : undefined,
          smtp_username: form.email_provider === "smtp" ? (form.smtp_username || undefined) : undefined,
          smtp_password: form.email_provider === "smtp" ? (form.smtp_password || undefined) : undefined,
          smtp_secure: form.email_provider === "smtp" ? form.smtp_secure : undefined,
          provider_api_key: form.email_provider !== "smtp" ? (form.provider_api_key || undefined) : undefined,
          provider_config,
          native_provider_email_enabled: form.native_provider_email_enabled,
          custom_firm_email_enabled: form.custom_firm_email_enabled,
        },
      });
    },
    onSuccess: () => { toast.success("Paramètres enregistrés"); setForm(f => ({...f, smtp_password: "", provider_api_key: ""})); refetch(); qc.invalidateQueries({ queryKey: ["email-settings"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const test = useMutation({
    mutationFn: () => testFn({ data: { firmId: firmId! } }),
    onSuccess: () => { toast.success("Connexion validée"); refetch(); },
    onError: (e: Error) => toast.error(`Échec : ${e.message}`),
  });
  const sendTest = useMutation({
    mutationFn: () => sendTestFn({ data: { firmId: firmId!, to: testTo.trim() } }),
    onSuccess: () => toast.success("Email de test envoyé"),
    onError: (e: Error) => toast.error(e.message),
  });

  const status = data?.settings?.status as string | undefined;
  const connected = status === "connected";
  const isSmtp = form.email_provider === "smtp";
  const apiKeySet = !!(data as any)?.hasApiKey;

  return (
    <Card className="mb-4">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="size-10 rounded-lg bg-primary/10 text-primary grid place-items-center"><Mail className="size-5"/></div>
            <div>
              <p className="font-semibold">Email</p>
              <p className="text-xs text-muted-foreground mt-0.5 max-w-xl">
                Notifications par email aux clients (signatures, rappels, partages).
              </p>
            </div>
          </div>
          {connected
            ? <Badge className="bg-primary/10 text-primary"><Check className="size-3 mr-1"/>Connecté</Badge>
            : <Badge variant="outline">{status === "error" ? "Erreur" : "Non connecté"}</Badge>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
          <div className="md:col-span-2">
            <Label className="text-xs">Fournisseur d'email</Label>
            <Select value={form.email_provider} onValueChange={(v: any) => setForm({...form, email_provider: v})}>
              <SelectTrigger><SelectValue/></SelectTrigger>
              <SelectContent>
                <SelectItem value="resend">Resend (recommandé)</SelectItem>
                <SelectItem value="sendgrid">SendGrid</SelectItem>
                <SelectItem value="mailgun">Mailgun</SelectItem>
                <SelectItem value="postmark">Postmark</SelectItem>
                <SelectItem value="smtp">SMTP (avancé / auto-hébergé)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div><Label className="text-xs">Nom expéditeur</Label>
            <Input value={form.sender_name} onChange={e => setForm({...form, sender_name: e.target.value})}/></div>
          <div><Label className="text-xs">Email expéditeur</Label>
            <Input type="email" value={form.sender_email} onChange={e => setForm({...form, sender_email: e.target.value})}/></div>

          {!isSmtp && (
            <div className="md:col-span-2">
              <Label className="text-xs">
                Clé API {apiKeySet && <span className="text-muted-foreground">(définie · laisser vide pour conserver)</span>}
              </Label>
              <Input type="password" autoComplete="new-password" placeholder={
                form.email_provider === "resend" ? "re_xxx" :
                form.email_provider === "sendgrid" ? "SG.xxx" :
                form.email_provider === "postmark" ? "Token serveur Postmark" :
                "Clé API privée Mailgun"
              } value={form.provider_api_key} onChange={e => setForm({...form, provider_api_key: e.target.value})}/>
            </div>
          )}

          {form.email_provider === "mailgun" && (
            <>
              <div><Label className="text-xs">Domaine Mailgun</Label>
                <Input placeholder="mg.example.com" value={form.mailgun_domain} onChange={e => setForm({...form, mailgun_domain: e.target.value})}/></div>
              <div><Label className="text-xs">Région</Label>
                <Select value={form.mailgun_region} onValueChange={(v: any) => setForm({...form, mailgun_region: v})}>
                  <SelectTrigger><SelectValue/></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">US</SelectItem>
                    <SelectItem value="eu">EU</SelectItem>
                  </SelectContent>
                </Select></div>
            </>
          )}
          {form.email_provider === "postmark" && (
            <div><Label className="text-xs">Message Stream</Label>
              <Input value={form.postmark_stream} onChange={e => setForm({...form, postmark_stream: e.target.value})}/></div>
          )}

          {isSmtp && <>
            <div className="md:col-span-2 -mb-1 mt-2">
              <p className="text-xs text-muted-foreground">SMTP — avancé / auto-hébergé uniquement (les connexions TCP sortantes peuvent être bloquées en production).</p>
            </div>
            <div><Label className="text-xs">Serveur SMTP</Label>
              <Input value={form.smtp_host} placeholder="smtp.example.com" onChange={e => setForm({...form, smtp_host: e.target.value})}/></div>
            <div><Label className="text-xs">Port</Label>
              <Input type="number" value={form.smtp_port} onChange={e => setForm({...form, smtp_port: Number(e.target.value)})}/></div>
            <div><Label className="text-xs">Nom d'utilisateur</Label>
              <Input value={form.smtp_username} onChange={e => setForm({...form, smtp_username: e.target.value})}/></div>
            <div><Label className="text-xs">Mot de passe {data?.hasPassword && <span className="text-muted-foreground">(défini · laisser vide pour conserver)</span>}</Label>
              <Input type="password" autoComplete="new-password" value={form.smtp_password} onChange={e => setForm({...form, smtp_password: e.target.value})}/></div>
          </>}
        </div>

        <div className="flex items-center gap-6 mt-4 flex-wrap">
          {isSmtp && (
            <label className="flex items-center gap-2 text-sm">
              <Switch checked={form.smtp_secure} onCheckedChange={(v) => setForm({...form, smtp_secure: v})}/>
              TLS / SSL
            </label>
          )}
          <label className="flex items-center gap-2 text-sm">
            <Switch checked={form.custom_firm_email_enabled} onCheckedChange={(v) => setForm({...form, custom_firm_email_enabled: v})}/>
            Activer mes emails personnalisés
          </label>
          <label className="flex items-center gap-2 text-sm">
            <Switch checked={form.native_provider_email_enabled} onCheckedChange={(v) => setForm({...form, native_provider_email_enabled: v})}/>
            Conserver les emails natifs YouSign / DocuSign
          </label>
        </div>

        {data?.settings?.last_error && (
          <p className="text-xs text-destructive mt-2">Dernière erreur : {data.settings.last_error}</p>
        )}

        <div className="flex flex-wrap gap-2 mt-4">
          <Button size="sm" onClick={() => save.mutate()} disabled={save.isPending}>Enregistrer</Button>
          <Button size="sm" variant="outline" onClick={() => test.mutate()} disabled={test.isPending}>Tester la connexion</Button>
          <div className="flex items-center gap-2 ml-auto">
            <Input className="w-56" placeholder="email@test.com" value={testTo} onChange={e => setTestTo(e.target.value)}/>
            <Button size="sm" variant="outline" onClick={() => sendTest.mutate()} disabled={sendTest.isPending || !testTo.includes("@")}>Email de test</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}