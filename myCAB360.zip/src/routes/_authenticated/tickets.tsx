import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { Ticket } from "lucide-react";

export const Route = createFileRoute("/_authenticated/tickets")({ component: () => (
  <div>
    <PageHeader title="Tickets" description="Suivi des demandes clients"/>
    <EmptyState icon={Ticket} title="Bientôt disponible" description="Le module tickets arrive prochainement."/>
  </div>
) });