import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useActiveFirm } from "@/lib/use-active-firm";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Plug, Check, Sparkles, FileSignature } from "lucide-react";
import { toast } from "sonner";
import { setPappersKey, clearPappersKey, testPappersConnection, getPappersStatus } from "@/lib/pappers.functions";
import {
  setSignatureCredentials, clearSignatureCredentials,
  testSignatureConnection, getSignatureProviderStatus,
} from "@/lib/signatures.functions";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmailSettingsCard } from "@/components/email-settings-card";

export const Route = createFileRoute("/_authenticated/integrations")({ component: IntegrationsPage });

type Provider = "google_drive" | "sharepoint" | "gmail_smtp" | "inpi";

const PROVIDERS: { key: Provider; name: string; description: string }[] = [
  { key: "google_drive", name: "Google Drive", description: "Synchronisation des documents générés vers Drive." },
  { key: "sharepoint", name: "SharePoint", description: "Stockage et partage via Microsoft 365." },
  { key: "gmail_smtp", name: "Gmail / SMTP", description: "Envoi d'emails et notifications depuis votre adresse." },
  { key: "inpi", name: "INPI", description: "Accès aux registres officiels du commerce et propriété industrielle." },
];

function IntegrationsPage() {
  const { activeFirm } = useActiveFirm();
  const qc = useQueryClient();
  const setKey = useServerFn(setPappersKey);
  const clearKey = useServerFn(clearPappersKey);
  const testFn = useServerFn(testPappersConnection);
  const statusFn = useServerFn(getPappersStatus);
  const [pappersOpen, setPappersOpen] = useState(false);
  const [pappersKeyInput, setPappersKeyInput] = useState("");

  const { data: pappers, refetch: refetchPappers } = useQuery({
    queryKey: ["pappers-status", activeFirm?.id], enabled: !!activeFirm,
    queryFn: () => statusFn({ data: { firmId: activeFirm!.id } }),
  });

  const connect = useMutation({
    mutationFn: () => setKey({ data: { firmId: activeFirm!.id, apiKey: pappersKeyInput.trim() } }),
    onSuccess: () => { toast.success("Pappers connecté"); setPappersOpen(false); setPappersKeyInput(""); refetchPappers(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const disconnect = useMutation({
    mutationFn: () => clearKey({ data: { firmId: activeFirm!.id } }),
    onSuccess: () => { toast.success("Pappers déconnecté"); refetchPappers(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const test = useMutation({
    mutationFn: () => testFn({ data: { firmId: activeFirm!.id } }),
    onSuccess: () => { toast.success("Connexion réussie"); refetchPappers(); },
    onError: (e: Error) => toast.error(e.message),
  });

  const { data: integrations = [] } = useQuery({
    queryKey: ["integrations", activeFirm?.id], enabled: !!activeFirm,
    queryFn: async () => {
      const { data, error } = await supabase.from("integrations").select("*").eq("firm_id", activeFirm!.id);
      if (error) throw error; return data;
    },
  });

  const toggle = useMutation({
    mutationFn: async ({ provider, connect }: { provider: Provider; connect: boolean }) => {
      const existing = integrations.find((i: any) => i.provider === provider);
      if (existing) {
        const { error } = await supabase.from("integrations").update({
          status: connect ? "connected" : "disconnected",
          connected_at: connect ? new Date().toISOString() : null,
        }).eq("id", existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("integrations").insert({
          firm_id: activeFirm!.id, provider, status: connect ? "connected" : "disconnected",
          connected_at: connect ? new Date().toISOString() : null,
        });
        if (error) throw error;
      }
    },
    onSuccess: () => { toast.success("Statut mis à jour"); qc.invalidateQueries({ queryKey: ["integrations"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div>
      <PageHeader title="Intégrations" description="Connectez vos services tiers à ce cabinet"/>

      {/* Pappers card */}
      <Card className="mb-4">
        <CardContent className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="size-10 rounded-lg bg-primary/10 text-primary grid place-items-center"><Sparkles className="size-5"/></div>
              <div>
                <p className="font-semibold">Pappers</p>
                <p className="text-xs text-muted-foreground mt-0.5 max-w-xl">Enrichissement automatique des données d'entreprise (SIREN, SIRET, dirigeants, capital).</p>
              </div>
            </div>
            {pappers?.connected
              ? <Badge className="bg-primary/10 text-primary"><Check className="size-3 mr-1"/>Connecté</Badge>
              : <Badge variant="outline">Non connecté</Badge>}
          </div>
          {pappers?.connected && (
            <div className="grid grid-cols-2 gap-3 mt-4 text-xs text-muted-foreground">
              <div>Connecté le : {pappers.connected_at ? new Date(pappers.connected_at).toLocaleString("fr-FR") : "—"}</div>
              <div>Dernière synchro : {pappers.last_sync_at ? new Date(pappers.last_sync_at).toLocaleString("fr-FR") : "—"}</div>
            </div>
          )}
          <div className="flex flex-wrap gap-2 mt-4">
            {pappers?.connected ? (
              <>
                <Button size="sm" variant="outline" onClick={() => test.mutate()} disabled={test.isPending}>Tester la connexion</Button>
                <Button size="sm" variant="outline" onClick={() => setPappersOpen(true)}>Remplacer la clé</Button>
                <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => disconnect.mutate()} disabled={disconnect.isPending}>Déconnecter</Button>
              </>
            ) : (
              <Button size="sm" onClick={() => setPappersOpen(true)}>Connecter Pappers</Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={pappersOpen} onOpenChange={setPappersOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Connecter Pappers</DialogTitle>
            <DialogDescription>Saisissez votre clé API Pappers. Elle est stockée de manière sécurisée côté serveur et n'est jamais exposée au navigateur.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Clé API</Label>
            <Input type="password" autoComplete="off" placeholder="Votre clé API Pappers" value={pappersKeyInput} onChange={e => setPappersKeyInput(e.target.value)}/>
            <p className="text-xs text-muted-foreground">Obtenez votre clé sur pappers.fr → API → Mon compte.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPappersOpen(false)}>Annuler</Button>
            <Button onClick={() => connect.mutate()} disabled={connect.isPending || pappersKeyInput.trim().length < 8}>
              {connect.isPending ? "Vérification…" : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SignatureProviderCard provider="yousign" firmId={activeFirm?.id}/>
      <SignatureProviderCard provider="docusign" firmId={activeFirm?.id}/>
      <EmailSettingsCard firmId={activeFirm?.id}/>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {PROVIDERS.map(p => {
          const i = integrations.find((x: any) => x.provider === p.key);
          const connected = i?.status === "connected";
          return (
            <Card key={p.key}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="size-10 rounded-lg bg-primary/10 text-primary grid place-items-center"><Plug className="size-5"/></div>
                  {connected ? <Badge className="bg-primary/10 text-primary"><Check className="size-3 mr-1"/>Connecté</Badge> : <Badge variant="outline">Non connecté</Badge>}
                </div>
                <p className="font-semibold mt-3">{p.name}</p>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{p.description}</p>
                <Button variant={connected ? "outline" : "default"} size="sm" className="w-full mt-4"
                  onClick={() => toggle.mutate({ provider: p.key, connect: !connected })}>
                  {connected ? "Déconnecter" : "Connecter"}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function SignatureProviderCard({ provider, firmId }: { provider: "yousign" | "docusign"; firmId?: string }) {
  const qc = useQueryClient();
  const setFn = useServerFn(setSignatureCredentials);
  const clearFn = useServerFn(clearSignatureCredentials);
  const testFn = useServerFn(testSignatureConnection);
  const statusFn = useServerFn(getSignatureProviderStatus);
  const [open, setOpen] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [accountId, setAccountId] = useState("");
  const [mode, setMode] = useState<"sandbox" | "live">("sandbox");

  const { data: status, refetch } = useQuery({
    queryKey: ["sig-status", provider, firmId], enabled: !!firmId,
    queryFn: () => statusFn({ data: { firmId: firmId!, provider } }),
  });

  const connect = useMutation({
    mutationFn: () => setFn({ data: {
      firmId: firmId!, provider, apiKey: apiKey.trim(),
      config: provider === "docusign"
        ? { mode, account_id: accountId.trim() }
        : { mode },
    } }),
    onSuccess: () => { toast.success(`${provider === "yousign" ? "YouSign" : "DocuSign"} connecté`); setOpen(false); setApiKey(""); setAccountId(""); refetch(); qc.invalidateQueries({ queryKey: ["integrations"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const disconnect = useMutation({
    mutationFn: () => clearFn({ data: { firmId: firmId!, provider } }),
    onSuccess: () => { toast.success("Déconnecté"); refetch(); qc.invalidateQueries({ queryKey: ["integrations"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const test = useMutation({
    mutationFn: () => testFn({ data: { firmId: firmId!, provider } }),
    onSuccess: () => { toast.success("Connexion réussie"); refetch(); },
    onError: (e: Error) => toast.error(e.message),
  });

  const name = provider === "yousign" ? "YouSign" : "DocuSign";
  const description = provider === "yousign"
    ? "Signature électronique légalement valable en France et UE."
    : "Signature électronique internationale pour vos clients.";

  return (
    <Card className="mb-4">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="size-10 rounded-lg bg-primary/10 text-primary grid place-items-center"><FileSignature className="size-5"/></div>
            <div>
              <p className="font-semibold">{name}</p>
              <p className="text-xs text-muted-foreground mt-0.5 max-w-xl">{description}</p>
            </div>
          </div>
          {status?.connected
            ? <Badge className="bg-primary/10 text-primary"><Check className="size-3 mr-1"/>Connecté · {status.mode}</Badge>
            : <Badge variant="outline">Non connecté</Badge>}
        </div>
        {status?.connected && (
          <div className="grid grid-cols-2 gap-3 mt-4 text-xs text-muted-foreground">
            <div>Connecté le : {status.connected_at ? new Date(status.connected_at).toLocaleString("fr-FR") : "—"}</div>
            <div>Dernier test réussi : {status.last_test_at ? new Date(status.last_test_at).toLocaleString("fr-FR") : "—"}</div>
          </div>
        )}
        <div className="flex flex-wrap gap-2 mt-4">
          {status?.connected ? (
            <>
              <Button size="sm" variant="outline" onClick={() => test.mutate()} disabled={test.isPending}>Tester la connexion</Button>
              <Button size="sm" variant="outline" onClick={() => setOpen(true)}>Remplacer les identifiants</Button>
              <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => disconnect.mutate()} disabled={disconnect.isPending}>Déconnecter</Button>
            </>
          ) : (
            <Button size="sm" onClick={() => setOpen(true)}>Connecter {name}</Button>
          )}
        </div>
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Connecter {name}</DialogTitle>
            <DialogDescription>
              Les identifiants sont stockés côté serveur uniquement et ne sont jamais exposés au navigateur.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Environnement</Label>
              <Select value={mode} onValueChange={v => setMode(v as any)}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sandbox">Sandbox / test</SelectItem>
                  <SelectItem value="live">Production</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{provider === "yousign" ? "Clé API" : "Access token"}</Label>
              <Input type="password" autoComplete="off" value={apiKey} onChange={e => setApiKey(e.target.value)}
                placeholder={provider === "yousign" ? "Votre clé API YouSign" : "Bearer access token DocuSign"}/>
            </div>
            {provider === "docusign" && (
              <div>
                <Label>Account ID</Label>
                <Input value={accountId} onChange={e => setAccountId(e.target.value)} placeholder="ex. 1234567"/>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Annuler</Button>
            <Button onClick={() => connect.mutate()}
              disabled={connect.isPending || apiKey.trim().length < 4 || (provider === "docusign" && !accountId.trim())}>
              {connect.isPending ? "Vérification…" : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}