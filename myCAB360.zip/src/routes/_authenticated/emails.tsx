import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { Mail } from "lucide-react";

export const Route = createFileRoute("/_authenticated/emails")({ component: () => (
  <div>
    <PageHeader title="Emails" description="Centralisez vos échanges email"/>
    <EmptyState icon={Mail} title="Bientôt disponible" description="La gestion des emails arrive prochainement."/>
  </div>
) });