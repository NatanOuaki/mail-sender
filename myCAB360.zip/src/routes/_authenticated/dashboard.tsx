import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useActiveFirm } from "@/lib/use-active-firm";
import { PageHeader } from "@/components/page-header";
import { Building2, UserCheck, UserPlus, FileText, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/dashboard")({ component: Dashboard });

function StatCard({ icon: Icon, label, value, hint }: { icon: typeof Building2; label: string; value: number | string; hint?: string }) {
  return (
    <Card className="border-border">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">{label}</p>
            <p className="text-3xl font-semibold tracking-tight mt-2">{value}</p>
            {hint && <p className="text-xs text-muted-foreground mt-1">{hint}</p>}
          </div>
          <div className="size-10 rounded-lg bg-primary/10 text-primary grid place-items-center"><Icon className="size-5"/></div>
        </div>
      </CardContent>
    </Card>
  );
}

function Dashboard() {
  const { activeFirm } = useActiveFirm();

  const { data: counts } = useQuery({
    queryKey: ["dashboard", activeFirm?.id],
    enabled: !!activeFirm,
    queryFn: async () => {
      const firmId = activeFirm!.id;
      const [all, clients, prospects, tpl] = await Promise.all([
        supabase.from("companies").select("*", { count: "exact", head: true }).eq("firm_id", firmId),
        supabase.from("companies").select("*", { count: "exact", head: true }).eq("firm_id", firmId).eq("status", "client"),
        supabase.from("companies").select("*", { count: "exact", head: true }).eq("firm_id", firmId).eq("status", "prospect"),
        supabase.from("document_templates").select("*", { count: "exact", head: true }).eq("firm_id", firmId),
      ]);
      return {
        companies: all.count ?? 0,
        clients: clients.count ?? 0,
        prospects: prospects.count ?? 0,
        templates: tpl.count ?? 0,
      };
    },
  });

  return (
    <div>
      <PageHeader
        title={`Bonjour 👋`}
        description={activeFirm ? `Vue d'ensemble de ${activeFirm.name}` : "Sélectionnez ou créez un cabinet"}
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Building2} label="Entreprises" value={counts?.companies ?? "—"}/>
        <StatCard icon={UserCheck} label="Clients" value={counts?.clients ?? "—"}/>
        <StatCard icon={UserPlus} label="Prospects" value={counts?.prospects ?? "—"}/>
        <StatCard icon={FileText} label="Modèles" value={counts?.templates ?? "—"}/>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle className="text-base">Activité récente</CardTitle></CardHeader>
          <CardContent>
            <div className="text-sm text-muted-foreground py-12 text-center border border-dashed rounded-lg">
              <TrendingUp className="size-8 mx-auto mb-2 opacity-40"/>
              Aucune activité enregistrée pour le moment.
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Démarrage rapide</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <p className="text-muted-foreground">Configurez votre cabinet :</p>
            <ul className="space-y-2 text-foreground">
              <li>1. Ajoutez une entreprise</li>
              <li>2. Créez un client</li>
              <li>3. Importez un modèle DOCX</li>
              <li>4. Connectez Pappers, YouSign…</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}