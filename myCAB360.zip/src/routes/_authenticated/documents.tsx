import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useRef, useState, type DragEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useActiveFirm } from "@/lib/use-active-firm";
import { useAuth } from "@/lib/use-auth";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { FileText, Plus, Upload, Trash2, Eye, Archive, ArchiveRestore } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { extractTemplateVariables } from "@/lib/documents.functions";

export const Route = createFileRoute("/_authenticated/documents")({ component: DocumentsPage });

export const TEMPLATE_CATEGORIES = [
  "Lettre de mission",
  "Mandat SEPA",
  "Courrier",
  "Juridique",
  "Fiscal",
  "Social",
  "Autre",
];

const ACCEPTED = ".docx,.pdf,.png,.jpg,.jpeg";

function fileTypeOf(name: string): string {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  if (ext === "docx") return "docx";
  if (ext === "pdf") return "pdf";
  if (["png","jpg","jpeg"].includes(ext)) return "image";
  return ext || "other";
}

function DocumentsPage() {
  const { activeFirm } = useActiveFirm();
  const { user } = useAuth();
  const qc = useQueryClient();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [category, setCategory] = useState<string>("Lettre de mission");
  const [docFile, setDocFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [showArchived, setShowArchived] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<{ id: string; path: string | null } | null>(null);
  const [previewing, setPreviewing] = useState<any | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const extractVarsFn = useServerFn(extractTemplateVariables);

  const { data: templates = [] } = useQuery({
    queryKey: ["templates", activeFirm?.id],
    enabled: !!activeFirm,
    queryFn: async () => {
      const { data, error } = await supabase.from("document_templates").select("*").eq("firm_id", activeFirm!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: role } = useQuery({
    queryKey: ["my-role", activeFirm?.id], enabled: !!activeFirm && !!user,
    queryFn: async () => {
      const { data } = await supabase.from("firm_members").select("role").eq("firm_id", activeFirm!.id).eq("user_id", user!.id).maybeSingle();
      return data?.role ?? null;
    },
  });
  const isAdmin = role === "owner" || role === "admin";

  const filtered = useMemo(() => {
    let list = templates as any[];
    if (!showArchived) list = list.filter(t => t.is_active !== false);
    if (filterCategory !== "all") list = list.filter(t => t.category === filterCategory);
    return list;
  }, [templates, filterCategory, showArchived]);

  const grouped = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const t of filtered) {
      const k = t.category || "Autre";
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(t);
    }
    return Array.from(map.entries());
  }, [filtered]);

  const reset = () => { setName(""); setCategory("Lettre de mission"); setDocFile(null); };

  const create = useMutation({
    mutationFn: async () => {
      if (!activeFirm || !docFile) throw new Error("Fichier requis");
      const path = `${activeFirm.id}/templates/${Date.now()}-${docFile.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error: upErr } = await supabase.storage.from("templates").upload(path, docFile, { upsert: false });
      if (upErr) throw upErr;
      const fileType = fileTypeOf(docFile.name);
      const { data: inserted, error } = await supabase.from("document_templates").insert({
        firm_id: activeFirm.id, name, category, file_path: path, file_type: fileTypeOf(docFile.name),
        variables: [], created_by: user!.id, is_active: true,
      }).select("id").single();
      if (error) throw error;
      // Auto-detect variables for DOCX templates.
      if (fileType === "docx" && inserted?.id) {
        try {
          const res = await extractVarsFn({ data: { templateId: inserted.id } });
          return { detected: res.variables.length };
        } catch (e) {
          console.error(e);
          return { detected: 0 };
        }
      }
      return { detected: 0 };
    },
    onSuccess: (res) => {
      const n = (res as any)?.detected ?? 0;
      toast.success(n > 0 ? `Modèle importé · ${n} variable${n > 1 ? "s" : ""} détectée${n > 1 ? "s" : ""}` : "Modèle importé");
      qc.invalidateQueries({ queryKey: ["templates"] });
      setOpen(false); reset();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const archive = useMutation({
    mutationFn: async (t: any) => {
      const { error } = await supabase.from("document_templates").update({ is_active: !t.is_active }).eq("id", t.id);
      if (error) throw error;
    },
    onSuccess: (_d, t: any) => { toast.success(t.is_active ? "Modèle archivé" : "Modèle restauré"); qc.invalidateQueries({ queryKey: ["templates"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (t: { id: string; path: string | null }) => {
      if (t.path) await supabase.storage.from("templates").remove([t.path]);
      const { error } = await supabase.from("document_templates").delete().eq("id", t.id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Modèle supprimé"); qc.invalidateQueries({ queryKey: ["templates"] }); setConfirmDelete(null); },
    onError: (e: Error) => toast.error(e.message),
  });

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault(); setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) { setDocFile(f); if (!name) setName(f.name.replace(/\.[^.]+$/, "")); setOpen(true); }
  };

  return (
    <div>
      <PageHeader title="Documents & modèles" description="Importez vos modèles et générez des documents pour vos entreprises" action={
        <Button onClick={() => setOpen(true)}><Plus className="size-4 mr-1"/>Nouveau modèle</Button>
      }/>

      <div className="flex flex-wrap items-center gap-2 mb-4">
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-56"><SelectValue/></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes les catégories</SelectItem>
            {TEMPLATE_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button variant={showArchived ? "default" : "outline"} size="sm" onClick={() => setShowArchived(s => !s)}>
          {showArchived ? "Masquer archivés" : "Afficher archivés"}
        </Button>
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={`mb-6 rounded-xl border-2 border-dashed p-6 text-center text-sm transition ${dragOver ? "border-primary bg-primary/5" : "border-muted bg-muted/20"}`}
      >
        <Upload className="size-5 mx-auto mb-1 text-muted-foreground"/>
        Glissez-déposez un fichier ici (DOCX, PDF, PNG/JPG) ou <button className="text-primary underline ml-1" onClick={() => setOpen(true)}>cliquez pour importer</button>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={FileText} title="Aucun modèle" description="Importez votre premier modèle pour démarrer."/>
      ) : (
        <div className="space-y-6">
          {grouped.map(([cat, items]) => (
            <div key={cat}>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{cat}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {items.map((t: any) => (
                  <Card key={t.id} className={t.is_active === false ? "opacity-60" : ""}>
                    <CardContent className="p-5">
                      <div className="flex items-start gap-3">
                        <div className="size-10 rounded-lg bg-primary/10 text-primary grid place-items-center"><FileText className="size-5"/></div>
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold truncate">{t.name}</p>
                          <p className="text-xs text-muted-foreground">{t.category || "Sans catégorie"} · {(t.file_type ?? "—").toUpperCase()}</p>
                        </div>
                        {t.is_active === false && <Badge variant="outline">Archivé</Badge>}
                      </div>
                      {Array.isArray(t.variables) && t.variables.length > 0 && (
                        <div className="mt-3 flex flex-wrap gap-1">
                          {t.variables.slice(0, 6).map((v: string) => (
                            <span key={v} className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground font-mono">{`{{${v}}}`}</span>
                          ))}
                          {t.variables.length > 6 && <span className="text-[10px] text-muted-foreground">+{t.variables.length - 6}</span>}
                        </div>
                      )}
                      <div className="flex gap-1 mt-4">
                        <Button size="sm" variant="outline" onClick={() => setPreviewing(t)}><Eye className="size-3.5 mr-1"/>Détails</Button>
                        <Button size="sm" variant="ghost" onClick={() => archive.mutate(t)} title={t.is_active === false ? "Restaurer" : "Archiver"}>
                          {t.is_active === false ? <ArchiveRestore className="size-3.5"/> : <Archive className="size-3.5"/>}
                        </Button>
                        {isAdmin && (
                          <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => setConfirmDelete({ id: t.id, path: t.file_path })}>
                            <Trash2 className="size-3.5"/>
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Importer un modèle</DialogTitle>
            <DialogDescription>DOCX, PDF, PNG, JPG. Les variables au format <code>{`{{nom}}`}</code> sont détectées automatiquement dans les modèles DOCX.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Nom *</Label><Input value={name} onChange={e => setName(e.target.value)} placeholder="Lettre de mission 2025"/></div>
            <div>
              <Label>Catégorie</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  {TEMPLATE_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Fichier *</Label>
              <Input ref={fileRef} type="file" accept={ACCEPTED} onChange={e => setDocFile(e.target.files?.[0] ?? null)}/>
              {docFile && <p className="text-xs text-muted-foreground mt-1">{docFile.name} · {(docFile.size / 1024).toFixed(0)} Ko</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Annuler</Button>
            <Button onClick={() => create.mutate()} disabled={!name || !docFile || create.isPending}>
              <Upload className="size-4 mr-2"/>{create.isPending ? "Import…" : "Importer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!previewing} onOpenChange={(v) => !v && setPreviewing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{previewing?.name}</DialogTitle>
            <DialogDescription>{previewing?.category || "Sans catégorie"}</DialogDescription>
          </DialogHeader>
          {previewing && (
            <div className="space-y-3 text-sm">
              <div><span className="text-muted-foreground">Type :</span> {(previewing.file_type ?? "—").toUpperCase()}</div>
              <div><span className="text-muted-foreground">Créé le :</span> {new Date(previewing.created_at).toLocaleDateString("fr-FR")}</div>
              <div>
                <p className="text-muted-foreground mb-1">Variables disponibles :</p>
                {Array.isArray(previewing.variables) && previewing.variables.length > 0 ? (
                  <div className="flex flex-wrap gap-1">
                    {previewing.variables.map((v: string) => (
                      <span key={v} className="text-xs px-2 py-0.5 rounded bg-muted font-mono">{`{{${v}}}`}</span>
                    ))}
                  </div>
                ) : <p className="text-xs text-muted-foreground">Aucune variable.</p>}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(v) => !v && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce modèle ?</AlertDialogTitle>
            <AlertDialogDescription>Cette action est irréversible.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground" onClick={() => confirmDelete && remove.mutate(confirmDelete)}>Supprimer</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}