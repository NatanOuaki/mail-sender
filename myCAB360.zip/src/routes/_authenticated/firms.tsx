import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/use-auth";
import { useActiveFirm } from "@/lib/use-active-firm";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Building, Plus, Check, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/firms")({ component: FirmsPage });

type FirmForm = {
  name: string; address: string; postal_code: string; city: string;
  phone: string; email: string; website: string;
  siren: string; siret: string; share_capital: string; legal_form: string; vat_number: string;
  iban: string; bic: string; ics: string;
};
const EMPTY: FirmForm = {
  name: "", address: "", postal_code: "", city: "", phone: "", email: "", website: "",
  siren: "", siret: "", share_capital: "", legal_form: "", vat_number: "",
  iban: "", bic: "", ics: "",
};

function validate(f: FirmForm): string | null {
  if (!f.name.trim()) return "Le nom du cabinet est requis";
  if (f.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) return "Email invalide";
  if (f.siren && !/^\d{9}$/.test(f.siren.replace(/\s/g, ""))) return "Le SIREN doit contenir 9 chiffres";
  if (f.siret && !/^\d{14}$/.test(f.siret.replace(/\s/g, ""))) return "Le SIRET doit contenir 14 chiffres";
  if (f.iban) {
    const iban = f.iban.replace(/\s/g, "").toUpperCase();
    if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban)) return "IBAN invalide";
  }
  return null;
}

function Field({ label, value, onChange, type, placeholder }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string; }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      <Input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)} />
    </div>
  );
}

function FirmsPage() {
  const { user } = useAuth();
  const { firms, activeFirm, setActiveFirmId, refetch } = useActiveFirm();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<FirmForm>(EMPTY);
  const [confirmDelete, setConfirmDelete] = useState<{ id: string; name: string } | null>(null);
  const set = (k: keyof FirmForm) => (v: string) => setForm(prev => ({ ...prev, [k]: v }));

  const create = useMutation({
    mutationFn: async () => {
      const err = validate(form);
      if (err) throw new Error(err);
      const { data, error } = await supabase.rpc("create_firm", {
        firm_name: form.name,
        firm_siret: form.siret || undefined,
        firm_city: form.city || undefined,
        firm_address: form.address || undefined,
        firm_postal_code: form.postal_code || undefined,
        firm_phone: form.phone || undefined,
        firm_email: form.email || undefined,
        firm_website: form.website || undefined,
        firm_siren: form.siren || undefined,
        firm_legal_form: form.legal_form || undefined,
        firm_share_capital: form.share_capital || undefined,
        firm_vat_number: form.vat_number || undefined,
        firm_iban: form.iban || undefined,
        firm_bic: form.bic || undefined,
        firm_ics: form.ics || undefined,
      });
      if (error) throw error;
      return data as { id: string };
    },
    onSuccess: (d) => {
      toast.success("Cabinet créé");
      qc.invalidateQueries({ queryKey: ["firms"] });
      refetch();
      setActiveFirmId(d.id);
      setOpen(false); setForm(EMPTY);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.rpc("delete_firm", { firm_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Cabinet supprimé");
      qc.invalidateQueries({ queryKey: ["firms"] });
      refetch();
      setConfirmDelete(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div>
      <PageHeader title="Cabinets" description="Gérez tous vos cabinets depuis un seul compte"
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="size-4 mr-1"/>Nouveau cabinet</Button></DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>Créer un cabinet</DialogTitle></DialogHeader>
              <div className="space-y-6">
                <div className="space-y-3">
                  <p className="text-sm font-semibold">Infos Cabinet</p>
                  <Field label="Nom du cabinet *" value={form.name} onChange={set("name")} placeholder="Cabinet Dupont"/>
                  <Field label="Adresse" value={form.address} onChange={set("address")} />
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Code postal" value={form.postal_code} onChange={set("postal_code")} />
                    <Field label="Ville" value={form.city} onChange={set("city")} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Téléphone" value={form.phone} onChange={set("phone")} />
                    <Field label="Email" type="email" value={form.email} onChange={set("email")} />
                  </div>
                  <Field label="Site web" value={form.website} onChange={set("website")} placeholder="https://" />
                </div>
                <div className="space-y-3">
                  <p className="text-sm font-semibold">Juridique</p>
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="SIREN" value={form.siren} onChange={set("siren")} />
                    <Field label="SIRET" value={form.siret} onChange={set("siret")} />
                  </div>
                  <Field label="Capital social" value={form.share_capital} onChange={set("share_capital")} />
                  <Field label="Forme juridique" value={form.legal_form} onChange={set("legal_form")} placeholder="SARL, SAS, EURL…" />
                  <Field label="Numéro de TVA" value={form.vat_number} onChange={set("vat_number")} />
                </div>
                <div className="space-y-3">
                  <p className="text-sm font-semibold">Coordonnées bancaires</p>
                  <Field label="IBAN" value={form.iban} onChange={set("iban")} />
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="BIC" value={form.bic} onChange={set("bic")} />
                    <Field label="Numéro ICS" value={form.ics} onChange={set("ics")} />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={() => create.mutate()} disabled={!form.name || create.isPending}>Créer</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {firms.map(f => (
          <Card key={f.id} className={`group relative transition ${activeFirm?.id === f.id ? 'ring-2 ring-primary' : 'hover:border-primary/50'}`}>
            <CardContent className="p-5 cursor-pointer" onClick={() => setActiveFirmId(f.id)}>
              <div className="flex items-start justify-between">
                <div className="size-10 rounded-lg bg-primary/10 text-primary grid place-items-center"><Building className="size-5"/></div>
                <div className="flex items-center gap-2">
                  {activeFirm?.id === f.id && <span className="text-xs font-medium text-primary flex items-center gap-1"><Check className="size-3"/>Actif</span>}
                  {f.owner_id === user?.id && (
                    <Button variant="ghost" size="icon" className="size-7 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"
                      onClick={(e) => { e.stopPropagation(); setConfirmDelete({ id: f.id, name: f.name }); }}>
                      <Trash2 className="size-3.5"/>
                    </Button>
                  )}
                </div>
              </div>
              <p className="font-semibold mt-3">{f.name}</p>
              <p className="text-xs text-muted-foreground mt-1">Cabinet · {f.owner_id === user?.id ? "Propriétaire" : "Membre"}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <AlertDialog open={!!confirmDelete} onOpenChange={(v) => !v && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce cabinet ?</AlertDialogTitle>
            <AlertDialogDescription>
              Vous êtes sur le point de supprimer <strong>{confirmDelete?.name}</strong>. Cette action est irréversible. La suppression est refusée si le cabinet contient des clients ou entreprises.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={(e) => { e.preventDefault(); if (confirmDelete) del.mutate(confirmDelete.id); }}
              disabled={del.isPending}
            >Supprimer</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}