import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useActiveFirm } from "@/lib/use-active-firm";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/settings")({ component: SettingsPage });

type FirmForm = {
  name: string; address: string; postal_code: string; city: string;
  phone: string; email: string; website: string;
  siren: string; siret: string; share_capital: string; legal_form: string; vat_number: string;
  iban: string; bic: string; ics: string;
};

const EMPTY: FirmForm = {
  name: "", address: "", postal_code: "", city: "", phone: "", email: "", website: "",
  siren: "", siret: "", share_capital: "", legal_form: "", vat_number: "",
  iban: "", bic: "", ics: "",
};

function validate(f: FirmForm): string | null {
  if (!f.name.trim()) return "Le nom du cabinet est requis";
  if (f.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) return "Email invalide";
  if (f.siren && !/^\d{9}$/.test(f.siren.replace(/\s/g, ""))) return "Le SIREN doit contenir 9 chiffres";
  if (f.siret && !/^\d{14}$/.test(f.siret.replace(/\s/g, ""))) return "Le SIRET doit contenir 14 chiffres";
  if (f.iban) {
    const iban = f.iban.replace(/\s/g, "").toUpperCase();
    if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban)) return "IBAN invalide";
  }
  return null;
}

function Field({ label, value, onChange, type, placeholder }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string; }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      <Input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)} />
    </div>
  );
}

function FirmGeneralForm({ form, setForm, onSave, saving }: { form: FirmForm; setForm: (f: FirmForm) => void; onSave: () => void; saving: boolean; }) {
  const set = (k: keyof FirmForm) => (v: string) => setForm({ ...form, [k]: v });
  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pb-24 md:pb-0">
        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Infos Cabinet</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <Field label="Nom du cabinet *" value={form.name} onChange={set("name")} />
            <Field label="Adresse" value={form.address} onChange={set("address")} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Code postal" value={form.postal_code} onChange={set("postal_code")} />
              <Field label="Ville" value={form.city} onChange={set("city")} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Téléphone" value={form.phone} onChange={set("phone")} />
              <Field label="Email" type="email" value={form.email} onChange={set("email")} />
            </div>
            <Field label="Site web" value={form.website} onChange={set("website")} placeholder="https://" />
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Juridique</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Field label="SIREN" value={form.siren} onChange={set("siren")} />
              <Field label="SIRET" value={form.siret} onChange={set("siret")} />
            </div>
            <Field label="Capital social" value={form.share_capital} onChange={set("share_capital")} />
            <Field label="Forme juridique" value={form.legal_form} onChange={set("legal_form")} placeholder="SARL, SAS, EURL…" />
            <Field label="Numéro de TVA" value={form.vat_number} onChange={set("vat_number")} />
          </CardContent>
        </Card>
        <Card className="rounded-2xl lg:col-span-2">
          <CardHeader><CardTitle className="text-base">Coordonnées bancaires</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <Field label="IBAN" value={form.iban} onChange={set("iban")} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="BIC" value={form.bic} onChange={set("bic")} />
              <Field label="Numéro ICS" value={form.ics} onChange={set("ics")} />
            </div>
          </CardContent>
        </Card>
        <div className="hidden md:flex lg:col-span-2 justify-end">
          <Button onClick={onSave} disabled={saving}>Enregistrer</Button>
        </div>
      </div>
      <div className="md:hidden fixed bottom-0 inset-x-0 p-4 bg-background border-t z-40">
        <Button className="w-full" onClick={onSave} disabled={saving}>Enregistrer</Button>
      </div>
    </>
  );
}

function SettingsPage() {
  const { activeFirm, refetch } = useActiveFirm();
  const qc = useQueryClient();
  const [form, setForm] = useState<FirmForm>(EMPTY);

  useEffect(() => {
    if (!activeFirm) return;
    supabase.from("firms").select("*").eq("id", activeFirm.id).single().then(({ data }) => {
      if (data) setForm({
        name: data.name ?? "", address: data.address ?? "", postal_code: data.postal_code ?? "",
        city: data.city ?? "", phone: data.phone ?? "", email: data.email ?? "", website: data.website ?? "",
        siren: data.siren ?? "", siret: data.siret ?? "", share_capital: data.share_capital ?? "",
        legal_form: data.legal_form ?? "", vat_number: data.vat_number ?? "",
        iban: "", bic: "", ics: "",
      });
    });
    // Banking fields are stored separately and only readable by owner/admin
    supabase.from("firm_banking").select("iban,bic,ics").eq("firm_id", activeFirm.id).maybeSingle().then(({ data }) => {
      if (data) setForm(f => ({ ...f, iban: data.iban ?? "", bic: data.bic ?? "", ics: data.ics ?? "" }));
    });
  }, [activeFirm?.id]);

  const save = useMutation({
    mutationFn: async () => {
      const err = validate(form);
      if (err) throw new Error(err);
      const { iban, bic, ics, ...firmFields } = form;
      const { error } = await supabase.from("firms").update(firmFields).eq("id", activeFirm!.id);
      if (error) throw error;
      const { error: bErr } = await supabase.from("firm_banking").upsert({
        firm_id: activeFirm!.id,
        iban: iban || null,
        bic: bic || null,
        ics: ics || null,
      }, { onConflict: "firm_id" });
      if (bErr && bErr.code !== "42501") throw bErr; // ignore permission denied for non-admin viewers
    },
    onSuccess: () => { toast.success("Cabinet mis à jour"); refetch(); qc.invalidateQueries({ queryKey: ["firms"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const { data: members = [] } = useQuery({
    queryKey: ["members", activeFirm?.id], enabled: !!activeFirm,
    queryFn: async () => {
      const { data, error } = await supabase.from("firm_members").select("*").eq("firm_id", activeFirm!.id);
      if (error) throw error; return data;
    },
  });

  const { data: apiKeys = [] } = useQuery({
    queryKey: ["apikeys", activeFirm?.id], enabled: !!activeFirm,
    queryFn: async () => {
      const { data, error } = await supabase.from("api_keys").select("*").eq("firm_id", activeFirm!.id);
      if (error) return []; return data;
    },
  });

  const { data: logs = [] } = useQuery({
    queryKey: ["logs", activeFirm?.id], enabled: !!activeFirm,
    queryFn: async () => {
      const { data, error } = await supabase.from("audit_logs").select("*").eq("firm_id", activeFirm!.id).order("created_at", { ascending: false }).limit(20);
      if (error) return []; return data;
    },
  });

  return (
    <div>
      <PageHeader title="Paramètres" description={activeFirm?.name}/>
      <Tabs defaultValue="general">
        <TabsList>
          <TabsTrigger value="general">Général</TabsTrigger>
          <TabsTrigger value="members">Utilisateurs</TabsTrigger>
          <TabsTrigger value="api">Clés API</TabsTrigger>
          <TabsTrigger value="audit">Journal</TabsTrigger>
        </TabsList>
        <TabsContent value="general">
          <FirmGeneralForm form={form} setForm={setForm} onSave={() => save.mutate()} saving={save.isPending} />
        </TabsContent>
        <TabsContent value="members">
          <Card><CardHeader><CardTitle className="text-base">Utilisateurs & rôles</CardTitle></CardHeader>
            <CardContent>
              {members.length === 0 ? <p className="text-sm text-muted-foreground">Aucun membre.</p> : (
                <div className="divide-y">
                  {members.map((m: any) => (
                    <div key={m.id} className="flex items-center justify-between py-3">
                      <p className="text-sm font-mono text-muted-foreground">{m.user_id.slice(0,8)}…</p>
                      <Badge>{m.role}</Badge>
                    </div>
                  ))}
                </div>
              )}
              <p className="text-xs text-muted-foreground mt-4">L'invitation par email sera disponible prochainement.</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="api">
          <Card><CardHeader><CardTitle className="text-base">Clés API</CardTitle></CardHeader>
            <CardContent>
              {apiKeys.length === 0 ? <p className="text-sm text-muted-foreground">Aucune clé API générée.</p> : (
                <div className="divide-y">{apiKeys.map((k: any) => (
                  <div key={k.id} className="flex items-center justify-between py-3">
                    <div><p className="font-medium text-sm">{k.name}</p><p className="text-xs text-muted-foreground font-mono">{k.key_prefix}…</p></div>
                  </div>
                ))}</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="audit">
          <Card><CardHeader><CardTitle className="text-base">Journal d'activité</CardTitle></CardHeader>
            <CardContent>
              {logs.length === 0 ? <p className="text-sm text-muted-foreground">Aucune entrée.</p> : (
                <div className="divide-y text-sm">{logs.map((l: any) => (
                  <div key={l.id} className="py-2 flex justify-between">
                    <span>{l.action} {l.entity_type && <span className="text-muted-foreground">· {l.entity_type}</span>}</span>
                    <span className="text-xs text-muted-foreground">{new Date(l.created_at).toLocaleString("fr-FR")}</span>
                  </div>
                ))}</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}