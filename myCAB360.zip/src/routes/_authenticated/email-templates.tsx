import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { useActiveFirm } from "@/lib/use-active-firm";
import { PageHeader } from "@/components/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  listEmailTemplates, saveEmailTemplate, resetEmailTemplate, previewEmailTemplate,
} from "@/lib/emails.functions";

export const Route = createFileRoute("/_authenticated/email-templates")({ component: EmailTemplatesPage });

const TEMPLATE_LABELS: Record<string, string> = {
  signature_send: "Envoi de signature",
  signature_reminder: "Rappel de signature",
  signature_completed: "Signature complétée",
  signature_expired: "Signature expirée",
  document_shared: "Document partagé",
};

const VARIABLES = [
  "firm_name", "company_name", "signer_firstname", "signer_lastname",
  "document_name", "signature_link", "expiration_date", "portal_link",
];

function EmailTemplatesPage() {
  const { activeFirm } = useActiveFirm();
  const qc = useQueryClient();
  const listFn = useServerFn(listEmailTemplates);
  const saveFn = useServerFn(saveEmailTemplate);
  const resetFn = useServerFn(resetEmailTemplate);
  const previewFn = useServerFn(previewEmailTemplate);

  const { data } = useQuery({
    queryKey: ["email-templates", activeFirm?.id], enabled: !!activeFirm,
    queryFn: () => listFn({ data: { firmId: activeFirm!.id } }),
  });
  const templates = data?.templates ?? [];
  const [active, setActive] = useState<string>("signature_send");
  const current: any = templates.find((t: any) => t.template_key === active);
  const [form, setForm] = useState({ subject: "", body_html: "", body_text: "" });
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewHtml, setPreviewHtml] = useState("");
  const [previewSubject, setPreviewSubject] = useState("");

  useEffect(() => {
    if (current) setForm({
      subject: current.subject ?? "", body_html: current.body_html ?? "", body_text: current.body_text ?? "",
    });
  }, [current?.template_key, current?.id]);

  const save = useMutation({
    mutationFn: () => saveFn({ data: {
      firmId: activeFirm!.id, templateKey: active,
      subject: form.subject, body_html: form.body_html, body_text: form.body_text,
    } }),
    onSuccess: () => { toast.success("Modèle enregistré"); qc.invalidateQueries({ queryKey: ["email-templates"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const reset = useMutation({
    mutationFn: () => resetFn({ data: { firmId: activeFirm!.id, templateKey: active } }),
    onSuccess: () => { toast.success("Modèle réinitialisé"); qc.invalidateQueries({ queryKey: ["email-templates"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const preview = useMutation({
    mutationFn: () => previewFn({ data: { firmId: activeFirm!.id, templateKey: active } }),
    onSuccess: (r) => { setPreviewHtml(r.body_html); setPreviewSubject(r.subject); setPreviewOpen(true); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div>
      <PageHeader title="Modèles d'emails" description="Personnalisez les emails envoyés à vos clients"/>
      <Tabs value={active} onValueChange={setActive}>
        <TabsList className="flex-wrap h-auto">
          {Object.keys(TEMPLATE_LABELS).map(k => <TabsTrigger key={k} value={k}>{TEMPLATE_LABELS[k]}</TabsTrigger>)}
        </TabsList>
        {Object.keys(TEMPLATE_LABELS).map(k => (
          <TabsContent key={k} value={k}>
            <Card>
              <CardContent className="p-5 space-y-3">
                <div>
                  <Label className="text-xs">Sujet</Label>
                  <Input value={form.subject} onChange={e => setForm({...form, subject: e.target.value})}/>
                </div>
                <div>
                  <Label className="text-xs">HTML</Label>
                  <Textarea rows={14} className="font-mono text-xs" value={form.body_html} onChange={e => setForm({...form, body_html: e.target.value})}/>
                </div>
                <div>
                  <Label className="text-xs">Texte (optionnel)</Label>
                  <Textarea rows={4} value={form.body_text} onChange={e => setForm({...form, body_text: e.target.value})}/>
                </div>
                <div className="text-xs text-muted-foreground">
                  Variables : {VARIABLES.map(v => <code key={v} className="mx-1 px-1.5 py-0.5 bg-muted rounded">{`{{${v}}}`}</code>)}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => save.mutate()} disabled={save.isPending}>Enregistrer</Button>
                  <Button size="sm" variant="outline" onClick={() => preview.mutate()}>Aperçu</Button>
                  {!current?._is_default && (
                    <Button size="sm" variant="ghost" className="text-destructive" onClick={() => reset.mutate()}>Réinitialiser</Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>{previewSubject}</DialogTitle></DialogHeader>
          <div className="border rounded p-3 bg-white" dangerouslySetInnerHTML={{ __html: previewHtml }}/>
        </DialogContent>
      </Dialog>
    </div>
  );
}