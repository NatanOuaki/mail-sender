import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { MessageCircle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/whatsapp")({ component: () => (
  <div>
    <PageHeader title="Whatsapp" description="Conversations Whatsapp Business"/>
    <EmptyState icon={MessageCircle} title="Bientôt disponible" description="L'intégration Whatsapp arrive prochainement."/>
  </div>
) });