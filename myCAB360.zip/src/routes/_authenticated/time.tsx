import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { Clock } from "lucide-react";

export const Route = createFileRoute("/_authenticated/time")({ component: () => (
  <div>
    <PageHeader title="Temps" description="Suivi du temps passé"/>
    <EmptyState icon={Clock} title="Bientôt disponible" description="Le suivi du temps arrive prochainement."/>
  </div>
) });