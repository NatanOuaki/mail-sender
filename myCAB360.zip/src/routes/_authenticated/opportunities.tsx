import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { Target } from "lucide-react";

export const Route = createFileRoute("/_authenticated/opportunities")({ component: () => (
  <div>
    <PageHeader title="Opportunités" description="Pipeline commercial"/>
    <EmptyState icon={Target} title="Bientôt disponible" description="Le pipeline d'opportunités arrive prochainement."/>
  </div>
) });