import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useActiveFirm } from "@/lib/use-active-firm";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Building2, Plus, Search, Pencil, Sparkles, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { searchPappers, getPappersCompany, getPappersStatus } from "@/lib/pappers.functions";
import { CompanyDocumentsTab } from "@/components/company-documents-tab";
import { CompanySignaturesTab } from "@/components/company-signatures-tab";

export const Route = createFileRoute("/_authenticated/companies")({ component: CompaniesPage });

const STATUSES = [
  { value: "prospect", label: "Prospect", color: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300" },
  {
    value: "client",
    label: "Client",
    color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300",
  },
  {
    value: "ancien_client",
    label: "Ancien client",
    color: "bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300",
  },
  { value: "lead", label: "Lead", color: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300" },
  {
    value: "suspendu",
    label: "Suspendu",
    color: "bg-orange-100 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300",
  },
  { value: "archive", label: "Archivé", color: "bg-muted text-muted-foreground" },
] as const;

const TAX_REGIMES = ["IS RN", "IS RS", "BIC RN", "BIC RS", "BNC", "RF", "Association"];
const VAT_REGIMES = ["RN Mensuel", "RN Trimestriel", "RS", "Exo"];
const PERIODICITES = ["Mensuelle", "Trimestrielle", "Annuelle"];
const CIVILITES = ["M.", "Mme", "Mlle"];
const SOFTWARES = ["Pennylane", "Tiime", "Dext", "ACD Isuite"];

type CompanyForm = {
  // Société
  name: string;
  firm_id: string;
  status: string;
  address: string;
  postal_code: string;
  city: string;
  // Responsable légal
  rep_civility: string;
  rep_first_name: string;
  rep_last_name: string;
  rep_email: string;
  rep_phone: string;
  // Juridique
  siren: string;
  siret: string;
  share_capital: string;
  legal_form: string;
  vat_number: string;
  activity: string;
  creation_date: string;
  takeover_date: string;
  first_closing_date: string;
  tax_regime: string;
  vat_regime: string;
  headcount: string;
  takeover_colleague: string;
  ldm_date: string;
  sepa_mandate: boolean;
  lmnp_sci: string;
  // Honoraires
  fees_accounting: string;
  fees_periodicity: string;
  fees_balance: string;
  fees_legal: string;
  fees_payroll: string;
  payslips_count: string;
  software_provided: string;
  fees_software: string;
  observations: string;
};

const emptyForm = (firmId: string): CompanyForm => ({
  name: "",
  firm_id: firmId,
  status: "prospect",
  address: "",
  postal_code: "",
  city: "",
  rep_civility: "",
  rep_first_name: "",
  rep_last_name: "",
  rep_email: "",
  rep_phone: "",
  siren: "",
  siret: "",
  share_capital: "",
  legal_form: "",
  vat_number: "",
  activity: "",
  creation_date: "",
  takeover_date: "",
  first_closing_date: "",
  tax_regime: "",
  vat_regime: "",
  headcount: "",
  takeover_colleague: "",
  ldm_date: "",
  sepa_mandate: false,
  lmnp_sci: "",
  fees_accounting: "",
  fees_periodicity: "",
  fees_balance: "",
  fees_legal: "",
  fees_payroll: "",
  payslips_count: "",
  software_provided: "",
  fees_software: "",
  observations: "",
});

function fromRecord(c: any, firmId: string): CompanyForm {
  const f = emptyForm(firmId);
  for (const k of Object.keys(f) as (keyof CompanyForm)[]) {
    const v = c[k];
    if (v === null || v === undefined) continue;
    (f as any)[k] = typeof v === "boolean" ? v : String(v);
  }
  return f;
}

function toPayload(f: CompanyForm) {
  const num = (s: string) => (s.trim() === "" ? null : Number(s));
  const int = (s: string) => (s.trim() === "" ? null : parseInt(s, 10));
  const txt = (s: string) => (s.trim() === "" ? null : s.trim());
  const date = (s: string) => (s.trim() === "" ? null : s);
  return {
    firm_id: f.firm_id,
    name: f.name.trim(),
    status: f.status,
    address: txt(f.address),
    postal_code: txt(f.postal_code),
    city: txt(f.city),
    rep_civility: txt(f.rep_civility),
    rep_first_name: txt(f.rep_first_name),
    rep_last_name: txt(f.rep_last_name),
    rep_email: txt(f.rep_email),
    rep_phone: txt(f.rep_phone),
    siren: txt(f.siren),
    siret: txt(f.siret),
    share_capital: num(f.share_capital),
    legal_form: txt(f.legal_form),
    vat_number: txt(f.vat_number),
    activity: txt(f.activity),
    creation_date: date(f.creation_date),
    takeover_date: date(f.takeover_date),
    first_closing_date: date(f.first_closing_date),
    tax_regime: txt(f.tax_regime),
    vat_regime: txt(f.vat_regime),
    headcount: int(f.headcount),
    takeover_colleague: txt(f.takeover_colleague),
    ldm_date: date(f.ldm_date),
    sepa_mandate: f.sepa_mandate,
    lmnp_sci: txt(f.lmnp_sci),
    fees_accounting: num(f.fees_accounting),
    fees_periodicity: txt(f.fees_periodicity),
    fees_balance: num(f.fees_balance),
    fees_legal: num(f.fees_legal),
    fees_payroll: num(f.fees_payroll),
    payslips_count: int(f.payslips_count),
    software_provided: txt(f.software_provided),
    fees_software: num(f.fees_software),
    observations: txt(f.observations),
  };
}

function StatusBadge({ status }: { status: string }) {
  const s = STATUSES.find((x) => x.value === status) ?? STATUSES[0];
  return <Badge className={`${s.color} font-medium border-0`}>{s.label}</Badge>;
}

function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function CompaniesPage() {
  const { activeFirm, firms } = useActiveFirm();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<CompanyForm>(() => emptyForm(activeFirm?.id ?? ""));
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [firmFilter, setFirmFilter] = useState<string>("all");
  const [cityFilter, setCityFilter] = useState<string>("");
  const [taxFilter, setTaxFilter] = useState<string>("all");

  // Pappers search modal state
  const searchFn = useServerFn(searchPappers);
  const detailFn = useServerFn(getPappersCompany);
  const statusFn = useServerFn(getPappersStatus);
  const [pappersOpen, setPappersOpen] = useState(false);
  const [pappersQuery, setPappersQuery] = useState("");
  const [pappersResults, setPappersResults] = useState<any[] | null>(null);
  const [pappersLoading, setPappersLoading] = useState(false);
  const [pappersImporting, setPappersImporting] = useState<string | null>(null);

  const { data: pappersStatus } = useQuery({
    queryKey: ["pappers-status", activeFirm?.id],
    enabled: !!activeFirm,
    queryFn: () => statusFn({ data: { firmId: activeFirm!.id } }),
  });

  const { data: companies = [], isLoading } = useQuery({
    queryKey: ["companies", activeFirm?.id],
    enabled: !!activeFirm,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("companies")
        .select("*")
        .eq("firm_id", activeFirm!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as any[];
    },
  });

  const firmsById = useMemo(() => Object.fromEntries(firms.map((f) => [f.id, f.name])), [firms]);

  const upsert = useMutation({
    mutationFn: async () => {
      if (!form.name.trim()) throw new Error("Le nom de la société est requis");
      if (!form.firm_id) throw new Error("Le cabinet est requis");
      if (form.siren && !/^\d{9}$/.test(form.siren.replace(/\s/g, ""))) throw new Error("SIREN invalide (9 chiffres)");
      if (form.siret && !/^\d{14}$/.test(form.siret.replace(/\s/g, "")))
        throw new Error("SIRET invalide (14 chiffres)");
      if (form.rep_email && !/^\S+@\S+\.\S+$/.test(form.rep_email)) throw new Error("Email du responsable invalide");
      const payload = toPayload(form);
      if (editingId) {
        const { error } = await supabase
          .from("companies")
          .update(payload as any)
          .eq("id", editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("companies").insert(payload as any);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(editingId ? "Entreprise mise à jour" : "Entreprise créée");
      qc.invalidateQueries({ queryKey: ["companies"] });
      setOpen(false);
      setEditingId(null);
      setForm(emptyForm(activeFirm?.id ?? ""));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm(activeFirm?.id ?? ""));
    setOpen(true);
  };
  const openEdit = (c: any) => {
    setEditingId(c.id);
    setForm(fromRecord(c, c.firm_id));
    setOpen(true);
  };

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return companies.filter((c: any) => {
      if (statusFilter !== "all" && c.status !== statusFilter) return false;
      if (firmFilter !== "all" && c.firm_id !== firmFilter) return false;
      if (cityFilter && !(c.city ?? "").toLowerCase().includes(cityFilter.toLowerCase())) return false;
      if (taxFilter !== "all" && c.tax_regime !== taxFilter) return false;
      if (!q) return true;
      const rep = `${c.rep_first_name ?? ""} ${c.rep_last_name ?? ""}`.toLowerCase();
      return [c.name, c.siren, c.siret, rep].some((v) => (v ?? "").toString().toLowerCase().includes(q));
    });
  }, [companies, search, statusFilter, firmFilter, cityFilter, taxFilter]);

  const set = <K extends keyof CompanyForm>(k: K, v: CompanyForm[K]) => setForm((prev) => ({ ...prev, [k]: v }));

  const runPappersSearch = async () => {
    if (!activeFirm || !pappersQuery.trim()) return;
    setPappersLoading(true);
    try {
      const r = await searchFn({ data: { firmId: activeFirm.id, query: pappersQuery.trim() } });
      setPappersResults(r.results);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setPappersLoading(false);
    }
  };

  const importFromPappers = async (siren: string) => {
    if (!activeFirm) return;
    setPappersImporting(siren);
    try {
      const c = await detailFn({ data: { firmId: activeFirm.id, siren } });
      // Duplicate check
      const dup = companies.find((x: any) => x.siren === c.siren);
      if (dup) {
        toast.warning(
          `SIREN déjà existant : "${dup.name}". Le formulaire est pré-rempli, vérifiez avant d'enregistrer.`,
        );
      }
      const f = emptyForm(activeFirm.id);
      f.name = c.name || "";
      f.siren = c.siren ?? "";
      f.siret = c.siret ?? "";
      f.address = c.address ?? "";
      f.postal_code = c.postal_code ?? "";
      f.city = c.city ?? "";
      f.legal_form = c.legal_form ?? "";
      f.activity = c.activity ?? "";
      f.creation_date = c.creation_date ?? "";
      f.share_capital = c.share_capital != null ? String(c.share_capital) : "";
      f.vat_number = c.vat_number ?? "";
      f.headcount = c.headcount != null ? String(c.headcount) : "";
      const firstRep = c.representatives?.[0];
      if (firstRep?.name) {
        const parts = firstRep.name.split(" ");
        f.rep_first_name = parts[0] ?? "";
        f.rep_last_name = parts.slice(1).join(" ") ?? "";
      }
      if (dup) {
        f.observations = `Représentants Pappers : ${(c.representatives ?? []).map((r: any) => r.name + (r.role ? ` (${r.role})` : "")).join(", ")}`;
      }
      setEditingId(dup ? dup.id : null);
      setForm(f);
      setPappersOpen(false);
      setOpen(true);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setPappersImporting(null);
    }
  };

  return (
    <div>
      <PageHeader
        title="Entreprises"
        description="Toutes les sociétés gérées par votre cabinet"
        action={
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setPappersOpen(true);
                setPappersResults(null);
                setPappersQuery("");
              }}
            >
              <Sparkles className="size-4 mr-1" />
              Recherche Pappers
            </Button>
            <Button onClick={openCreate}>
              <Plus className="size-4 mr-1" />
              Nouvelle entreprise
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <Card className="mb-4 border-border bg-card">
        <CardContent className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="relative lg:col-span-2">
            <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher (nom, SIREN, SIRET, responsable)"
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous statuts</SelectItem>
              {STATUSES.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={firmFilter} onValueChange={setFirmFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Cabinet" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous cabinets</SelectItem>
              {firms.map((f) => (
                <SelectItem key={f.id} value={f.id}>
                  {f.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={taxFilter} onValueChange={setTaxFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Régime fiscal" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous régimes</SelectItem>
              {TAX_REGIMES.map((r) => (
                <SelectItem key={r} value={r}>
                  {r}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            placeholder="Ville"
            className="md:col-span-2 lg:col-span-1"
          />
        </CardContent>
      </Card>

      {/* List */}
      {isLoading ? (
        <div className="text-sm text-muted-foreground py-12 text-center">Chargement…</div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="Aucune entreprise"
          description={companies.length ? "Aucun résultat avec ces filtres." : "Créez votre première entreprise."}
          action={
            !companies.length ? (
              <Button onClick={openCreate}>
                <Plus className="size-4 mr-1" />
                Nouvelle entreprise
              </Button>
            ) : undefined
          }
        />
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden md:block border-border bg-card">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="pl-4">Nom</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead>SIREN</TableHead>
                    <TableHead>Ville</TableHead>
                    <TableHead>Responsable</TableHead>
                    <TableHead>Cabinet</TableHead>
                    <TableHead>Créé le</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((c: any) => (
                    <TableRow key={c.id} className="cursor-pointer" onClick={() => openEdit(c)}>
                      <TableCell className="pl-4 font-medium">{c.name}</TableCell>
                      <TableCell>
                        <StatusBadge status={c.status} />
                      </TableCell>
                      <TableCell className="text-muted-foreground">{c.siren || "—"}</TableCell>
                      <TableCell className="text-muted-foreground">{c.city || "—"}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {[c.rep_first_name, c.rep_last_name].filter(Boolean).join(" ") || "—"}
                      </TableCell>
                      <TableCell className="text-muted-foreground">{firmsById[c.firm_id] || "—"}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {new Date(c.created_at).toLocaleDateString("fr-FR")}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            openEdit(c);
                          }}
                        >
                          <Pencil className="size-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Mobile cards */}
          <div className="md:hidden space-y-3">
            {filtered.map((c: any) => (
              <Card key={c.id} className="border-border bg-card cursor-pointer" onClick={() => openEdit(c)}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-semibold truncate">{c.name}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {[c.legal_form, c.city].filter(Boolean).join(" · ") || "—"}
                      </p>
                    </div>
                    <StatusBadge status={c.status} />
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                    <div>SIREN: {c.siren || "—"}</div>
                    <div className="truncate">
                      Resp.: {[c.rep_first_name, c.rep_last_name].filter(Boolean).join(" ") || "—"}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}

      {/* Create/Edit dialog */}
      <Dialog
        open={open}
        onOpenChange={(v) => {
          setOpen(v);
          if (!v) {
            setEditingId(null);
          }
        }}
      >
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto p-0">
          <DialogHeader className="px-6 pt-6">
            <DialogTitle>{editingId ? "Modifier l'entreprise" : "Nouvelle entreprise"}</DialogTitle>
            <DialogDescription>Renseignez les informations de la société.</DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="societe" className="px-6 pb-24 md:pb-6">
            <TabsList className={`grid ${editingId ? "grid-cols-6" : "grid-cols-4"} w-full`}>
              <TabsTrigger value="societe">Société</TabsTrigger>
              <TabsTrigger value="responsable">Responsable</TabsTrigger>
              <TabsTrigger value="juridique">Juridique</TabsTrigger>
              <TabsTrigger value="honoraires">Honoraires</TabsTrigger>
              {editingId && <TabsTrigger value="documents">Documents</TabsTrigger>}
              {editingId && <TabsTrigger value="signatures">Signatures</TabsTrigger>}
            </TabsList>

            {/* Société */}
            <TabsContent value="societe" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Nom de la société *" className="md:col-span-2">
                  <Input value={form.name} onChange={(e) => set("name", e.target.value)} />
                </Field>
                <Field label="Cabinet *">
                  <Select value={form.firm_id} onValueChange={(v) => set("firm_id", v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner" />
                    </SelectTrigger>
                    <SelectContent>
                      {firms.map((f) => (
                        <SelectItem key={f.id} value={f.id}>
                          {f.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Statut">
                  <Select value={form.status} onValueChange={(v) => set("status", v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUSES.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Adresse" className="md:col-span-2">
                  <Input value={form.address} onChange={(e) => set("address", e.target.value)} />
                </Field>
                <Field label="Code postal">
                  <Input value={form.postal_code} onChange={(e) => set("postal_code", e.target.value)} />
                </Field>
                <Field label="Ville">
                  <Input value={form.city} onChange={(e) => set("city", e.target.value)} />
                </Field>
              </div>
            </TabsContent>

            {/* Responsable */}
            <TabsContent value="responsable" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Civilité">
                  <Select value={form.rep_civility} onValueChange={(v) => set("rep_civility", v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="—" />
                    </SelectTrigger>
                    <SelectContent>
                      {CIVILITES.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <div />
                <Field label="Prénom">
                  <Input value={form.rep_first_name} onChange={(e) => set("rep_first_name", e.target.value)} />
                </Field>
                <Field label="Nom">
                  <Input value={form.rep_last_name} onChange={(e) => set("rep_last_name", e.target.value)} />
                </Field>
                <Field label="Email">
                  <Input type="email" value={form.rep_email} onChange={(e) => set("rep_email", e.target.value)} />
                </Field>
                <Field label="Téléphone">
                  <Input value={form.rep_phone} onChange={(e) => set("rep_phone", e.target.value)} />
                </Field>
              </div>
            </TabsContent>

            {/* Juridique */}
            <TabsContent value="juridique" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="SIREN">
                  <Input value={form.siren} onChange={(e) => set("siren", e.target.value)} maxLength={9} />
                </Field>
                <Field label="SIRET">
                  <Input value={form.siret} onChange={(e) => set("siret", e.target.value)} maxLength={14} />
                </Field>
                <Field label="Capital social (€)">
                  <Input
                    type="number"
                    value={form.share_capital}
                    onChange={(e) => set("share_capital", e.target.value)}
                  />
                </Field>
                <Field label="Forme juridique">
                  <Input
                    value={form.legal_form}
                    onChange={(e) => set("legal_form", e.target.value)}
                    placeholder="SAS, SARL…"
                  />
                </Field>
                <Field label="Numéro de TVA">
                  <Input value={form.vat_number} onChange={(e) => set("vat_number", e.target.value)} />
                </Field>
                <Field label="Activité">
                  <Input value={form.activity} onChange={(e) => set("activity", e.target.value)} />
                </Field>
                <Field label="Date création entreprise">
                  <Input
                    type="date"
                    value={form.creation_date}
                    onChange={(e) => set("creation_date", e.target.value)}
                  />
                </Field>
                <Field label="Date de reprise du dossier">
                  <Input
                    type="date"
                    value={form.takeover_date}
                    onChange={(e) => set("takeover_date", e.target.value)}
                  />
                </Field>
                <Field label="Date 1ère clôture cabinet">
                  <Input
                    type="date"
                    value={form.first_closing_date}
                    onChange={(e) => set("first_closing_date", e.target.value)}
                  />
                </Field>
                <Field label="Régime fiscal">
                  <Select value={form.tax_regime} onValueChange={(v) => set("tax_regime", v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="—" />
                    </SelectTrigger>
                    <SelectContent>
                      {TAX_REGIMES.map((r) => (
                        <SelectItem key={r} value={r}>
                          {r}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Régime TVA">
                  <Select value={form.vat_regime} onValueChange={(v) => set("vat_regime", v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="—" />
                    </SelectTrigger>
                    <SelectContent>
                      {VAT_REGIMES.map((r) => (
                        <SelectItem key={r} value={r}>
                          {r}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Effectif">
                  <Input type="number" value={form.headcount} onChange={(e) => set("headcount", e.target.value)} />
                </Field>
                <Field label="Reprise confrère">
                  <Input value={form.takeover_colleague} onChange={(e) => set("takeover_colleague", e.target.value)} />
                </Field>
                <Field label="Date LDM">
                  <Input type="date" value={form.ldm_date} onChange={(e) => set("ldm_date", e.target.value)} />
                </Field>
                <Field label="Mandat SEPA">
                  <Select
                    value={form.sepa_mandate ? "true" : "false"}
                    onValueChange={(v) => set("sepa_mandate", v === "true")}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="false">Non</SelectItem>
                      <SelectItem value="true">Oui</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="LMNP ou SCI">
                  <Select value={form.lmnp_sci} onValueChange={(v) => set("lmnp_sci", v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="—" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="LMNP">LMNP</SelectItem>
                      <SelectItem value="SCI">SCI</SelectItem>
                      <SelectItem value="Aucun">Aucun</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
              </div>
            </TabsContent>

            {/* Honoraires */}
            <TabsContent value="honoraires" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Honoraires compta (€)">
                  <Input
                    type="number"
                    value={form.fees_accounting}
                    onChange={(e) => set("fees_accounting", e.target.value)}
                  />
                </Field>
                <Field label="Périodicité">
                  <Select value={form.fees_periodicity} onValueChange={(v) => set("fees_periodicity", v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="—" />
                    </SelectTrigger>
                    <SelectContent>
                      {PERIODICITES.map((p) => (
                        <SelectItem key={p} value={p}>
                          {p}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Honoraires bilan (€)">
                  <Input
                    type="number"
                    value={form.fees_balance}
                    onChange={(e) => set("fees_balance", e.target.value)}
                  />
                </Field>
                <Field label="Honoraires juridique (€)">
                  <Input type="number" value={form.fees_legal} onChange={(e) => set("fees_legal", e.target.value)} />
                </Field>
                <Field label="Honoraires BS (€)">
                  <Input
                    type="number"
                    value={form.fees_payroll}
                    onChange={(e) => set("fees_payroll", e.target.value)}
                  />
                </Field>
                <Field label="Nb bulletins">
                  <Input
                    type="number"
                    value={form.payslips_count}
                    onChange={(e) => set("payslips_count", e.target.value)}
                  />
                </Field>
                <Field label="Logiciel à disposition">
                  <Select value={form.software_provided} onValueChange={(v) => set("software_provided", v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="—" />
                    </SelectTrigger>
                    <SelectContent>
                      {SOFTWARES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Honoraires logiciel (€)">
                  <Input
                    type="number"
                    value={form.fees_software}
                    onChange={(e) => set("fees_software", e.target.value)}
                  />
                </Field>
                <Field label="Observations" className="md:col-span-2">
                  <Textarea value={form.observations} onChange={(e) => set("observations", e.target.value)} rows={4} />
                </Field>
              </div>
            </TabsContent>

            {editingId && (
              <TabsContent value="documents" className="mt-4">
                <CompanyDocumentsTab firmId={form.firm_id} companyId={editingId} companyName={form.name} />
              </TabsContent>
            )}
            {editingId && (
              <TabsContent value="signatures" className="mt-4">
                <CompanySignaturesTab companyId={editingId} />
              </TabsContent>
            )}
          </Tabs>

          {/* Desktop footer */}
          <DialogFooter className="hidden md:flex px-6 pb-6 border-t pt-4">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Annuler
            </Button>
            <Button onClick={() => upsert.mutate()} disabled={upsert.isPending}>
              {editingId ? "Enregistrer" : "Créer"}
            </Button>
          </DialogFooter>

          {/* Mobile sticky footer */}
          <div className="md:hidden fixed bottom-0 inset-x-0 bg-background border-t p-3 flex gap-2 z-50">
            <Button variant="outline" className="flex-1" onClick={() => setOpen(false)}>
              Annuler
            </Button>
            <Button className="flex-1" onClick={() => upsert.mutate()} disabled={upsert.isPending}>
              {editingId ? "Enregistrer" : "Créer"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Pappers search dialog */}
      <Dialog open={pappersOpen} onOpenChange={setPappersOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="size-4 text-primary" />
              Recherche Pappers
            </DialogTitle>
            <DialogDescription>
              Recherchez par SIREN, SIRET ou nom de société, puis créez la fiche en un clic.
            </DialogDescription>
          </DialogHeader>
          {!pappersStatus?.connected ? (
            <div className="rounded-lg border bg-muted/30 p-4 flex items-start gap-3">
              <AlertTriangle className="size-4 text-amber-500 mt-0.5" />
              <div className="text-sm">
                Pappers n'est pas connecté pour ce cabinet. Allez dans <span className="font-medium">Intégrations</span>{" "}
                pour ajouter votre clé API.
              </div>
            </div>
          ) : (
            <>
              <div className="flex gap-2">
                <Input
                  autoFocus
                  value={pappersQuery}
                  onChange={(e) => setPappersQuery(e.target.value)}
                  placeholder="Nom, SIREN ou SIRET"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") runPappersSearch();
                  }}
                />
                <Button onClick={runPappersSearch} disabled={pappersLoading || !pappersQuery.trim()}>
                  {pappersLoading ? "Recherche…" : "Rechercher"}
                </Button>
              </div>
              <div className="max-h-[50vh] overflow-y-auto -mx-2 px-2">
                {pappersResults === null ? (
                  <p className="text-sm text-muted-foreground py-8 text-center">
                    Saisissez votre recherche pour démarrer.
                  </p>
                ) : pappersResults.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-8 text-center">Aucun résultat.</p>
                ) : (
                  <div className="space-y-2">
                    {pappersResults.map((r: any) => {
                      const exists = companies.find((c: any) => c.siren === r.siren);
                      return (
                        <Card key={r.siren} className="border-border">
                          <CardContent className="p-3 flex items-center justify-between gap-3">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="font-medium truncate">{r.name}</p>
                                {exists && (
                                  <Badge variant="outline" className="text-amber-600 border-amber-300">
                                    Déjà existant
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground mt-0.5">
                                {[r.siren, r.legal_form, r.city, r.activity, r.status].filter(Boolean).join(" · ")}
                              </p>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => importFromPappers(r.siren)}
                              disabled={pappersImporting === r.siren}
                            >
                              {pappersImporting === r.siren ? "…" : "Créer depuis Pappers"}
                            </Button>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
