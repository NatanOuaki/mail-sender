import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { retrieveSignedDocumentInternal } from "@/lib/signatures.server";
import { decryptSecret } from "@/lib/crypto.server";
import { createHmac, timingSafeEqual } from "crypto";

/**
 * DocuSign Connect webhook (envelope status updates). Verifies HMAC-SHA256
 * (base64) of the raw body against the firm's webhook_secret stored in
 * firm_integration_secrets.config.webhook_secret. Live mode requires a
 * secret; otherwise the request is rejected.
 */
function verifyDocuSignSignature(rawBody: string, headers: Headers, secret: string): boolean {
  const expected = createHmac("sha256", secret).update(rawBody).digest("base64");
  for (let i = 1; i <= 10; i++) {
    const sig = headers.get(`x-docusign-signature-${i}`);
    if (!sig) continue;
    try {
      const a = Buffer.from(sig.trim(), "base64");
      const b = Buffer.from(expected, "base64");
      if (a.length === b.length && timingSafeEqual(a, b)) return true;
    } catch { /* keep checking */ }
  }
  return false;
}

export const Route = createFileRoute("/api/public/webhooks/docusign")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = await request.text();
        let payload: any = {};
        try { payload = JSON.parse(body); } catch {
          return new Response("Invalid JSON", { status: 400 });
        }

        const eventName: string = payload.event ?? payload.status ?? "unknown";
        const envelopeId: string | undefined =
          payload.data?.envelopeId ?? payload.envelopeId ?? payload.envelope?.envelopeId;
        if (!envelopeId) {
          return new Response(JSON.stringify({ ok: true, ignored: true }), {
            status: 200, headers: { "content-type": "application/json" },
          });
        }

        const { data: req } = await (supabaseAdmin as any)
          .from("signature_requests")
          .select("id, firm_id, generated_document_id, mode")
          .eq("provider", "docusign")
          .eq("provider_request_id", envelopeId)
          .maybeSingle();
        if (!req) {
          return new Response(JSON.stringify({ ok: true, unknown: true }), {
            status: 200, headers: { "content-type": "application/json" },
          });
        }

        const { data: secret } = await (supabaseAdmin as any)
          .from("firm_integration_secrets")
          .select("config")
          .eq("firm_id", req.firm_id).eq("provider", "docusign").maybeSingle();
        const rawSecret = secret?.config?.webhook_secret as string | undefined;
        const webhookSecret = rawSecret
          ? (decryptSecret(rawSecret) ?? rawSecret).trim()
          : undefined;
        if (req.mode === "live") {
          if (!webhookSecret) {
            console.error("[docusign webhook] missing secret for firm", req.firm_id);
            return new Response("Webhook secret not configured", { status: 401 });
          }
          if (!verifyDocuSignSignature(body, request.headers, webhookSecret)) {
            return new Response("Invalid signature", { status: 401 });
          }
        }

        await (supabaseAdmin as any).from("signature_events").insert({
          signature_request_id: req.id, provider: "docusign",
          event_type: eventName, payload,
        });

        const now = new Date().toISOString();
        const update: Record<string, any> = {};
        let docStatus: string | null = null;
        const evt = eventName.toLowerCase();
        if (evt.includes("sent")) { update.status = "sent"; update.sent_at = now; }
        if (evt.includes("delivered") || evt.includes("viewed"))
          { update.status = "viewed"; update.viewed_at = now; }
        if (evt.includes("completed") || evt.includes("signed"))
          { update.status = "signed"; update.completed_at = now; docStatus = "signed"; }
        if (evt.includes("declined") || evt.includes("refused"))
          { update.status = "refused"; docStatus = "refused"; }
        if (evt.includes("voided") || evt.includes("expired") || evt.includes("cancelled"))
          { update.status = evt.includes("expired") ? "expired" : "cancelled";
            docStatus = update.status; }
        if (Object.keys(update).length > 0) {
          await (supabaseAdmin as any).from("signature_requests").update(update).eq("id", req.id);
        }
        if (docStatus && req.generated_document_id) {
          await (supabaseAdmin as any).from("generated_documents")
            .update({ status: docStatus }).eq("id", req.generated_document_id);
        }
        if (docStatus === "signed") {
          retrieveSignedDocumentInternal(req.id).catch((e: any) =>
            console.error("[docusign webhook] retrieve signed pdf failed", e));
        }
        await (supabaseAdmin as any).from("audit_logs").insert({
          firm_id: req.firm_id, action: "signature.webhook_received",
          entity_type: "signature_request", entity_id: req.id,
          metadata: { provider: "docusign", event: eventName },
        });
        return new Response(JSON.stringify({ ok: true }), {
          status: 200, headers: { "content-type": "application/json" },
        });
      },
    },
  },
});