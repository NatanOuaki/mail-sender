import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { retrieveSignedDocumentInternal } from "@/lib/signatures.server";
import { decryptSecret } from "@/lib/crypto.server";
import { createHmac, timingSafeEqual } from "crypto";

/**
 * YouSign v3 webhook receiver. Verifies HMAC-SHA256 of the raw body
 * against the firm's per-provider webhook secret stored in
 * firm_integration_secrets.config.webhook_secret. In live mode the
 * webhook is rejected if no secret is configured.
 */
function verifyYouSignSignature(rawBody: string, header: string | null, secret: string): boolean {
  if (!header) return false;
  const provided = header.trim();
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  try {
    const a = Buffer.from(provided, "hex");
    const b = Buffer.from(expected, "hex");
    return a.length === b.length && timingSafeEqual(a, b);
  } catch { return false; }
}

export const Route = createFileRoute("/api/public/webhooks/yousign")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = await request.text();
        let payload: any = {};
        try { payload = JSON.parse(body); } catch {
          return new Response("Invalid JSON", { status: 400 });
        }

        const eventName: string = payload.event_name ?? payload.event ?? "unknown";
        const reqId: string | undefined =
          payload.signature_request?.id ?? payload.data?.signature_request?.id ?? payload.signature_request_id;

        if (!reqId) {
          return new Response(JSON.stringify({ ok: true, ignored: true }), {
            status: 200, headers: { "content-type": "application/json" },
          });
        }

        const { data: req } = await (supabaseAdmin as any)
          .from("signature_requests")
          .select("id, firm_id, generated_document_id, status, mode, provider_request_id")
          .eq("provider", "yousign")
          .eq("provider_request_id", reqId)
          .maybeSingle();
        if (!req) {
          return new Response(JSON.stringify({ ok: true, unknown: true }), {
            status: 200, headers: { "content-type": "application/json" },
          });
        }

        // Signature verification (firm-scoped secret)
        const { data: secret } = await (supabaseAdmin as any)
          .from("firm_integration_secrets")
          .select("config")
          .eq("firm_id", req.firm_id).eq("provider", "yousign").maybeSingle();
        const rawSecret = secret?.config?.webhook_secret as string | undefined;
        const webhookSecret = rawSecret
          ? (decryptSecret(rawSecret) ?? rawSecret).trim()
          : undefined;
        const sigHeader =
          request.headers.get("x-yousign-signature-256") ??
          request.headers.get("x-yousign-signature");
        if (req.mode === "live") {
          if (!webhookSecret) {
            console.error("[yousign webhook] missing secret for firm", req.firm_id);
            return new Response("Webhook secret not configured", { status: 401 });
          }
          if (!verifyYouSignSignature(body, sigHeader, webhookSecret)) {
            return new Response("Invalid signature", { status: 401 });
          }
        }

        await (supabaseAdmin as any).from("signature_events").insert({
          signature_request_id: req.id, provider: "yousign",
          event_type: eventName, payload,
        });

        const now = new Date().toISOString();
        const update: Record<string, any> = {};
        let docStatus: string | null = null;
        if (eventName.includes("activated")) { update.status = "sent"; update.sent_at = now; }
        if (eventName.includes("opened") || eventName.includes("viewed"))
          { update.status = "viewed"; update.viewed_at = now; }
        if (eventName.includes("done") || eventName.includes("signed"))
          { update.status = "signed"; update.completed_at = now; docStatus = "signed"; }
        if (eventName.includes("decline") || eventName.includes("refused"))
          { update.status = "refused"; docStatus = "refused"; }
        if (eventName.includes("expired")) { update.status = "expired"; docStatus = "expired"; }
        if (Object.keys(update).length > 0) {
          await (supabaseAdmin as any).from("signature_requests").update(update).eq("id", req.id);
        }
        if (docStatus && req.generated_document_id) {
          await (supabaseAdmin as any).from("generated_documents")
            .update({ status: docStatus }).eq("id", req.generated_document_id);
        }

        // On signed, fetch the signed PDF in the background
        if (docStatus === "signed") {
          retrieveSignedDocumentInternal(req.id).catch((e: any) =>
            console.error("[yousign webhook] retrieve signed pdf failed", e));
        }
        await (supabaseAdmin as any).from("audit_logs").insert({
          firm_id: req.firm_id, action: "signature.webhook_received",
          entity_type: "signature_request", entity_id: req.id,
          metadata: { provider: "yousign", event: eventName },
        });
        return new Response(JSON.stringify({ ok: true }), {
          status: 200, headers: { "content-type": "application/json" },
        });
      },
    },
  },
});