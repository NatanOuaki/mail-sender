import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Building2 } from "lucide-react";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Connexion réussie");
    navigate({ to: "/dashboard" });
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between p-12 bg-sidebar text-sidebar-foreground">
        <div className="flex items-center gap-2">
          <div className="size-9 rounded-xl bg-primary grid place-items-center text-primary-foreground"><Building2 className="size-5"/></div>
          <span className="text-lg font-semibold tracking-tight">MyCab360</span>
        </div>
        <div>
          <h1 className="text-4xl font-semibold tracking-tight max-w-md">Le CRM moderne pour les cabinets d'expertise comptable.</h1>
          <p className="mt-4 text-sm text-sidebar-foreground/70 max-w-md">Gérez plusieurs cabinets, clients, documents et intégrations depuis un espace unifié.</p>
        </div>
        <p className="text-xs text-sidebar-foreground/50">© {new Date().getFullYear()} MyCab360</p>
      </div>
      <div className="flex items-center justify-center p-8">
        <form onSubmit={onSubmit} className="w-full max-w-sm space-y-5">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight">Connexion</h2>
            <p className="text-sm text-muted-foreground mt-1">Accédez à votre espace cabinet.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="vous@cabinet.fr"/>
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Mot de passe</Label>
            <Input id="password" type="password" required value={password} onChange={e => setPassword(e.target.value)}/>
          </div>
          <Button type="submit" disabled={loading} className="w-full">{loading ? "Connexion…" : "Se connecter"}</Button>
          <p className="text-sm text-muted-foreground text-center">
            Pas encore de compte ? <Link to="/signup" className="text-primary font-medium hover:underline">Créer un cabinet</Link>
          </p>
        </form>
      </div>
    </div>
  );
}