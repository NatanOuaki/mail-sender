import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Building2 } from "lucide-react";

export const Route = createFileRoute("/signup")({ component: SignupPage });

function SignupPage() {
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [firmName, setFirmName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email, password,
      options: {
        emailRedirectTo: `${window.location.origin}/dashboard`,
        data: { full_name: fullName, firm_name: firmName },
      },
    });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Compte créé. Vous pouvez vous connecter.");
    navigate({ to: "/dashboard" });
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between p-12 bg-sidebar text-sidebar-foreground">
        <div className="flex items-center gap-2">
          <div className="size-9 rounded-xl bg-primary grid place-items-center text-primary-foreground"><Building2 className="size-5"/></div>
          <span className="text-lg font-semibold tracking-tight">MyCab360</span>
        </div>
        <div>
          <h1 className="text-4xl font-semibold tracking-tight max-w-md">Créez votre cabinet en quelques secondes.</h1>
          <p className="mt-4 text-sm text-sidebar-foreground/70 max-w-md">Vous pourrez gérer plusieurs cabinets, vos clients, contacts et documents depuis un seul compte.</p>
        </div>
        <p className="text-xs text-sidebar-foreground/50">© {new Date().getFullYear()} MyCab360</p>
      </div>
      <div className="flex items-center justify-center p-8">
        <form onSubmit={onSubmit} className="w-full max-w-sm space-y-5">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight">Créer un compte</h2>
            <p className="text-sm text-muted-foreground mt-1">Premier cabinet créé automatiquement.</p>
          </div>
          <div className="space-y-2"><Label>Nom complet</Label><Input required value={fullName} onChange={e => setFullName(e.target.value)} /></div>
          <div className="space-y-2"><Label>Nom du cabinet</Label><Input required value={firmName} onChange={e => setFirmName(e.target.value)} placeholder="Cabinet Dupont & Associés"/></div>
          <div className="space-y-2"><Label>Email</Label><Input type="email" required value={email} onChange={e => setEmail(e.target.value)}/></div>
          <div className="space-y-2"><Label>Mot de passe</Label><Input type="password" required minLength={6} value={password} onChange={e => setPassword(e.target.value)}/></div>
          <Button type="submit" disabled={loading} className="w-full">{loading ? "Création…" : "Créer mon cabinet"}</Button>
          <p className="text-sm text-muted-foreground text-center">
            Déjà inscrit ? <Link to="/login" className="text-primary font-medium hover:underline">Se connecter</Link>
          </p>
        </form>
      </div>
    </div>
  );
}