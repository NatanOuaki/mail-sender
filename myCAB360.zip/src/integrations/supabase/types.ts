export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      api_keys: {
        Row: {
          created_at: string
          created_by: string | null
          firm_id: string
          id: string
          key_hash: string
          key_prefix: string
          last_used_at: string | null
          name: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          firm_id: string
          id?: string
          key_hash: string
          key_prefix: string
          last_used_at?: string | null
          name: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          firm_id?: string
          id?: string
          key_hash?: string
          key_prefix?: string
          last_used_at?: string | null
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "api_keys_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string
          entity_id: string | null
          entity_type: string | null
          firm_id: string
          id: string
          metadata: Json | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          entity_id?: string | null
          entity_type?: string | null
          firm_id: string
          id?: string
          metadata?: Json | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          entity_id?: string | null
          entity_type?: string | null
          firm_id?: string
          id?: string
          metadata?: Json | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          assigned_to: string | null
          company_id: string | null
          created_at: string
          firm_id: string
          id: string
          notes: string | null
          reference: string | null
          status: Database["public"]["Enums"]["client_status"]
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          company_id?: string | null
          created_at?: string
          firm_id: string
          id?: string
          notes?: string | null
          reference?: string | null
          status?: Database["public"]["Enums"]["client_status"]
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          company_id?: string | null
          created_at?: string
          firm_id?: string
          id?: string
          notes?: string | null
          reference?: string | null
          status?: Database["public"]["Enums"]["client_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clients_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      companies: {
        Row: {
          activity: string | null
          address: string | null
          city: string | null
          country: string | null
          created_at: string
          creation_date: string | null
          email: string | null
          fees_accounting: number | null
          fees_balance: number | null
          fees_legal: number | null
          fees_payroll: number | null
          fees_periodicity: string | null
          fees_software: number | null
          firm_id: string
          first_closing_date: string | null
          headcount: number | null
          id: string
          ldm_date: string | null
          legal_form: string | null
          lmnp_sci: string | null
          naf_code: string | null
          name: string
          observations: string | null
          pappers_synced_at: string | null
          payslips_count: number | null
          phone: string | null
          postal_code: string | null
          rep_civility: string | null
          rep_email: string | null
          rep_first_name: string | null
          rep_last_name: string | null
          rep_phone: string | null
          sepa_mandate: boolean | null
          share_capital: number | null
          siren: string | null
          siret: string | null
          software_provided: string | null
          status: string
          takeover_colleague: string | null
          takeover_date: string | null
          tax_regime: string | null
          updated_at: string
          vat_number: string | null
          vat_regime: string | null
          website: string | null
        }
        Insert: {
          activity?: string | null
          address?: string | null
          city?: string | null
          country?: string | null
          created_at?: string
          creation_date?: string | null
          email?: string | null
          fees_accounting?: number | null
          fees_balance?: number | null
          fees_legal?: number | null
          fees_payroll?: number | null
          fees_periodicity?: string | null
          fees_software?: number | null
          firm_id: string
          first_closing_date?: string | null
          headcount?: number | null
          id?: string
          ldm_date?: string | null
          legal_form?: string | null
          lmnp_sci?: string | null
          naf_code?: string | null
          name: string
          observations?: string | null
          pappers_synced_at?: string | null
          payslips_count?: number | null
          phone?: string | null
          postal_code?: string | null
          rep_civility?: string | null
          rep_email?: string | null
          rep_first_name?: string | null
          rep_last_name?: string | null
          rep_phone?: string | null
          sepa_mandate?: boolean | null
          share_capital?: number | null
          siren?: string | null
          siret?: string | null
          software_provided?: string | null
          status?: string
          takeover_colleague?: string | null
          takeover_date?: string | null
          tax_regime?: string | null
          updated_at?: string
          vat_number?: string | null
          vat_regime?: string | null
          website?: string | null
        }
        Update: {
          activity?: string | null
          address?: string | null
          city?: string | null
          country?: string | null
          created_at?: string
          creation_date?: string | null
          email?: string | null
          fees_accounting?: number | null
          fees_balance?: number | null
          fees_legal?: number | null
          fees_payroll?: number | null
          fees_periodicity?: string | null
          fees_software?: number | null
          firm_id?: string
          first_closing_date?: string | null
          headcount?: number | null
          id?: string
          ldm_date?: string | null
          legal_form?: string | null
          lmnp_sci?: string | null
          naf_code?: string | null
          name?: string
          observations?: string | null
          pappers_synced_at?: string | null
          payslips_count?: number | null
          phone?: string | null
          postal_code?: string | null
          rep_civility?: string | null
          rep_email?: string | null
          rep_first_name?: string | null
          rep_last_name?: string | null
          rep_phone?: string | null
          sepa_mandate?: boolean | null
          share_capital?: number | null
          siren?: string | null
          siret?: string | null
          software_provided?: string | null
          status?: string
          takeover_colleague?: string | null
          takeover_date?: string | null
          tax_regime?: string | null
          updated_at?: string
          vat_number?: string | null
          vat_regime?: string | null
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "companies_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      contacts: {
        Row: {
          client_id: string | null
          company_id: string | null
          created_at: string
          email: string | null
          firm_id: string
          first_name: string
          id: string
          last_name: string
          notes: string | null
          phone: string | null
          role_title: string | null
          updated_at: string
        }
        Insert: {
          client_id?: string | null
          company_id?: string | null
          created_at?: string
          email?: string | null
          firm_id: string
          first_name: string
          id?: string
          last_name: string
          notes?: string | null
          phone?: string | null
          role_title?: string | null
          updated_at?: string
        }
        Update: {
          client_id?: string | null
          company_id?: string | null
          created_at?: string
          email?: string | null
          firm_id?: string
          first_name?: string
          id?: string
          last_name?: string
          notes?: string | null
          phone?: string | null
          role_title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "contacts_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contacts_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contacts_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      document_templates: {
        Row: {
          background_path: string | null
          category: string | null
          created_at: string
          created_by: string | null
          description: string | null
          file_path: string | null
          file_type: string | null
          file_url: string | null
          firm_id: string
          id: string
          is_active: boolean
          name: string
          updated_at: string
          variables: Json
        }
        Insert: {
          background_path?: string | null
          category?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          file_path?: string | null
          file_type?: string | null
          file_url?: string | null
          firm_id: string
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
          variables?: Json
        }
        Update: {
          background_path?: string | null
          category?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          file_path?: string | null
          file_type?: string | null
          file_url?: string | null
          firm_id?: string
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
          variables?: Json
        }
        Relationships: [
          {
            foreignKeyName: "document_templates_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      email_logs: {
        Row: {
          company_id: string | null
          created_at: string
          error_message: string | null
          firm_id: string
          id: string
          metadata: Json
          provider_message_id: string | null
          recipient_email: string
          sent_at: string | null
          signature_request_id: string | null
          status: string
          subject: string | null
          template_key: string | null
        }
        Insert: {
          company_id?: string | null
          created_at?: string
          error_message?: string | null
          firm_id: string
          id?: string
          metadata?: Json
          provider_message_id?: string | null
          recipient_email: string
          sent_at?: string | null
          signature_request_id?: string | null
          status?: string
          subject?: string | null
          template_key?: string | null
        }
        Update: {
          company_id?: string | null
          created_at?: string
          error_message?: string | null
          firm_id?: string
          id?: string
          metadata?: Json
          provider_message_id?: string | null
          recipient_email?: string
          sent_at?: string | null
          signature_request_id?: string | null
          status?: string
          subject?: string | null
          template_key?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "email_logs_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_logs_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_logs_signature_request_id_fkey"
            columns: ["signature_request_id"]
            isOneToOne: false
            referencedRelation: "signature_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      firm_banking: {
        Row: {
          bic: string | null
          firm_id: string
          iban: string | null
          ics: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          bic?: string | null
          firm_id: string
          iban?: string | null
          ics?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          bic?: string | null
          firm_id?: string
          iban?: string | null
          ics?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "firm_banking_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: true
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      firm_email_settings: {
        Row: {
          created_at: string
          custom_firm_email_enabled: boolean
          email_provider: string
          firm_id: string
          last_error: string | null
          last_test_at: string | null
          native_provider_email_enabled: boolean
          oauth_provider: string | null
          oauth_tokens: Json | null
          provider_api_key_cipher: string | null
          provider_config: Json
          sender_email: string | null
          sender_name: string | null
          smtp_host: string | null
          smtp_password_cipher: string | null
          smtp_password_encrypted: string | null
          smtp_port: number | null
          smtp_secure: boolean
          smtp_username: string | null
          status: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          created_at?: string
          custom_firm_email_enabled?: boolean
          email_provider?: string
          firm_id: string
          last_error?: string | null
          last_test_at?: string | null
          native_provider_email_enabled?: boolean
          oauth_provider?: string | null
          oauth_tokens?: Json | null
          provider_api_key_cipher?: string | null
          provider_config?: Json
          sender_email?: string | null
          sender_name?: string | null
          smtp_host?: string | null
          smtp_password_cipher?: string | null
          smtp_password_encrypted?: string | null
          smtp_port?: number | null
          smtp_secure?: boolean
          smtp_username?: string | null
          status?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          created_at?: string
          custom_firm_email_enabled?: boolean
          email_provider?: string
          firm_id?: string
          last_error?: string | null
          last_test_at?: string | null
          native_provider_email_enabled?: boolean
          oauth_provider?: string | null
          oauth_tokens?: Json | null
          provider_api_key_cipher?: string | null
          provider_config?: Json
          sender_email?: string | null
          sender_name?: string | null
          smtp_host?: string | null
          smtp_password_cipher?: string | null
          smtp_password_encrypted?: string | null
          smtp_port?: number | null
          smtp_secure?: boolean
          smtp_username?: string | null
          status?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "firm_email_settings_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: true
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      firm_email_templates: {
        Row: {
          body_html: string
          body_text: string | null
          created_at: string
          enabled: boolean
          firm_id: string
          id: string
          subject: string
          template_key: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          body_html: string
          body_text?: string | null
          created_at?: string
          enabled?: boolean
          firm_id: string
          id?: string
          subject: string
          template_key: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          body_html?: string
          body_text?: string | null
          created_at?: string
          enabled?: boolean
          firm_id?: string
          id?: string
          subject?: string
          template_key?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "firm_email_templates_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      firm_integration_secrets: {
        Row: {
          api_key: string | null
          config: Json
          created_at: string
          created_by: string | null
          firm_id: string
          id: string
          last_test_at: string | null
          provider: string
          updated_at: string
        }
        Insert: {
          api_key?: string | null
          config?: Json
          created_at?: string
          created_by?: string | null
          firm_id: string
          id?: string
          last_test_at?: string | null
          provider: string
          updated_at?: string
        }
        Update: {
          api_key?: string | null
          config?: Json
          created_at?: string
          created_by?: string | null
          firm_id?: string
          id?: string
          last_test_at?: string | null
          provider?: string
          updated_at?: string
        }
        Relationships: []
      }
      firm_members: {
        Row: {
          created_at: string
          firm_id: string
          id: string
          invited_by: string | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          firm_id: string
          id?: string
          invited_by?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          firm_id?: string
          id?: string
          invited_by?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "firm_members_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      firms: {
        Row: {
          address: string | null
          city: string | null
          created_at: string
          email: string | null
          id: string
          legal_form: string | null
          logo_url: string | null
          name: string
          owner_id: string
          phone: string | null
          postal_code: string | null
          primary_color: string | null
          share_capital: string | null
          siren: string | null
          siret: string | null
          updated_at: string
          vat_number: string | null
          website: string | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          created_at?: string
          email?: string | null
          id?: string
          legal_form?: string | null
          logo_url?: string | null
          name: string
          owner_id: string
          phone?: string | null
          postal_code?: string | null
          primary_color?: string | null
          share_capital?: string | null
          siren?: string | null
          siret?: string | null
          updated_at?: string
          vat_number?: string | null
          website?: string | null
        }
        Update: {
          address?: string | null
          city?: string | null
          created_at?: string
          email?: string | null
          id?: string
          legal_form?: string | null
          logo_url?: string | null
          name?: string
          owner_id?: string
          phone?: string | null
          postal_code?: string | null
          primary_color?: string | null
          share_capital?: string | null
          siren?: string | null
          siret?: string | null
          updated_at?: string
          vat_number?: string | null
          website?: string | null
        }
        Relationships: []
      }
      generated_documents: {
        Row: {
          client_id: string | null
          company_id: string | null
          created_at: string
          docx_path: string | null
          file_path: string | null
          file_type: string | null
          file_url: string | null
          firm_id: string
          generated_by: string | null
          id: string
          name: string
          pdf_path: string | null
          status: string | null
          template_id: string | null
          updated_at: string
        }
        Insert: {
          client_id?: string | null
          company_id?: string | null
          created_at?: string
          docx_path?: string | null
          file_path?: string | null
          file_type?: string | null
          file_url?: string | null
          firm_id: string
          generated_by?: string | null
          id?: string
          name: string
          pdf_path?: string | null
          status?: string | null
          template_id?: string | null
          updated_at?: string
        }
        Update: {
          client_id?: string | null
          company_id?: string | null
          created_at?: string
          docx_path?: string | null
          file_path?: string | null
          file_type?: string | null
          file_url?: string | null
          firm_id?: string
          generated_by?: string | null
          id?: string
          name?: string
          pdf_path?: string | null
          status?: string | null
          template_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "generated_documents_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "generated_documents_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "generated_documents_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "document_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      integrations: {
        Row: {
          config: Json
          connected_at: string | null
          created_at: string
          firm_id: string
          id: string
          last_sync_at: string | null
          provider: Database["public"]["Enums"]["integration_provider"]
          status: Database["public"]["Enums"]["integration_status"]
          updated_at: string
        }
        Insert: {
          config?: Json
          connected_at?: string | null
          created_at?: string
          firm_id: string
          id?: string
          last_sync_at?: string | null
          provider: Database["public"]["Enums"]["integration_provider"]
          status?: Database["public"]["Enums"]["integration_status"]
          updated_at?: string
        }
        Update: {
          config?: Json
          connected_at?: string | null
          created_at?: string
          firm_id?: string
          id?: string
          last_sync_at?: string | null
          provider?: Database["public"]["Enums"]["integration_provider"]
          status?: Database["public"]["Enums"]["integration_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "integrations_firm_id_fkey"
            columns: ["firm_id"]
            isOneToOne: false
            referencedRelation: "firms"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      signature_events: {
        Row: {
          created_at: string
          event_type: string
          id: string
          payload: Json
          provider: string
          signature_request_id: string
        }
        Insert: {
          created_at?: string
          event_type: string
          id?: string
          payload?: Json
          provider: string
          signature_request_id: string
        }
        Update: {
          created_at?: string
          event_type?: string
          id?: string
          payload?: Json
          provider?: string
          signature_request_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "signature_events_signature_request_id_fkey"
            columns: ["signature_request_id"]
            isOneToOne: false
            referencedRelation: "signature_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      signature_requests: {
        Row: {
          company_id: string | null
          completed_at: string | null
          created_at: string
          created_by: string | null
          custom_firm_email_enabled: boolean
          expires_at: string | null
          firm_id: string
          generated_document_id: string | null
          id: string
          last_reminder_at: string | null
          message: string | null
          mode: string
          native_provider_email_enabled: boolean
          provider: string
          provider_request_id: string | null
          reminder_count: number
          sent_at: string | null
          signature_url: string | null
          signed_document_path: string | null
          signing_order_mode: string
          status: string
          subject: string | null
          updated_at: string
          viewed_at: string | null
        }
        Insert: {
          company_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          custom_firm_email_enabled?: boolean
          expires_at?: string | null
          firm_id: string
          generated_document_id?: string | null
          id?: string
          last_reminder_at?: string | null
          message?: string | null
          mode?: string
          native_provider_email_enabled?: boolean
          provider: string
          provider_request_id?: string | null
          reminder_count?: number
          sent_at?: string | null
          signature_url?: string | null
          signed_document_path?: string | null
          signing_order_mode?: string
          status?: string
          subject?: string | null
          updated_at?: string
          viewed_at?: string | null
        }
        Update: {
          company_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          custom_firm_email_enabled?: boolean
          expires_at?: string | null
          firm_id?: string
          generated_document_id?: string | null
          id?: string
          last_reminder_at?: string | null
          message?: string | null
          mode?: string
          native_provider_email_enabled?: boolean
          provider?: string
          provider_request_id?: string | null
          reminder_count?: number
          sent_at?: string | null
          signature_url?: string | null
          signed_document_path?: string | null
          signing_order_mode?: string
          status?: string
          subject?: string | null
          updated_at?: string
          viewed_at?: string | null
        }
        Relationships: []
      }
      signature_signers: {
        Row: {
          created_at: string
          email: string
          firstname: string
          id: string
          lastname: string
          phone: string | null
          provider_signer_id: string | null
          signature_request_id: string
          signed_at: string | null
          signing_order: number
          status: string
        }
        Insert: {
          created_at?: string
          email: string
          firstname: string
          id?: string
          lastname: string
          phone?: string | null
          provider_signer_id?: string | null
          signature_request_id: string
          signed_at?: string | null
          signing_order?: number
          status?: string
        }
        Update: {
          created_at?: string
          email?: string
          firstname?: string
          id?: string
          lastname?: string
          phone?: string | null
          provider_signer_id?: string | null
          signature_request_id?: string
          signed_at?: string | null
          signing_order?: number
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "signature_signers_signature_request_id_fkey"
            columns: ["signature_request_id"]
            isOneToOne: false
            referencedRelation: "signature_requests"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      clear_integration_api_key: {
        Args: { _firm_id: string; _provider: string }
        Returns: undefined
      }
      create_firm:
        | {
            Args: { firm_city?: string; firm_name: string; firm_siret?: string }
            Returns: {
              address: string | null
              city: string | null
              created_at: string
              email: string | null
              id: string
              legal_form: string | null
              logo_url: string | null
              name: string
              owner_id: string
              phone: string | null
              postal_code: string | null
              primary_color: string | null
              share_capital: string | null
              siren: string | null
              siret: string | null
              updated_at: string
              vat_number: string | null
              website: string | null
            }
            SetofOptions: {
              from: "*"
              to: "firms"
              isOneToOne: true
              isSetofReturn: false
            }
          }
        | {
            Args: {
              firm_address?: string
              firm_bic?: string
              firm_city?: string
              firm_email?: string
              firm_iban?: string
              firm_ics?: string
              firm_legal_form?: string
              firm_name: string
              firm_phone?: string
              firm_postal_code?: string
              firm_share_capital?: string
              firm_siren?: string
              firm_siret?: string
              firm_vat_number?: string
              firm_website?: string
            }
            Returns: {
              address: string | null
              city: string | null
              created_at: string
              email: string | null
              id: string
              legal_form: string | null
              logo_url: string | null
              name: string
              owner_id: string
              phone: string | null
              postal_code: string | null
              primary_color: string | null
              share_capital: string | null
              siren: string | null
              siret: string | null
              updated_at: string
              vat_number: string | null
              website: string | null
            }
            SetofOptions: {
              from: "*"
              to: "firms"
              isOneToOne: true
              isSetofReturn: false
            }
          }
      delete_firm: { Args: { firm_id: string }; Returns: undefined }
      has_firm_access: {
        Args: { _firm_id: string; _user_id: string }
        Returns: boolean
      }
      has_firm_role: {
        Args: {
          _firm_id: string
          _roles: Database["public"]["Enums"]["app_role"][]
          _user_id: string
        }
        Returns: boolean
      }
      set_integration_api_key: {
        Args: { _api_key: string; _firm_id: string; _provider: string }
        Returns: undefined
      }
      set_integration_credentials: {
        Args: {
          _api_key: string
          _config?: Json
          _firm_id: string
          _provider: string
        }
        Returns: undefined
      }
      shares_firm_with: {
        Args: { _other_user: string; _viewer: string }
        Returns: boolean
      }
      touch_integration_test: {
        Args: { _firm_id: string; _provider: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "owner" | "admin" | "manager" | "collaborator" | "viewer"
      client_status: "prospect" | "active" | "inactive" | "archived"
      integration_provider:
        | "pappers"
        | "yousign"
        | "docusign"
        | "google_drive"
        | "sharepoint"
        | "gmail_smtp"
        | "inpi"
      integration_status: "connected" | "disconnected" | "error"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner", "admin", "manager", "collaborator", "viewer"],
      client_status: ["prospect", "active", "inactive", "archived"],
      integration_provider: [
        "pappers",
        "yousign",
        "docusign",
        "google_drive",
        "sharepoint",
        "gmail_smtp",
        "inpi",
      ],
      integration_status: ["connected", "disconnected", "error"],
    },
  },
} as const
