// Server-only helpers for sending emails via firm SMTP.
// Wraps nodemailer in a try/catch — if the runtime cannot create a transport
// (e.g. nodejs_compat limitations on edge), the helper returns a structured
// failure that the caller logs into email_logs without throwing.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { encryptSecret, decryptSecret } from "./crypto.server";
import {
  isMailServiceConfigured,
  mailServiceSend,
  mailServiceTestSmtp,
} from "./mail-service.server";

export type EmailProvider = "smtp" | "resend" | "sendgrid" | "mailgun" | "postmark";

export type SmtpSettings = {
  sender_name: string | null;
  sender_email: string;
  smtp_host: string;
  smtp_port: number;
  smtp_username: string | null;
  smtp_secure: boolean;
};

export type SendEmailResult =
  | { ok: true; messageId: string | null }
  | { ok: false; error: string };

export async function loadFirmSmtpPassword(firmId: string): Promise<string | null> {
  const { data, error } = await (supabaseAdmin as any)
    .from("firm_email_settings")
    .select("smtp_password_cipher")
    .eq("firm_id", firmId)
    .maybeSingle();
  if (error) {
    console.error("[emails] loadFirmSmtpPassword failed", error.message);
    return null;
  }
  return decryptSecret(data?.smtp_password_cipher ?? null);
}

// Returns the encrypted ciphertext as stored in DB (not the plaintext).
// Used when forwarding to the standalone mail microservice, which holds the
// shared APP_ENCRYPTION_KEY and decrypts inside its own runtime.
async function loadFirmSmtpPasswordCipher(firmId: string): Promise<string | null> {
  const { data } = await (supabaseAdmin as any)
    .from("firm_email_settings")
    .select("smtp_password_cipher")
    .eq("firm_id", firmId)
    .maybeSingle();
  return data?.smtp_password_cipher ?? null;
}

// Encrypt and persist a firm's SMTP password. Pass an empty string to clear it.
export async function saveFirmSmtpPassword(firmId: string, plaintext: string | null): Promise<void> {
  const cipher = plaintext && plaintext.length > 0 ? encryptSecret(plaintext) : null;
  const { error } = await (supabaseAdmin as any)
    .from("firm_email_settings")
    .update({ smtp_password_cipher: cipher })
    .eq("firm_id", firmId);
  if (error) throw new Error(error.message);
}

// =====================================================================
// Provider API key (Resend / SendGrid / Mailgun / Postmark)
// =====================================================================
export async function loadFirmProviderApiKey(firmId: string): Promise<string | null> {
  const { data } = await (supabaseAdmin as any)
    .from("firm_email_settings")
    .select("provider_api_key_cipher")
    .eq("firm_id", firmId)
    .maybeSingle();
  return decryptSecret(data?.provider_api_key_cipher ?? null);
}

export async function saveFirmProviderApiKey(firmId: string, plaintext: string | null): Promise<void> {
  const cipher = plaintext && plaintext.length > 0 ? encryptSecret(plaintext) : null;
  const { error } = await (supabaseAdmin as any)
    .from("firm_email_settings")
    .update({ provider_api_key_cipher: cipher })
    .eq("firm_id", firmId);
  if (error) throw new Error(error.message);
}

// =====================================================================
// Provider HTTP senders — fetch-only, work in serverless edge runtimes.
// =====================================================================
function fromHeader(senderName: string | null, senderEmail: string): string {
  return senderName ? `${senderName} <${senderEmail}>` : senderEmail;
}

export async function sendResendEmail(opts: {
  apiKey: string; from: string; to: string; subject: string; html: string; text?: string;
}): Promise<SendEmailResult> {
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${opts.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: opts.from, to: [opts.to], subject: opts.subject,
        html: opts.html, text: opts.text,
      }),
    });
    const json: any = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: json?.message || `Resend ${r.status}` };
    return { ok: true, messageId: json?.id ?? null };
  } catch (e: any) { return { ok: false, error: e?.message ?? String(e) }; }
}

export async function sendSendgridEmail(opts: {
  apiKey: string; senderName: string | null; senderEmail: string;
  to: string; subject: string; html: string; text?: string;
}): Promise<SendEmailResult> {
  try {
    const r = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: { Authorization: `Bearer ${opts.apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: opts.to }] }],
        from: { email: opts.senderEmail, name: opts.senderName ?? undefined },
        subject: opts.subject,
        content: [
          ...(opts.text ? [{ type: "text/plain", value: opts.text }] : []),
          { type: "text/html", value: opts.html },
        ],
      }),
    });
    if (!r.ok) {
      const txt = await r.text().catch(() => "");
      return { ok: false, error: `SendGrid ${r.status} ${txt.slice(0, 200)}` };
    }
    return { ok: true, messageId: r.headers.get("x-message-id") };
  } catch (e: any) { return { ok: false, error: e?.message ?? String(e) }; }
}

export async function sendMailgunEmail(opts: {
  apiKey: string; domain: string; from: string;
  to: string; subject: string; html: string; text?: string;
  region?: "us" | "eu";
}): Promise<SendEmailResult> {
  try {
    const base = opts.region === "eu" ? "https://api.eu.mailgun.net" : "https://api.mailgun.net";
    const body = new URLSearchParams();
    body.set("from", opts.from); body.set("to", opts.to);
    body.set("subject", opts.subject); body.set("html", opts.html);
    if (opts.text) body.set("text", opts.text);
    const r = await fetch(`${base}/v3/${encodeURIComponent(opts.domain)}/messages`, {
      method: "POST",
      headers: {
        Authorization: "Basic " + Buffer.from(`api:${opts.apiKey}`).toString("base64"),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: body.toString(),
    });
    const json: any = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: json?.message || `Mailgun ${r.status}` };
    return { ok: true, messageId: json?.id ?? null };
  } catch (e: any) { return { ok: false, error: e?.message ?? String(e) }; }
}

export async function sendPostmarkEmail(opts: {
  apiKey: string; from: string; to: string; subject: string; html: string; text?: string;
  messageStream?: string;
}): Promise<SendEmailResult> {
  try {
    const r = await fetch("https://api.postmarkapp.com/email", {
      method: "POST",
      headers: {
        "X-Postmark-Server-Token": opts.apiKey,
        Accept: "application/json", "Content-Type": "application/json",
      },
      body: JSON.stringify({
        From: opts.from, To: opts.to, Subject: opts.subject,
        HtmlBody: opts.html, TextBody: opts.text,
        MessageStream: opts.messageStream || "outbound",
      }),
    });
    const json: any = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: json?.Message || `Postmark ${r.status}` };
    return { ok: true, messageId: json?.MessageID ?? null };
  } catch (e: any) { return { ok: false, error: e?.message ?? String(e) }; }
}

// Unified provider dispatcher. Picks transport from settings row.
export async function sendViaProvider(opts: {
  row: any; firmId: string;
  to: string; subject: string; html: string; text?: string;
}): Promise<SendEmailResult> {
  const { row } = opts;
  const provider: EmailProvider = (row?.email_provider ?? "smtp") as EmailProvider;
  const senderEmail: string = row?.sender_email;
  const senderName: string | null = row?.sender_name ?? null;
  if (!senderEmail) return { ok: false, error: "Email expéditeur manquant" };
  const from = fromHeader(senderName, senderEmail);
  const cfg = (row?.provider_config ?? {}) as Record<string, any>;

  if (provider === "smtp") {
    if (!row?.smtp_host) return { ok: false, error: "SMTP non configuré" };
    // Prefer the standalone mail microservice when configured. SMTP TCP
    // connections from this serverless runtime are unreliable; the service
    // runs on a normal Node host (Railway/Render/VPS) and decrypts the
    // password with the shared APP_ENCRYPTION_KEY.
    if (isMailServiceConfigured()) {
      const cipher = await loadFirmSmtpPasswordCipher(opts.firmId);
      try {
        const r = await mailServiceSend({
          smtp: {
            host: row.smtp_host, port: row.smtp_port, secure: !!row.smtp_secure,
            username: row.smtp_username, password: cipher,
          },
          sender: { name: senderName, email: senderEmail },
          to: opts.to, subject: opts.subject, html: opts.html, text: opts.text,
          firmId: opts.firmId,
        });
        if (r.ok) return { ok: true, messageId: r.messageId ?? null };
        return { ok: false, error: r.error ?? "Échec mail service" };
      } catch (e: any) {
        return { ok: false, error: e?.message ?? "Mail service indisponible" };
      }
    }
    const password = await loadFirmSmtpPassword(opts.firmId);
    return sendSmtpEmail({
      settings: {
        sender_name: senderName, sender_email: senderEmail,
        smtp_host: row.smtp_host, smtp_port: row.smtp_port,
        smtp_username: row.smtp_username, smtp_secure: row.smtp_secure,
      },
      password, to: opts.to, subject: opts.subject, html: opts.html, text: opts.text,
    });
  }

  const apiKey = await loadFirmProviderApiKey(opts.firmId);
  if (!apiKey) return { ok: false, error: "Clé API du fournisseur d'email manquante" };

  if (provider === "resend") {
    return sendResendEmail({ apiKey, from, to: opts.to, subject: opts.subject, html: opts.html, text: opts.text });
  }
  if (provider === "sendgrid") {
    return sendSendgridEmail({ apiKey, senderName, senderEmail, to: opts.to, subject: opts.subject, html: opts.html, text: opts.text });
  }
  if (provider === "mailgun") {
    const domain = (cfg.mailgun_domain ?? "").toString().trim();
    if (!domain) return { ok: false, error: "Domaine Mailgun manquant" };
    const region = cfg.mailgun_region === "eu" ? "eu" : "us";
    return sendMailgunEmail({ apiKey, domain, region, from, to: opts.to, subject: opts.subject, html: opts.html, text: opts.text });
  }
  if (provider === "postmark") {
    return sendPostmarkEmail({ apiKey, from, to: opts.to, subject: opts.subject, html: opts.html, text: opts.text, messageStream: cfg.postmark_stream });
  }
  return { ok: false, error: `Fournisseur inconnu: ${provider}` };
}

// Lightweight verification — checks credentials by hitting a low-risk
// provider endpoint. For SMTP, defers to the existing nodemailer verify.
export async function verifyProviderConnection(opts: {
  row: any; firmId: string;
}): Promise<SendEmailResult> {
  const provider: EmailProvider = (opts.row?.email_provider ?? "smtp") as EmailProvider;
  if (provider === "smtp") {
    if (isMailServiceConfigured()) {
      const cipher = await loadFirmSmtpPasswordCipher(opts.firmId);
      try {
        const r = await mailServiceTestSmtp({
          host: opts.row?.smtp_host, port: opts.row?.smtp_port, secure: !!opts.row?.smtp_secure,
          username: opts.row?.smtp_username, password: cipher,
        });
        return r.ok ? { ok: true, messageId: null } : { ok: false, error: r.error ?? "Échec test SMTP" };
      } catch (e: any) {
        return { ok: false, error: e?.message ?? "Mail service indisponible" };
      }
    }
    const password = await loadFirmSmtpPassword(opts.firmId);
    return verifySmtpConnection({
      settings: {
        sender_name: opts.row?.sender_name ?? null, sender_email: opts.row?.sender_email,
        smtp_host: opts.row?.smtp_host, smtp_port: opts.row?.smtp_port,
        smtp_username: opts.row?.smtp_username, smtp_secure: opts.row?.smtp_secure,
      },
      password,
    });
  }
  const apiKey = await loadFirmProviderApiKey(opts.firmId);
  if (!apiKey) return { ok: false, error: "Clé API manquante" };
  try {
    if (provider === "resend") {
      const r = await fetch("https://api.resend.com/domains", {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      if (!r.ok && r.status !== 200) return { ok: false, error: `Resend ${r.status}` };
      return { ok: true, messageId: null };
    }
    if (provider === "sendgrid") {
      const r = await fetch("https://api.sendgrid.com/v3/scopes", {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      if (!r.ok) return { ok: false, error: `SendGrid ${r.status}` };
      return { ok: true, messageId: null };
    }
    if (provider === "mailgun") {
      const cfg = (opts.row?.provider_config ?? {}) as Record<string, any>;
      const domain = (cfg.mailgun_domain ?? "").toString().trim();
      if (!domain) return { ok: false, error: "Domaine Mailgun manquant" };
      const base = cfg.mailgun_region === "eu" ? "https://api.eu.mailgun.net" : "https://api.mailgun.net";
      const r = await fetch(`${base}/v3/domains/${encodeURIComponent(domain)}`, {
        headers: { Authorization: "Basic " + Buffer.from(`api:${apiKey}`).toString("base64") },
      });
      if (!r.ok) return { ok: false, error: `Mailgun ${r.status}` };
      return { ok: true, messageId: null };
    }
    if (provider === "postmark") {
      const r = await fetch("https://api.postmarkapp.com/server", {
        headers: { "X-Postmark-Server-Token": apiKey, Accept: "application/json" },
      });
      if (!r.ok) return { ok: false, error: `Postmark ${r.status}` };
      return { ok: true, messageId: null };
    }
    return { ok: false, error: `Fournisseur inconnu: ${provider}` };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? String(e) };
  }
}

export async function sendSmtpEmail(opts: {
  settings: SmtpSettings;
  password: string | null;
  to: string;
  subject: string;
  html: string;
  text?: string;
}): Promise<SendEmailResult> {
  try {
    // Dynamic import — nodemailer is Node-only and may fail to load in a
    // Worker runtime. Catching here lets us record a failed log entry
    // instead of crashing the whole request.
    const mod: any = await import("nodemailer");
    const nodemailer = mod.default ?? mod;
    const transport = nodemailer.createTransport({
      host: opts.settings.smtp_host,
      port: opts.settings.smtp_port,
      secure: opts.settings.smtp_secure,
      auth: opts.settings.smtp_username
        ? { user: opts.settings.smtp_username, pass: opts.password ?? "" }
        : undefined,
    });
    const from = opts.settings.sender_name
      ? `"${opts.settings.sender_name}" <${opts.settings.sender_email}>`
      : opts.settings.sender_email;
    const info = await transport.sendMail({
      from, to: opts.to, subject: opts.subject,
      html: opts.html, text: opts.text,
    });
    return { ok: true, messageId: info?.messageId ?? null };
  } catch (e: any) {
    const msg = e?.message ?? String(e);
    console.error("[emails] sendSmtpEmail failed", msg);
    return { ok: false, error: msg };
  }
}

export async function verifySmtpConnection(opts: {
  settings: SmtpSettings; password: string | null;
}): Promise<SendEmailResult> {
  try {
    const mod: any = await import("nodemailer");
    const nodemailer = mod.default ?? mod;
    const transport = nodemailer.createTransport({
      host: opts.settings.smtp_host,
      port: opts.settings.smtp_port,
      secure: opts.settings.smtp_secure,
      auth: opts.settings.smtp_username
        ? { user: opts.settings.smtp_username, pass: opts.password ?? "" }
        : undefined,
    });
    await transport.verify();
    return { ok: true, messageId: null };
  } catch (e: any) {
    const msg = e?.message ?? String(e);
    return { ok: false, error: msg };
  }
}

// Replace {{variable}} occurrences in a string from a flat data map.
export function renderTemplate(tpl: string, data: Record<string, string | null | undefined>): string {
  return tpl.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_m, key) => {
    const v = data[key];
    return v == null ? "" : String(v);
  });
}