import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { retrieveSignedDocumentInternal } from "./signatures.server";
import { sendTemplatedEmail } from "./emails.functions";
import { encryptSecret, decryptSecret, encryptConfigSecrets, decryptConfigSecrets } from "./crypto.server";

// =====================================================================
// Types & helpers
// =====================================================================
export type SignatureProvider = "yousign" | "docusign";

const providerSchema = z.enum(["yousign", "docusign"]);

const signerSchema = z.object({
  firstname: z.string().trim().min(1).max(100),
  lastname: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  signing_order: z.number().int().min(1).max(20).optional(),
});

async function assertFirmAccess(supabase: any, firmId: string, userId: string) {
  const { data, error } = await supabase.rpc("has_firm_access", {
    _firm_id: firmId, _user_id: userId,
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Accès refusé à ce cabinet");
}
async function assertFirmAdmin(supabase: any, firmId: string, userId: string) {
  const { data, error } = await supabase.rpc("has_firm_role", {
    _firm_id: firmId, _user_id: userId, _roles: ["owner", "admin"],
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Réservé aux administrateurs du cabinet");
}

async function loadCredentials(firmId: string, provider: SignatureProvider) {
  const { data } = await (supabaseAdmin as any)
    .from("firm_integration_secrets")
    .select("api_key, config")
    .eq("firm_id", firmId)
    .eq("provider", provider)
    .maybeSingle();
  if (!data) return null;
  const decryptedKey = data.api_key ? decryptSecret(data.api_key) : null;
  return {
    api_key: decryptedKey ?? data.api_key ?? null, // tolerate legacy plaintext during migration
    config: decryptConfigSecrets(data.config ?? {}),
  } as { api_key: string | null; config: any };
}

// Quick PDF page count (counts /Type /Page object headers, ignoring /Pages).
function pdfPageCount(bytes: Uint8Array): number {
  try {
    const text = new TextDecoder("latin1").decode(bytes);
    const m = text.match(/\/Type\s*\/Page(?!s)/g);
    return m ? m.length : 1;
  } catch { return 1; }
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

// =====================================================================
// Provider adapters — simulated mode keeps the workflow working without
// real API access; real calls can be plugged in later.
// =====================================================================
type AdapterSendInput = {
  apiKey: string | null;
  config: any;
  documentName: string;
  documentBytes: Uint8Array;
  signers: Array<{
    id: string; firstname: string; lastname: string; email: string;
    phone?: string | null; signing_order: number;
  }>;
  subject?: string | null;
  message?: string | null;
  signingOrderMode: "parallel" | "sequential";
};
type AdapterSendResult = {
  providerRequestId: string;
  signatureUrl: string | null;
  signers: Array<{ id: string; provider_signer_id: string }>;
  expiresAt: string | null;
  raw: any;
};
type ProviderAdapter = {
  name: SignatureProvider;
  testCredentials(input: { apiKey: string | null; config: any }): Promise<{ ok: true; info?: any }>;
  send(input: AdapterSendInput): Promise<AdapterSendResult>;
};

function isLiveMode(config: any): boolean {
  return config && (config.mode === "live" || config.mode === "production");
}

// ----- YouSign ------
const YOUSIGN_BASE = (config: any) =>
  isLiveMode(config) ? "https://api.yousign.app/v3" : "https://api-sandbox.yousign.app/v3";

const yousignAdapter: ProviderAdapter = {
  name: "yousign",
  async testCredentials({ apiKey, config }) {
    if (!apiKey) throw new Error("Clé API YouSign manquante");
    const res = await fetch(`${YOUSIGN_BASE(config)}/users?limit=1`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      console.error("[yousign] test failed", res.status, txt.slice(0, 200));
      if (res.status === 401 || res.status === 403) throw new Error("Clé API YouSign invalide");
      throw new Error(`Erreur YouSign (${res.status})`);
    }
    return { ok: true };
  },
  async send({ apiKey, config, documentName, documentBytes, signers, subject, message, signingOrderMode }) {
    if (!apiKey) throw new Error("Clé API YouSign manquante");
    const base = YOUSIGN_BASE(config);
    const auth = { Authorization: `Bearer ${apiKey}` } as Record<string, string>;

    // 1. Create signature request
    const createRes = await fetch(`${base}/signature_requests`, {
      method: "POST",
      headers: { ...auth, "content-type": "application/json" },
      body: JSON.stringify({
        name: subject || documentName,
        delivery_mode: "email",
        ordered_signers: signingOrderMode === "sequential",
        custom_experience_id: config?.custom_experience_id ?? undefined,
        external_id: config?.external_id ?? undefined,
        ...(message ? { custom_email: { signer: { subject: subject || documentName, content: message } } } : {}),
      }),
    });
    if (!createRes.ok) {
      const t = await createRes.text().catch(() => "");
      throw new Error(`YouSign create request: ${createRes.status} ${t.slice(0, 300)}`);
    }
    const reqJson: any = await createRes.json();
    const requestId: string = reqJson.id;

    // 2. Upload document
    const fd = new FormData();
    fd.append("nature", "signable_document");
    const fileName = documentName.toLowerCase().endsWith(".pdf") ? documentName : `${documentName}.pdf`;
    fd.append("file", new Blob([documentBytes as BlobPart], { type: "application/pdf" }), fileName);
    const upRes = await fetch(`${base}/signature_requests/${requestId}/documents`, {
      method: "POST", headers: auth, body: fd,
    });
    if (!upRes.ok) {
      const t = await upRes.text().catch(() => "");
      throw new Error(`YouSign upload document: ${upRes.status} ${t.slice(0, 300)}`);
    }
    const docJson: any = await upRes.json();
    const documentId: string = docJson.id;

    // 3. Add signers with a signature field on the last page
    const pageCount = pdfPageCount(documentBytes);
    const sigPage = Math.max(1, Number(config?.signature_page) || pageCount);
    const x = Number(config?.signature_x) || 80;
    const y = Number(config?.signature_y) || 80;
    const sigWidth = Number(config?.signature_width) || 180;
    const sigHeight = Number(config?.signature_height) || 60;

    const outSigners: Array<{ id: string; provider_signer_id: string }> = [];
    for (const s of signers) {
      const phone = s.phone?.trim();
      const signerRes = await fetch(`${base}/signature_requests/${requestId}/signers`, {
        method: "POST",
        headers: { ...auth, "content-type": "application/json" },
        body: JSON.stringify({
          info: {
            first_name: s.firstname,
            last_name: s.lastname,
            email: s.email,
            phone_number: phone || undefined,
            locale: config?.locale ?? "fr",
          },
          signature_level: config?.signature_level ?? "electronic_signature",
          signature_authentication_mode: phone && config?.sms_otp ? "otp_sms" : "no_otp",
          fields: [{
            type: "signature",
            document_id: documentId,
            page: sigPage,
            x, y, width: sigWidth, height: sigHeight,
          }],
        }),
      });
      if (!signerRes.ok) {
        const t = await signerRes.text().catch(() => "");
        throw new Error(`YouSign add signer: ${signerRes.status} ${t.slice(0, 300)}`);
      }
      const sj: any = await signerRes.json();
      outSigners.push({ id: s.id, provider_signer_id: sj.id });
    }

    // 4. Activate the signature request
    const actRes = await fetch(`${base}/signature_requests/${requestId}/activate`, {
      method: "POST", headers: auth,
    });
    if (!actRes.ok) {
      const t = await actRes.text().catch(() => "");
      throw new Error(`YouSign activate: ${actRes.status} ${t.slice(0, 300)}`);
    }
    const activated: any = await actRes.json().catch(() => ({}));
    const firstUrl = (activated?.signers?.[0]?.signature_link as string | undefined) ?? null;
    return {
      providerRequestId: requestId,
      signatureUrl: firstUrl,
      signers: outSigners,
      expiresAt: activated?.expiration_date ?? null,
      raw: { id: requestId, document_id: documentId, base },
    };
  },
};

// ----- DocuSign ------
const DOCUSIGN_BASE = (config: any) =>
  (config?.base_uri as string) ||
  (isLiveMode(config) ? "https://www.docusign.net/restapi" : "https://demo.docusign.net/restapi");

const docusignAdapter: ProviderAdapter = {
  name: "docusign",
  async testCredentials({ apiKey, config }) {
    if (!apiKey) throw new Error("Access token DocuSign manquant");
    if (!config?.account_id) throw new Error("Account ID DocuSign requis");
    const res = await fetch(
      `${DOCUSIGN_BASE(config)}/v2.1/accounts/${config.account_id}`,
      { headers: { Authorization: `Bearer ${apiKey}` } },
    );
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      console.error("[docusign] test failed", res.status, txt.slice(0, 200));
      if (res.status === 401 || res.status === 403) throw new Error("Identifiants DocuSign invalides");
      throw new Error(`Erreur DocuSign (${res.status})`);
    }
    return { ok: true };
  },
  async send({ apiKey, config, documentName, documentBytes, signers, subject, message, signingOrderMode }) {
    if (!apiKey) throw new Error("Access token DocuSign manquant");
    if (!config?.account_id) throw new Error("Account ID DocuSign requis");
    const base = `${DOCUSIGN_BASE(config)}/v2.1/accounts/${config.account_id}`;
    const auth = { Authorization: `Bearer ${apiKey}` } as Record<string, string>;

    const pageCount = pdfPageCount(documentBytes);
    const sigPage = Math.max(1, Number(config?.signature_page) || pageCount);
    const xPos = String(Number(config?.signature_x) || 100);
    const yPos = String(Number(config?.signature_y) || 600);

    const docB64 = bytesToBase64(documentBytes);
    const fileName = documentName.toLowerCase().endsWith(".pdf") ? documentName : `${documentName}.pdf`;

    const recipientSigners = signers.map((s, idx) => ({
      email: s.email,
      name: `${s.firstname} ${s.lastname}`.trim(),
      recipientId: String(idx + 1),
      routingOrder: signingOrderMode === "sequential" ? String(s.signing_order ?? idx + 1) : "1",
      tabs: {
        signHereTabs: [{
          documentId: "1",
          pageNumber: String(sigPage),
          xPosition: xPos,
          yPosition: yPos,
        }],
      },
    }));

    const envBody = {
      emailSubject: subject || documentName,
      emailBlurb: message ?? undefined,
      status: "sent",
      documents: [{
        documentBase64: docB64,
        name: fileName,
        fileExtension: "pdf",
        documentId: "1",
      }],
      recipients: { signers: recipientSigners },
    };

    const envRes = await fetch(`${base}/envelopes`, {
      method: "POST",
      headers: { ...auth, "content-type": "application/json" },
      body: JSON.stringify(envBody),
    });
    if (!envRes.ok) {
      const t = await envRes.text().catch(() => "");
      throw new Error(`DocuSign create envelope: ${envRes.status} ${t.slice(0, 300)}`);
    }
    const env: any = await envRes.json();
    const envelopeId: string = env.envelopeId;

    // Fetch recipients to capture provider signer IDs
    const outSigners = signers.map((s, idx) => ({ id: s.id, provider_signer_id: String(idx + 1) }));
    try {
      const recRes = await fetch(`${base}/envelopes/${envelopeId}/recipients`, { headers: auth });
      if (recRes.ok) {
        const r: any = await recRes.json();
        const list = (r?.signers ?? []) as any[];
        list.forEach((rec, idx) => {
          if (outSigners[idx]) outSigners[idx].provider_signer_id = String(rec.recipientId ?? idx + 1);
        });
      }
    } catch {}

    return {
      providerRequestId: envelopeId,
      signatureUrl: null,
      signers: outSigners,
      expiresAt: env?.expireDateTime ?? null,
      raw: { envelopeId, status: env.status, base },
    };
  },
};

const ADAPTERS: Record<SignatureProvider, ProviderAdapter> = {
  yousign: yousignAdapter,
  docusign: docusignAdapter,
};

// Simulated adapter — used when credentials are missing or mode === 'simulated'
async function simulatedSend(input: AdapterSendInput): Promise<AdapterSendResult> {
  const id = `sim_${Math.random().toString(36).slice(2, 12)}`;
  return {
    providerRequestId: id,
    signatureUrl: null,
    signers: input.signers.map((s) => ({ id: s.id, provider_signer_id: `sim_signer_${s.id.slice(0, 8)}` })),
    expiresAt: null,
    raw: { simulated: true, id },
  };
}

// =====================================================================
// Credentials management
// =====================================================================
export const setSignatureCredentials = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; provider: SignatureProvider; apiKey?: string; config?: Record<string, any> }) =>
    z.object({
      firmId: z.string().uuid(),
      provider: providerSchema,
      apiKey: z.string().min(2).max(8000).optional(),
      config: z.record(z.string(), z.any()).optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAdmin(supabase, data.firmId, userId);
    const config = data.config ?? {};
    // Validate the credentials before storing
    try {
      await ADAPTERS[data.provider].testCredentials({ apiKey: data.apiKey ?? null, config });
    } catch (e: any) {
      throw new Error(e?.message ?? "Validation échouée");
    }
    const { error } = await supabase.rpc("set_integration_credentials", {
      _firm_id: data.firmId,
      _provider: data.provider,
      _api_key: data.apiKey ? encryptSecret(data.apiKey) : null,
      _config: encryptConfigSecrets(config),
    });
    if (error) throw new Error(error.message);
    await supabase.rpc("touch_integration_test", {
      _firm_id: data.firmId, _provider: data.provider,
    });
    return { ok: true };
  });

export const clearSignatureCredentials = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; provider: SignatureProvider }) =>
    z.object({ firmId: z.string().uuid(), provider: providerSchema }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAdmin(supabase, data.firmId, userId);
    const { error } = await supabase.rpc("clear_integration_api_key", {
      _firm_id: data.firmId, _provider: data.provider,
    });
    if (error) throw new Error(error.message);
    await (supabaseAdmin as any).from("audit_logs").insert({
      firm_id: data.firmId, user_id: userId,
      action: "integration.credentials_cleared", entity_type: "integration",
      metadata: { provider: data.provider },
    });
    return { ok: true };
  });

export const testSignatureConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; provider: SignatureProvider }) =>
    z.object({ firmId: z.string().uuid(), provider: providerSchema }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAccess(supabase, data.firmId, userId);
    const creds = await loadCredentials(data.firmId, data.provider);
    if (!creds) throw new Error("Aucune configuration trouvée pour ce fournisseur");
    await ADAPTERS[data.provider].testCredentials({
      apiKey: creds.api_key, config: creds.config ?? {},
    });
    await supabase.rpc("touch_integration_test", {
      _firm_id: data.firmId, _provider: data.provider,
    });
    return { ok: true };
  });

export const getSignatureProviderStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; provider: SignatureProvider }) =>
    z.object({ firmId: z.string().uuid(), provider: providerSchema }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAccess(supabase, data.firmId, userId);
    const { data: row } = await (supabaseAdmin as any)
      .from("integrations")
      .select("status, connected_at")
      .eq("firm_id", data.firmId)
      .eq("provider", data.provider)
      .maybeSingle();
    const { data: secret } = await (supabaseAdmin as any)
      .from("firm_integration_secrets")
      .select("updated_at, last_test_at, config")
      .eq("firm_id", data.firmId)
      .eq("provider", data.provider)
      .maybeSingle();
    return {
      connected: !!secret && row?.status === "connected",
      connected_at: row?.connected_at ?? null,
      last_test_at: secret?.last_test_at ?? null,
      mode: (secret?.config?.mode as string) ?? "sandbox",
    };
  });

// =====================================================================
// Send for signature
// =====================================================================
export const sendForSignature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    documentId: string; provider: SignatureProvider;
    signers: Array<{ firstname: string; lastname: string; email: string; phone?: string; signing_order?: number }>;
    signingOrderMode?: "parallel" | "sequential";
    subject?: string; message?: string;
  }) => z.object({
    documentId: z.string().uuid(),
    provider: providerSchema,
    signers: z.array(signerSchema).min(1).max(10),
    signingOrderMode: z.enum(["parallel","sequential"]).optional(),
    subject: z.string().max(255).optional(),
    message: z.string().max(2000).optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;

    // Load document & verify access
    const { data: doc, error: dErr } = await supabase
      .from("generated_documents")
      .select("id, firm_id, company_id, name, file_path, docx_path, pdf_path, status")
      .eq("id", data.documentId)
      .single();
    if (dErr || !doc) throw new Error("Document introuvable");
    await assertFirmAccess(supabase, doc.firm_id, userId);
    if (doc.status === "signed") throw new Error("Ce document est déjà signé");

    // Resolve credentials & decide live vs simulated
    const creds = await loadCredentials(doc.firm_id, data.provider);
    const live = !!creds?.api_key;
    const mode = live ? "live" : "simulated";

    // Create the signature_request row
    const sigOrderMode = data.signingOrderMode ?? "parallel";
    const { data: req, error: reqErr } = await (supabaseAdmin as any)
      .from("signature_requests")
      .insert({
        firm_id: doc.firm_id,
        company_id: doc.company_id,
        generated_document_id: doc.id,
        provider: data.provider,
        mode,
        status: "draft",
        subject: data.subject ?? `Signature : ${doc.name}`,
        message: data.message ?? null,
        signing_order_mode: sigOrderMode,
        created_by: userId,
      })
      .select()
      .single();
    if (reqErr || !req) throw new Error(reqErr?.message ?? "Création de la demande échouée");

    const signerRows = data.signers.map((s, idx) => ({
      signature_request_id: req.id,
      firstname: s.firstname.trim(),
      lastname: s.lastname.trim(),
      email: s.email.trim().toLowerCase(),
      phone: s.phone?.trim() || null,
      signing_order: sigOrderMode === "sequential" ? (s.signing_order ?? idx + 1) : 1,
      status: "pending",
    }));
    const { data: insertedSigners, error: sErr } = await (supabaseAdmin as any)
      .from("signature_signers").insert(signerRows).select();
    if (sErr) throw new Error(sErr.message);

    // Attempt to send via provider; fall back to simulated on any error
    let sendResult: AdapterSendResult;
    let docBytes: Uint8Array | null = null;
    if (live) {
      const path = doc.pdf_path ?? doc.docx_path ?? doc.file_path;
      if (path) {
        const dl = await supabaseAdmin.storage.from("generated-docs").download(path);
        if (!dl.error && dl.data) docBytes = new Uint8Array(await dl.data.arrayBuffer());
      }
    }
    try {
      if (live && docBytes) {
        sendResult = await ADAPTERS[data.provider].send({
          apiKey: creds!.api_key, config: creds!.config ?? {},
          documentName: doc.name, documentBytes: docBytes,
          signers: (insertedSigners ?? []).map((s: any) => ({
            id: s.id, firstname: s.firstname, lastname: s.lastname,
            email: s.email, phone: s.phone, signing_order: s.signing_order,
          })),
          subject: data.subject ?? null,
          message: data.message ?? null,
          signingOrderMode: sigOrderMode,
        });
      } else {
        sendResult = await simulatedSend({
          apiKey: null, config: {},
          documentName: doc.name,
          documentBytes: docBytes ?? new Uint8Array(),
          signers: (insertedSigners ?? []).map((s: any) => ({
            id: s.id, firstname: s.firstname, lastname: s.lastname,
            email: s.email, phone: s.phone, signing_order: s.signing_order,
          })),
          subject: data.subject ?? null,
          message: data.message ?? null,
          signingOrderMode: sigOrderMode,
        });
      }
    } catch (e: any) {
      console.error("[signatures] provider send failed, falling back to simulated", e);
      sendResult = await simulatedSend({
        apiKey: null, config: {},
        documentName: doc.name,
        documentBytes: docBytes ?? new Uint8Array(),
        signers: (insertedSigners ?? []).map((s: any) => ({
          id: s.id, firstname: s.firstname, lastname: s.lastname,
          email: s.email, phone: s.phone, signing_order: s.signing_order,
        })),
        subject: data.subject ?? null,
        message: data.message ?? null,
        signingOrderMode: sigOrderMode,
      });
    }

    // Update request and signers with provider IDs
    const now = new Date().toISOString();
    await (supabaseAdmin as any)
      .from("signature_requests")
      .update({
        status: "sent",
        provider_request_id: sendResult.providerRequestId,
        signature_url: sendResult.signatureUrl,
        sent_at: now,
        expires_at: sendResult.expiresAt,
      })
      .eq("id", req.id);

    for (const s of sendResult.signers) {
      await (supabaseAdmin as any)
        .from("signature_signers")
        .update({ status: "sent", provider_signer_id: s.provider_signer_id })
        .eq("id", s.id);
    }
    await (supabaseAdmin as any).from("signature_events").insert({
      signature_request_id: req.id, provider: "system",
      event_type: "request.sent",
      payload: { mode, providerRequestId: sendResult.providerRequestId, raw: sendResult.raw },
    });

    // Update document status & audit log
    await (supabaseAdmin as any)
      .from("generated_documents")
      .update({ status: "sent" })
      .eq("id", doc.id);
    await (supabaseAdmin as any).from("audit_logs").insert({
      firm_id: doc.firm_id, user_id: userId,
      action: "signature.sent", entity_type: "generated_document", entity_id: doc.id,
      metadata: { provider: data.provider, mode, request_id: req.id, signers: signerRows.length },
    });

    // Fire firm-branded notification emails to each signer (best-effort).
    await sendSignatureEmails({
      firmId: doc.firm_id,
      companyId: doc.company_id,
      requestId: req.id,
      documentName: doc.name,
      templateKey: "signature_send",
      signers: (insertedSigners ?? []).map((s: any) => ({
        firstname: s.firstname, lastname: s.lastname, email: s.email,
      })),
      signatureUrl: sendResult.signatureUrl,
      expiresAt: sendResult.expiresAt,
      userId,
    });

    return { requestId: req.id, mode, signers: insertedSigners };
  });

// =====================================================================
// Reminder
// =====================================================================
export const sendSignatureReminder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { requestId: string }) =>
    z.object({ requestId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: r } = await supabase
      .from("signature_requests")
      .select("id, firm_id, company_id, status, signature_url, expires_at, generated_document_id, reminder_count")
      .eq("id", data.requestId).single();
    if (!r) throw new Error("Demande introuvable");
    await assertFirmAccess(supabase, r.firm_id, userId);
    if (!["sent", "viewed"].includes(r.status))
      throw new Error("Impossible d'envoyer un rappel sur cette demande");

    const { data: signers } = await supabase
      .from("signature_signers")
      .select("firstname, lastname, email, status")
      .eq("signature_request_id", r.id);
    const pending = (signers ?? []).filter((s: any) => !["signed", "refused"].includes(s.status));
    if (pending.length === 0) throw new Error("Tous les signataires ont déjà signé");

    const { data: doc } = r.generated_document_id
      ? await supabase.from("generated_documents").select("name").eq("id", r.generated_document_id).maybeSingle()
      : { data: null as any };

    await sendSignatureEmails({
      firmId: r.firm_id, companyId: r.company_id, requestId: r.id,
      documentName: doc?.name ?? "Document",
      templateKey: "signature_reminder",
      signers: pending,
      signatureUrl: r.signature_url,
      expiresAt: r.expires_at,
      userId,
    });

    const now = new Date().toISOString();
    await (supabaseAdmin as any)
      .from("signature_requests")
      .update({ reminder_count: (r.reminder_count ?? 0) + 1, last_reminder_at: now })
      .eq("id", r.id);
    await (supabaseAdmin as any).from("signature_events").insert({
      signature_request_id: r.id, provider: "system",
      event_type: "reminder.sent", payload: { user_id: userId, count: (r.reminder_count ?? 0) + 1 },
    });
    await (supabaseAdmin as any).from("audit_logs").insert({
      firm_id: r.firm_id, user_id: userId,
      action: "signature.reminder_sent", entity_type: "signature_request", entity_id: r.id,
      metadata: { signers: pending.length },
    });
    return { ok: true, sent: pending.length };
  });

// Internal helper used by sendForSignature and sendSignatureReminder.
async function sendSignatureEmails(args: {
  firmId: string; companyId: string; requestId: string;
  documentName: string;
  templateKey: "signature_send" | "signature_reminder";
  signers: Array<{ firstname: string; lastname: string; email: string }>;
  signatureUrl: string | null;
  expiresAt: string | null;
  userId: string;
}) {
  const { data: firm } = await (supabaseAdmin as any)
    .from("firms").select("name").eq("id", args.firmId).maybeSingle();
  const { data: company } = await (supabaseAdmin as any)
    .from("companies").select("name").eq("id", args.companyId).maybeSingle();
  const expiration = args.expiresAt
    ? new Date(args.expiresAt).toLocaleDateString("fr-FR")
    : "—";
  for (const s of args.signers) {
    try {
      await sendTemplatedEmail({
        firmId: args.firmId,
        templateKey: args.templateKey,
        to: s.email,
        companyId: args.companyId,
        signatureRequestId: args.requestId,
        userId: args.userId,
        variables: {
          firm_name: firm?.name ?? "",
          company_name: company?.name ?? "",
          signer_firstname: s.firstname,
          signer_lastname: s.lastname,
          document_name: args.documentName,
          signature_link: args.signatureUrl ?? "",
          expiration_date: expiration,
          portal_link: args.signatureUrl ?? "",
        },
      });
    } catch (e) {
      console.error("[signatures] email send failed", e);
    }
  }
}

// =====================================================================
// Listing & cancelling
// =====================================================================
export const listSignatureRequests = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { companyId: string }) =>
    z.object({ companyId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: c } = await supabase.from("companies").select("firm_id").eq("id", data.companyId).maybeSingle();
    if (!c) throw new Error("Entreprise introuvable");
    await assertFirmAccess(supabase, c.firm_id, userId);

    const { data: rows } = await supabase
      .from("signature_requests")
      .select("*")
      .eq("company_id", data.companyId)
      .order("created_at", { ascending: false });
    if (!rows) return { requests: [] };

    const ids = rows.map((r: any) => r.id);
    if (ids.length === 0) return { requests: [] };
    const [{ data: signers }, { data: events }] = await Promise.all([
      supabase.from("signature_signers").select("*").in("signature_request_id", ids),
      supabase.from("signature_events").select("*").in("signature_request_id", ids).order("created_at", { ascending: false }),
    ]);
    return {
      requests: rows.map((r: any) => ({
        ...r,
        signers: (signers ?? []).filter((s: any) => s.signature_request_id === r.id),
        events: (events ?? []).filter((e: any) => e.signature_request_id === r.id),
      })),
    };
  });

export const cancelSignatureRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { requestId: string }) =>
    z.object({ requestId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: r } = await supabase
      .from("signature_requests")
      .select("id, firm_id, status, generated_document_id")
      .eq("id", data.requestId).single();
    if (!r) throw new Error("Demande introuvable");
    await assertFirmAccess(supabase, r.firm_id, userId);
    if (["signed", "cancelled"].includes(r.status))
      throw new Error("Cette demande ne peut plus être annulée");

    await (supabaseAdmin as any)
      .from("signature_requests")
      .update({ status: "cancelled" })
      .eq("id", r.id);
    await (supabaseAdmin as any).from("signature_events").insert({
      signature_request_id: r.id, provider: "system",
      event_type: "request.cancelled", payload: { user_id: userId },
    });
    if (r.generated_document_id) {
      await (supabaseAdmin as any)
        .from("generated_documents").update({ status: "generated" })
        .eq("id", r.generated_document_id);
    }
    return { ok: true };
  });

// =====================================================================
// Signed document retrieval — wraps the server-only helper
// =====================================================================
export const retrieveSignedDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { requestId: string }) =>
    z.object({ requestId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: r } = await supabase
      .from("signature_requests").select("firm_id").eq("id", data.requestId).maybeSingle();
    if (!r) throw new Error("Demande introuvable");
    await assertFirmAccess(supabase, r.firm_id, userId);
    return retrieveSignedDocumentInternal(data.requestId);
  });

export const getSignedDocumentUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { requestId: string }) =>
    z.object({ requestId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: r } = await supabase
      .from("signature_requests")
      .select("firm_id, signed_document_path")
      .eq("id", data.requestId).maybeSingle();
    if (!r) throw new Error("Demande introuvable");
    await assertFirmAccess(supabase, r.firm_id, userId);
    let path = r.signed_document_path as string | null;
    if (!path) {
      const res = await retrieveSignedDocumentInternal(data.requestId);
      if (!res.ok || !res.path) throw new Error(res.reason ?? "Document signé indisponible");
      path = res.path;
    }
    const { data: signed, error } = await supabaseAdmin.storage
      .from("signed-documents").createSignedUrl(path, 60 * 10);
    if (error || !signed) throw new Error(error?.message ?? "URL indisponible");
    return { url: signed.signedUrl, path };
  });

// =====================================================================
// Simulator helper — advances a simulated signature for testing
// =====================================================================
export const simulateSignatureEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { requestId: string; status: "viewed" | "signed" | "refused" | "expired" }) =>
    z.object({
      requestId: z.string().uuid(),
      status: z.enum(["viewed", "signed", "refused", "expired"]),
    }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: r } = await supabase
      .from("signature_requests")
      .select("id, firm_id, mode, generated_document_id")
      .eq("id", data.requestId).single();
    if (!r) throw new Error("Demande introuvable");
    await assertFirmAccess(supabase, r.firm_id, userId);
    if (r.mode !== "simulated") throw new Error("Action disponible uniquement en mode simulé");

    const now = new Date().toISOString();
    const update: any = { status: data.status };
    if (data.status === "viewed") update.viewed_at = now;
    if (data.status === "signed") update.completed_at = now;
    await (supabaseAdmin as any).from("signature_requests").update(update).eq("id", r.id);

    if (data.status === "signed") {
      await (supabaseAdmin as any)
        .from("signature_signers")
        .update({ status: "signed", signed_at: now })
        .eq("signature_request_id", r.id);
      if (r.generated_document_id) {
        await (supabaseAdmin as any).from("generated_documents")
          .update({ status: "signed" }).eq("id", r.generated_document_id);
      }
    } else if (data.status === "refused" || data.status === "expired") {
      if (r.generated_document_id) {
        await (supabaseAdmin as any).from("generated_documents")
          .update({ status: data.status }).eq("id", r.generated_document_id);
      }
    }

    await (supabaseAdmin as any).from("signature_events").insert({
      signature_request_id: r.id, provider: "system",
      event_type: `simulated.${data.status}`, payload: { user_id: userId },
    });
    return { ok: true };
  });