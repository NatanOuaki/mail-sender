import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { decryptSecret, decryptConfigSecrets } from "./crypto.server";

function isLiveMode(config: any): boolean {
  return config && (config.mode === "live" || config.mode === "production");
}
const YOUSIGN_BASE = (config: any) =>
  isLiveMode(config) ? "https://api.yousign.app/v3" : "https://api-sandbox.yousign.app/v3";
const DOCUSIGN_BASE = (config: any) =>
  (config?.base_uri as string) ||
  (isLiveMode(config) ? "https://www.docusign.net/restapi" : "https://demo.docusign.net/restapi");

async function loadCredentials(firmId: string, provider: "yousign" | "docusign") {
  const { data } = await (supabaseAdmin as any)
    .from("firm_integration_secrets")
    .select("api_key, config")
    .eq("firm_id", firmId).eq("provider", provider).maybeSingle();
  if (!data) return null;
  const decryptedKey = data.api_key ? decryptSecret(data.api_key) : null;
  return {
    api_key: decryptedKey ?? data.api_key ?? null,
    config: decryptConfigSecrets(data.config ?? {}),
  } as { api_key: string | null; config: any };
}

async function downloadSignedFromYouSign(apiKey: string, config: any, requestId: string): Promise<Uint8Array> {
  const res = await fetch(`${YOUSIGN_BASE(config)}/signature_requests/${requestId}/documents/download?archive=false`, {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`YouSign download: ${res.status} ${t.slice(0, 200)}`);
  }
  return new Uint8Array(await res.arrayBuffer());
}

async function downloadSignedFromDocuSign(apiKey: string, config: any, envelopeId: string): Promise<Uint8Array> {
  const base = `${DOCUSIGN_BASE(config)}/v2.1/accounts/${config.account_id}`;
  const res = await fetch(`${base}/envelopes/${envelopeId}/documents/combined`, {
    headers: { Authorization: `Bearer ${apiKey}`, Accept: "application/pdf" },
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DocuSign download: ${res.status} ${t.slice(0, 200)}`);
  }
  return new Uint8Array(await res.arrayBuffer());
}

export async function retrieveSignedDocumentInternal(requestId: string): Promise<{
  ok: boolean; path?: string; reason?: string;
}> {
  const { data: r } = await (supabaseAdmin as any)
    .from("signature_requests")
    .select("id, firm_id, company_id, provider, provider_request_id, mode, signed_document_path, generated_document_id")
    .eq("id", requestId).maybeSingle();
  if (!r) return { ok: false, reason: "not_found" };
  if (r.signed_document_path) return { ok: true, path: r.signed_document_path };
  if (r.mode !== "live" || !r.provider_request_id) return { ok: false, reason: "not_live" };

  const creds = await loadCredentials(r.firm_id, r.provider);
  if (!creds?.api_key) return { ok: false, reason: "no_credentials" };

  let bytes: Uint8Array;
  try {
    bytes = r.provider === "yousign"
      ? await downloadSignedFromYouSign(creds.api_key, creds.config ?? {}, r.provider_request_id)
      : await downloadSignedFromDocuSign(creds.api_key, creds.config ?? {}, r.provider_request_id);
  } catch (e: any) {
    await (supabaseAdmin as any).from("signature_events").insert({
      signature_request_id: r.id, provider: r.provider,
      event_type: "download.error", payload: { error: String(e?.message ?? e) },
    });
    return { ok: false, reason: e?.message ?? "download_failed" };
  }

  const path = `${r.firm_id}/${r.company_id ?? "_"}/${r.id}.pdf`;
  const up = await supabaseAdmin.storage.from("signed-documents").upload(path, bytes as any, {
    contentType: "application/pdf", upsert: false,
  });
  if (up.error && !String(up.error.message).includes("exists")) {
    return { ok: false, reason: up.error.message };
  }
  await (supabaseAdmin as any).from("signature_requests")
    .update({ signed_document_path: path }).eq("id", r.id);
  await (supabaseAdmin as any).from("signature_events").insert({
    signature_request_id: r.id, provider: r.provider,
    event_type: "signed_document.retrieved", payload: { path },
  });
  await (supabaseAdmin as any).from("audit_logs").insert({
    firm_id: r.firm_id, action: "signature.signed_document_retrieved",
    entity_type: "signature_request", entity_id: r.id,
    metadata: { provider: r.provider, path },
  });
  return { ok: true, path };
}