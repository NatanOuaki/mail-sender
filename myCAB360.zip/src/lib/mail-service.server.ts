// Thin client for the standalone mail microservice.
// When MAIL_SERVICE_URL is configured, all SMTP traffic is routed there
// instead of being attempted from the Lovable serverless runtime.
import nodeCrypto from "node:crypto";
const { createHmac, randomBytes } = nodeCrypto;

function base64url(buf: Buffer): string {
  return buf.toString("base64").replace(/=+$/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function signServiceJwt(): string {
  const secret = process.env.MAIL_SERVICE_JWT_SECRET;
  if (!secret) throw new Error("MAIL_SERVICE_JWT_SECRET non configuré");
  const header = base64url(Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })));
  const now = Math.floor(Date.now() / 1000);
  const payload = base64url(Buffer.from(JSON.stringify({
    iss: "lovable-app", aud: "mail-service",
    iat: now, exp: now + 120, jti: randomBytes(8).toString("hex"),
  })));
  const sig = base64url(createHmac("sha256", secret).update(`${header}.${payload}`).digest());
  return `${header}.${payload}.${sig}`;
}

export function isMailServiceConfigured(): boolean {
  return !!(process.env.MAIL_SERVICE_URL && process.env.MAIL_SERVICE_JWT_SECRET);
}

async function call<T>(path: string, body: unknown): Promise<T> {
  const base = process.env.MAIL_SERVICE_URL!.replace(/\/+$/, "");
  const r = await fetch(`${base}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${signServiceJwt()}`,
    },
    body: JSON.stringify(body),
  });
  const json: any = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(json?.error || `mail service ${r.status}`);
  return json as T;
}

export type MailServiceSmtp = {
  host: string; port: number; secure: boolean;
  username: string | null; password: string | null;
};

export async function mailServiceTestSmtp(smtp: MailServiceSmtp) {
  return call<{ ok: boolean; error?: string }>("/test-smtp", { smtp });
}

export async function mailServiceSend(opts: {
  smtp: MailServiceSmtp;
  sender: { name: string | null; email: string };
  to: string; subject: string; html: string; text?: string;
  kind?: "transactional" | "signature" | "reminder" | "test";
  firmId?: string; templateKey?: string;
}) {
  const path = opts.kind === "reminder" ? "/send-reminder"
    : opts.kind === "signature" ? "/send-signature"
    : "/send-email";
  return call<{ ok: boolean; messageId?: string | null; error?: string }>(path, {
    smtp: opts.smtp,
    sender: opts.sender,
    to: opts.to, subject: opts.subject, html: opts.html, text: opts.text,
    context: { firm_id: opts.firmId, kind: opts.kind ?? "transactional", template_key: opts.templateKey },
  });
}