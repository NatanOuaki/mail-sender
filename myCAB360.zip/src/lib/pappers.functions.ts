import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { encryptSecret, decryptSecret } from "./crypto.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const PAPPERS_BASE = "https://api.pappers.fr/v2";

async function assertFirmAdmin(supabase: any, firmId: string, userId: string) {
  const { data, error } = await supabase.rpc("has_firm_role", {
    _firm_id: firmId,
    _user_id: userId,
    _roles: ["owner", "admin"],
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: owner or admin only");
}

async function assertFirmAccess(supabase: any, firmId: string, userId: string) {
  const { data, error } = await supabase.rpc("has_firm_access", {
    _firm_id: firmId,
    _user_id: userId,
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: not a firm member");
}

async function getApiKey(firmId: string): Promise<string> {
  const { data, error } = await (supabaseAdmin as any)
    .from("firm_integration_secrets" as any)
    .select("api_key")
    .eq("firm_id", firmId)
    .eq("provider", "pappers")
    .maybeSingle();
  if (error) throw new Error(error.message);
  const key = (data as any)?.api_key;
  if (!key) throw new Error("Pappers n'est pas connecté pour ce cabinet");
  const plaintext = decryptSecret(key as string) ?? (key as string); // tolerate legacy plaintext
  return plaintext;
}

// In-memory rate limit (best-effort): max 10 calls / 10s per firm
const rateBuckets = new Map<string, number[]>();
function rateLimit(firmId: string) {
  const now = Date.now();
  const arr = (rateBuckets.get(firmId) ?? []).filter((t) => now - t < 10_000);
  if (arr.length >= 10) throw new Error("Trop de requêtes Pappers, réessayez dans quelques secondes");
  arr.push(now);
  rateBuckets.set(firmId, arr);
}

async function pappersFetch(path: string, params: Record<string, string>, apiKey: string) {
  const url = new URL(PAPPERS_BASE + path);
  url.searchParams.set("api_token", apiKey);
  for (const [k, v] of Object.entries(params)) if (v) url.searchParams.set(k, v);
  const res = await fetch(url.toString(), { method: "GET" });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    console.error(`[pappers] ${path} ${res.status}: ${body.slice(0, 200)}`);
    if (res.status === 401 || res.status === 403) throw new Error("Clé API Pappers invalide");
    if (res.status === 404) throw new Error("Aucun résultat");
    if (res.status === 429) throw new Error("Limite de l'API Pappers atteinte");
    throw new Error(`Erreur Pappers (${res.status})`);
  }
  return res.json();
}

export const setPappersKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; apiKey: string }) =>
    z.object({ firmId: z.string().uuid(), apiKey: z.string().min(8).max(200) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertFirmAdmin(supabase, data.firmId, userId);
    // Test the key first
    try {
      await pappersFetch("/recherche", { q: "test", par_page: "1" }, data.apiKey);
    } catch (e: any) {
      throw new Error("Clé invalide : " + e.message);
    }
    const { error } = await supabase.rpc("set_integration_api_key", {
      _firm_id: data.firmId,
      _provider: "pappers",
      _api_key: encryptSecret(data.apiKey),
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const clearPappersKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string }) => z.object({ firmId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertFirmAdmin(supabase, data.firmId, userId);
    const { error } = await supabase.rpc("clear_integration_api_key", {
      _firm_id: data.firmId,
      _provider: "pappers",
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const testPappersConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string }) => z.object({ firmId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertFirmAccess(supabase, data.firmId, userId);
    rateLimit(data.firmId);
    const apiKey = await getApiKey(data.firmId);
    await pappersFetch("/recherche", { q: "test", par_page: "1" }, apiKey);
    await supabaseAdmin
      .from("integrations")
      .update({ last_sync_at: new Date().toISOString() })
      .eq("firm_id", data.firmId)
      .eq("provider", "pappers");
    return { ok: true };
  });

export const searchPappers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; query: string }) =>
    z.object({ firmId: z.string().uuid(), query: z.string().min(1).max(200) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertFirmAccess(supabase, data.firmId, userId);
    rateLimit(data.firmId);
    const apiKey = await getApiKey(data.firmId);
    const raw = data.query.trim();
    const digits = raw.replace(/[\s.\-]/g, "");
    const onlyDigits = /^\d+$/.test(digits) ? digits : "";

    // SIREN: 9 digits
    if (onlyDigits.length === 9) {
      console.log(`[pappers] search type=siren q=${onlyDigits}`);
      try {
        const c: any = await pappersFetch("/entreprise", { siren: onlyDigits }, apiKey);
        return { results: [mapEntrepriseToResult(c)] };
      } catch (e: any) {
        if (e.message === "Aucun résultat") return { results: [] };
        throw e;
      }
    }
    // SIRET: 14 digits → SIREN = first 9 digits
    if (onlyDigits.length === 14) {
      console.log(`[pappers] search type=siret q=${onlyDigits}`);
      const siren = onlyDigits.slice(0, 9);
      try {
        const c: any = await pappersFetch("/entreprise", { siret: onlyDigits }, apiKey);
        return { results: [mapEntrepriseToResult(c, onlyDigits)] };
      } catch {
        try {
          const c: any = await pappersFetch("/entreprise", { siren }, apiKey);
          return { results: [mapEntrepriseToResult(c, onlyDigits)] };
        } catch (e: any) {
          if (e.message === "Aucun résultat") return { results: [] };
          throw e;
        }
      }
    }
    // Name search
    console.log(`[pappers] search type=name q=${raw}`);
    const json: any = await pappersFetch("/recherche", { q: raw, par_page: "10" }, apiKey);
    const results = (json?.resultats ?? []).map((r: any) => ({
      siren: r.siren,
      siret: r.siege?.siret ?? r.siret ?? null,
      name: r.nom_entreprise || r.denomination || r.nom_complet || "",
      city: r.siege?.ville ?? r.ville ?? null,
      legal_form: r.forme_juridique ?? null,
      activity: r.libelle_code_naf ?? r.domaine_activite ?? null,
      status: r.statut_rcs ?? (r.entreprise_cessee ? "Cessée" : "Active"),
    }));
    return { results };
  });

function mapEntrepriseToResult(c: any, siretOverride?: string) {
  const siege = c?.siege ?? {};
  return {
    siren: c?.siren ?? null,
    siret: siretOverride ?? siege.siret ?? null,
    name: c?.nom_entreprise || c?.denomination || c?.nom_complet || "",
    city: siege.ville ?? c?.ville ?? null,
    legal_form: c?.forme_juridique ?? null,
    activity: c?.libelle_code_naf ?? c?.domaine_activite ?? null,
    status: c?.statut_rcs ?? (c?.entreprise_cessee ? "Cessée" : "Active"),
  };
}

export const getPappersCompany = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; siren: string }) =>
    z.object({ firmId: z.string().uuid(), siren: z.string().regex(/^\d{9}$/) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertFirmAccess(supabase, data.firmId, userId);
    rateLimit(data.firmId);
    const apiKey = await getApiKey(data.firmId);
    const c: any = await pappersFetch("/entreprise", { siren: data.siren }, apiKey);
    const siege = c.siege ?? {};
    const reps = (c.representants ?? []).map((r: any) => ({
      name: [r.prenom, r.nom].filter(Boolean).join(" ") || r.nom_complet || "",
      role: r.qualite ?? null,
    }));
    return {
      name: c.nom_entreprise || c.denomination || "",
      siren: c.siren,
      siret: siege.siret ?? null,
      address: [siege.numero_voie, siege.type_voie, siege.libelle_voie].filter(Boolean).join(" ") || siege.adresse_ligne_1 || null,
      postal_code: siege.code_postal ?? null,
      city: siege.ville ?? null,
      legal_form: c.forme_juridique ?? null,
      activity: c.libelle_code_naf ?? c.domaine_activite ?? null,
      creation_date: c.date_creation ?? null,
      share_capital: c.capital ?? null,
      vat_number: c.numero_tva_intracommunautaire ?? null,
      headcount: c.effectif ? parseInt(String(c.effectif).replace(/\D/g, ""), 10) || null : null,
      representatives: reps,
      status: c.statut_rcs ?? (c.entreprise_cessee ? "Cessée" : "Active"),
    };
  });

export const getPappersStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string }) => z.object({ firmId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertFirmAccess(supabase, data.firmId, userId);
    const { data: row } = await supabaseAdmin
      .from("integrations")
      .select("status, connected_at, last_sync_at")
      .eq("firm_id", data.firmId)
      .eq("provider", "pappers")
      .maybeSingle();
    const { data: secret } = await (supabaseAdmin as any)
      .from("firm_integration_secrets" as any)
      .select("updated_at")
      .eq("firm_id", data.firmId)
      .eq("provider", "pappers")
      .maybeSingle();
    return {
      connected: !!secret && row?.status === "connected",
      connected_at: row?.connected_at ?? null,
      last_sync_at: row?.last_sync_at ?? null,
    };
  });