import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

async function assertFirmAccess(supabase: any, firmId: string, userId: string) {
  const { data, error } = await supabase.rpc("has_firm_access", {
    _firm_id: firmId,
    _user_id: userId,
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Accès refusé à ce cabinet");
}

function extractVariablesFromBuffer(buf: ArrayBuffer): string[] {
  const zip = new PizZip(buf);
  const found = new Set<string>();
  // Scan all word/*.xml files for {{var}} patterns. Docxtemplater stores
  // tags split across runs in some cases — to detect them robustly we use
  // its parser to walk through the document.
  try {
    const doc = new Docxtemplater(zip, {
      paragraphLoop: true,
      linebreaks: true,
      delimiters: { start: "{{", end: "}}" },
    });
    const tags = (doc as any).getFullText
      ? []
      : [];
    // Use the official API to list placeholders.
    const placeholders = (doc as any).getTags?.() ?? {};
    const collect = (obj: any) => {
      if (!obj || typeof obj !== "object") return;
      for (const k of Object.keys(obj)) {
        found.add(k);
        collect(obj[k]);
      }
    };
    collect(placeholders);
    void tags;
  } catch {
    // Fall back to regex scan over xml entries
  }
  if (found.size === 0) {
    const re = /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g;
    for (const name of Object.keys(zip.files)) {
      if (!name.endsWith(".xml")) continue;
      const content = zip.files[name].asText();
      let m: RegExpExecArray | null;
      while ((m = re.exec(content)) !== null) found.add(m[1]);
    }
  }
  return Array.from(found);
}

export const extractTemplateVariables = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { templateId: string }) =>
    z.object({ templateId: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: tpl, error } = await supabase
      .from("document_templates")
      .select("id, firm_id, file_path, file_type")
      .eq("id", data.templateId)
      .single();
    if (error || !tpl) throw new Error("Modèle introuvable");
    await assertFirmAccess(supabase, tpl.firm_id, userId);
    if (tpl.file_type !== "docx" || !tpl.file_path) {
      return { variables: [] as string[] };
    }
    const dl = await supabaseAdmin.storage.from("templates").download(tpl.file_path);
    if (dl.error || !dl.data) throw new Error("Téléchargement du modèle impossible");
    const buf = await dl.data.arrayBuffer();
    let variables: string[] = [];
    try {
      variables = extractVariablesFromBuffer(buf);
    } catch (e) {
      console.error("[documents] extract failed", e);
      variables = [];
    }
    await (supabaseAdmin as any)
      .from("document_templates")
      .update({ variables })
      .eq("id", tpl.id);
    return { variables };
  });

function fmtDate(d?: string | null): string {
  if (!d) return "";
  try {
    return new Date(d).toLocaleDateString("fr-FR");
  } catch {
    return "";
  }
}

function buildVariableMap(opts: {
  firm: any;
  banking: any;
  company: any;
  contact: any;
}): Record<string, string> {
  const { firm, banking, company, contact } = opts;
  const today = new Date();
  const repFullName = [company?.rep_first_name, company?.rep_last_name].filter(Boolean).join(" ").trim()
    || [contact?.first_name, contact?.last_name].filter(Boolean).join(" ").trim();
  const map: Record<string, string> = {
    // Firm
    firm_name: firm?.name ?? "",
    firm_address: firm?.address ?? "",
    firm_city: firm?.city ?? "",
    firm_postal_code: firm?.postal_code ?? "",
    firm_email: firm?.email ?? "",
    firm_phone: firm?.phone ?? "",
    firm_siret: firm?.siret ?? "",
    firm_siren: firm?.siren ?? "",
    iban: banking?.iban ?? "",
    bic: banking?.bic ?? "",
    vat_number: company?.vat_number ?? firm?.vat_number ?? "",
    // Company
    company_name: company?.name ?? "",
    siren: company?.siren ?? "",
    siret: company?.siret ?? "",
    legal_form: company?.legal_form ?? "",
    activity: company?.activity ?? "",
    address: company?.address ?? "",
    city: company?.city ?? "",
    postal_code: company?.postal_code ?? "",
    fiscal_regime: company?.tax_regime ?? "",
    tax_regime: company?.tax_regime ?? "",
    vat_regime: company?.vat_regime ?? "",
    headcount: company?.headcount != null ? String(company.headcount) : "",
    share_capital: company?.share_capital != null ? String(company.share_capital) : "",
    naf_code: company?.naf_code ?? "",
    creation_date: fmtDate(company?.creation_date),
    // Legal representative (from company.rep_* or first contact)
    legal_firstname: company?.rep_first_name ?? contact?.first_name ?? "",
    legal_lastname: company?.rep_last_name ?? contact?.last_name ?? "",
    legal_email: company?.rep_email ?? contact?.email ?? "",
    legal_phone: company?.rep_phone ?? contact?.phone ?? "",
    client_firstname: company?.rep_first_name ?? contact?.first_name ?? "",
    client_lastname: company?.rep_last_name ?? contact?.last_name ?? "",
    // System
    today_date: today.toLocaleDateString("fr-FR"),
    current_year: String(today.getFullYear()),
    // ===== French LDM template aliases =====
    civilite: company?.rep_civility ?? "",
    legal_representative_civility: company?.rep_civility ?? "",
    representantlegal: repFullName,
    raisonsociale: company?.name ?? "",
    formejuridique: company?.legal_form ?? "",
    numerorcs: company?.siren ?? "",
    dateimmatriculation: fmtDate(company?.creation_date),
    company_creation_date: fmtDate(company?.creation_date),
    capital: company?.share_capital != null ? String(company.share_capital) : "",
    capital_social: company?.share_capital != null ? String(company.share_capital) : "",
    adresse1: company?.address ?? "",
    codepostal: company?.postal_code ?? "",
    ville: company?.city ?? "",
    activite: company?.activity ?? "",
    salarie: company?.headcount != null ? String(company.headcount) : "",
    regimefiscal: company?.tax_regime ?? "",
    regimeimposition: company?.vat_regime ?? "",
    // Mission / dates
    debutfacturation: fmtDate(company?.takeover_date) || today.toLocaleDateString("fr-FR"),
    mission_start_date: fmtDate(company?.takeover_date),
    datecloture: fmtDate(company?.first_closing_date),
    fiscal_year_end_date: fmtDate(company?.first_closing_date),
    dateLDM: fmtDate(company?.ldm_date) || today.toLocaleDateString("fr-FR"),
    ldm_date: fmtDate(company?.ldm_date),
    // Honoraires
    periodicite: company?.fees_periodicity ?? "",
    billing_frequency: company?.fees_periodicity ?? "",
    honorairescompta: company?.fees_accounting != null ? String(company.fees_accounting) : "",
    accounting_fees: company?.fees_accounting != null ? String(company.fees_accounting) : "",
    honorairesbilan: company?.fees_balance != null ? String(company.fees_balance) : "",
    balance_sheet_fees: company?.fees_balance != null ? String(company.fees_balance) : "",
    honorairesjuridique: company?.fees_legal != null ? String(company.fees_legal) : "",
    legal_fees: company?.fees_legal != null ? String(company.fees_legal) : "",
    nbBulletins: company?.payslips_count != null ? String(company.payslips_count) : "",
    payslip_count: company?.payslips_count != null ? String(company.payslips_count) : "",
    honorairesbs: company?.fees_payroll != null ? String(company.fees_payroll) : "",
    payslip_fees: company?.fees_payroll != null ? String(company.fees_payroll) : "",
    logicielDisposition: company?.software_provided ?? "",
    software_provided: company?.software_provided ?? "",
    honorairesLogiciel: company?.fees_software != null ? String(company.fees_software) : "",
    software_fees: company?.fees_software != null ? String(company.fees_software) : "",
    observations: company?.observations ?? "",
  };
  return map;
}

export const generateDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { templateId: string; companyId: string; name?: string; overrides?: Record<string, string> }) =>
    z
      .object({
        templateId: z.string().uuid(),
        companyId: z.string().uuid(),
        name: z.string().min(1).max(255).optional(),
        overrides: z.record(z.string(), z.string()).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;

    const { data: tpl, error: tErr } = await supabase
      .from("document_templates")
      .select("id, firm_id, name, file_path, file_type, variables")
      .eq("id", data.templateId)
      .single();
    if (tErr || !tpl) throw new Error("Modèle introuvable");
    await assertFirmAccess(supabase, tpl.firm_id, userId);

    const { data: company, error: cErr } = await supabase
      .from("companies")
      .select("*")
      .eq("id", data.companyId)
      .eq("firm_id", tpl.firm_id)
      .single();
    if (cErr || !company) throw new Error("Entreprise introuvable");

    const [{ data: firm }, { data: banking }, { data: contacts }] = await Promise.all([
      (supabaseAdmin as any).from("firms").select("*").eq("id", tpl.firm_id).maybeSingle(),
      (supabaseAdmin as any).from("firm_banking").select("*").eq("firm_id", tpl.firm_id).maybeSingle(),
      (supabaseAdmin as any)
        .from("contacts")
        .select("*")
        .eq("company_id", data.companyId)
        .order("created_at", { ascending: true })
        .limit(1),
    ]);
    const contact = Array.isArray(contacts) ? contacts[0] : null;

    if (tpl.file_type !== "docx" || !tpl.file_path) {
      throw new Error("Seuls les modèles DOCX peuvent être générés pour le moment");
    }

    const dl = await supabaseAdmin.storage.from("templates").download(tpl.file_path);
    if (dl.error || !dl.data) throw new Error("Téléchargement du modèle impossible");
    const buf = await dl.data.arrayBuffer();

    const baseMap = buildVariableMap({ firm, banking, company, contact });
    const map: Record<string, string> = { ...baseMap };
    if (data.overrides) {
      for (const [k, v] of Object.entries(data.overrides)) {
        if (typeof v === "string" && v.length > 0) map[k] = v;
      }
    }
    const zip = new PizZip(buf);

    let out: Uint8Array;
    try {
      const doc = new Docxtemplater(zip, {
        paragraphLoop: true,
        linebreaks: true,
        delimiters: { start: "{{", end: "}}" },
        // Never crash on missing variables – render placeholder.
        nullGetter(part: any) {
          const tag = part?.value ?? "";
          return `«${tag}»`;
        },
      });
      doc.render(map);
      out = doc.getZip().generate({ type: "uint8array" });
    } catch (e: any) {
      console.error("[documents] render failed", e?.properties ?? e);
      throw new Error("Erreur lors de la génération du document");
    }

    const safeName = (data.name || `${tpl.name} - ${company.name}`)
      .replace(/[^a-zA-Z0-9._\- ]/g, "_")
      .slice(0, 180);
    const baseName = safeName.replace(/\s+/g, "_");
    const folder = `${tpl.firm_id}/${data.companyId}/${Date.now()}-${baseName}`;
    const docxPath = `${folder}.docx`;

    const upload = await supabaseAdmin.storage.from("generated-docs").upload(docxPath, out, {
      contentType:
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      upsert: false,
    });
    if (upload.error) throw new Error(upload.error.message);

    // Try PDF conversion (non-fatal)
    let pdfPath: string | null = null;
    const pdfBytes = await convertDocxToPdf(out);
    if (pdfBytes) {
      pdfPath = `${folder}.pdf`;
      const pdfUp = await supabaseAdmin.storage.from("generated-docs").upload(pdfPath, pdfBytes, {
        contentType: "application/pdf",
        upsert: false,
      });
      if (pdfUp.error) {
        console.error("[documents] pdf upload failed", pdfUp.error);
        pdfPath = null;
      }
    }

    const ins = await (supabaseAdmin as any)
      .from("generated_documents")
      .insert({
        firm_id: tpl.firm_id,
        company_id: data.companyId,
        template_id: tpl.id,
        name: `${safeName}.docx`,
        file_path: docxPath,
        file_type: "docx",
        docx_path: docxPath,
        pdf_path: pdfPath,
        status: "generated",
        generated_by: userId,
      })
      .select()
      .single();
    if (ins.error) throw new Error(ins.error.message);

    const signed = await supabaseAdmin.storage
      .from("generated-docs")
      .createSignedUrl(pdfPath ?? docxPath, 60 * 5);

    return {
      document: ins.data,
      signedUrl: signed.data?.signedUrl ?? null,
      pdfReady: !!pdfPath,
      missingVariables: (Array.isArray(tpl.variables) ? tpl.variables : [])
        .filter((v: string) => !map[v] || map[v] === ""),
    };
  });

export const getDocumentSignedUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { documentId: string; kind?: "docx" | "pdf" }) =>
    z
      .object({
        documentId: z.string().uuid(),
        kind: z.enum(["docx", "pdf"]).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: doc, error } = await supabase
      .from("generated_documents")
      .select("id, firm_id, file_path, docx_path, pdf_path, template_id")
      .eq("id", data.documentId)
      .single();
    if (error || !doc) throw new Error("Document introuvable");
    await assertFirmAccess(supabase, doc.firm_id, userId);
    const path =
      data.kind === "pdf"
        ? doc.pdf_path
        : data.kind === "docx"
          ? doc.docx_path ?? doc.file_path
          : doc.docx_path ?? doc.file_path ?? doc.pdf_path;
    if (!path) throw new Error("Aucun fichier associé");
    const bucket = "generated-docs";
    const signed = await supabaseAdmin.storage
      .from(bucket)
      .createSignedUrl(path, 60 * 5);
    if (signed.error || !signed.data) throw new Error("Lien indisponible");
    return { signedUrl: signed.data.signedUrl };
  });

// =====================================================================
// PDF conversion via CloudConvert (sync API)
// =====================================================================
async function convertDocxToPdf(docxBytes: Uint8Array): Promise<Uint8Array | null> {
  const apiKey = process.env.CLOUDCONVERT_API_KEY;
  if (!apiKey) {
    console.warn("[documents] CLOUDCONVERT_API_KEY not set, skipping PDF conversion");
    return null;
  }
  try {
    // 1. Create job with import/upload → convert → export/url
    const createRes = await fetch("https://sync.api.cloudconvert.com/v2/jobs", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        tasks: {
          "import-1": { operation: "import/upload" },
          "convert-1": {
            operation: "convert",
            input: "import-1",
            input_format: "docx",
            output_format: "pdf",
            engine: "libreoffice",
          },
          "export-1": { operation: "export/url", input: "convert-1" },
        },
      }),
    });
    if (!createRes.ok) {
      console.error("[documents] CloudConvert create failed", createRes.status, await createRes.text());
      return null;
    }
    const createJson: any = await createRes.json();
    const job = createJson.data;
    const importTask = job.tasks.find((t: any) => t.name === "import-1");
    const upload = importTask?.result?.form;
    if (!upload?.url) {
      console.error("[documents] CloudConvert: no upload form");
      return null;
    }
    // 2. Upload DOCX bytes
    const fd = new FormData();
    for (const [k, v] of Object.entries(upload.parameters as Record<string, string>)) {
      fd.append(k, v);
    }
    fd.append(
      "file",
      new Blob([docxBytes as any], {
        type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      }),
      "input.docx",
    );
    const upRes = await fetch(upload.url, { method: "POST", body: fd });
    if (!upRes.ok && upRes.status !== 201 && upRes.status !== 204) {
      console.error("[documents] CloudConvert upload failed", upRes.status, await upRes.text());
      return null;
    }
    // 3. Wait for job to finish (sync endpoint)
    const waitRes = await fetch(`https://sync.api.cloudconvert.com/v2/jobs/${job.id}`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (!waitRes.ok) {
      console.error("[documents] CloudConvert wait failed", waitRes.status, await waitRes.text());
      return null;
    }
    const waitJson: any = await waitRes.json();
    const exportTask = waitJson.data.tasks.find((t: any) => t.name === "export-1");
    const fileUrl = exportTask?.result?.files?.[0]?.url;
    if (!fileUrl) {
      console.error("[documents] CloudConvert: no export url", waitJson.data.status);
      return null;
    }
    // 4. Download PDF
    const pdfRes = await fetch(fileUrl);
    if (!pdfRes.ok) {
      console.error("[documents] CloudConvert pdf download failed", pdfRes.status);
      return null;
    }
    return new Uint8Array(await pdfRes.arrayBuffer());
  } catch (e) {
    console.error("[documents] CloudConvert exception", e);
    return null;
  }
}

// =====================================================================
// History helpers
// =====================================================================
export const renameGeneratedDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { documentId: string; name: string }) =>
    z.object({ documentId: z.string().uuid(), name: z.string().min(1).max(255) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: doc, error } = await supabase
      .from("generated_documents")
      .select("id, firm_id")
      .eq("id", data.documentId)
      .single();
    if (error || !doc) throw new Error("Document introuvable");
    await assertFirmAccess(supabase, doc.firm_id, userId);
    const upd = await (supabaseAdmin as any)
      .from("generated_documents")
      .update({ name: data.name, updated_at: new Date().toISOString() })
      .eq("id", data.documentId);
    if (upd.error) throw new Error(upd.error.message);
    return { ok: true };
  });

export const setGeneratedDocumentStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { documentId: string; status: string }) =>
    z
      .object({
        documentId: z.string().uuid(),
        status: z.enum(["draft", "generated", "sent", "signed", "archived", "uploaded"]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { data: doc, error } = await supabase
      .from("generated_documents")
      .select("id, firm_id")
      .eq("id", data.documentId)
      .single();
    if (error || !doc) throw new Error("Document introuvable");
    await assertFirmAccess(supabase, doc.firm_id, userId);
    const upd = await (supabaseAdmin as any)
      .from("generated_documents")
      .update({ status: data.status, updated_at: new Date().toISOString() })
      .eq("id", data.documentId);
    if (upd.error) throw new Error(upd.error.message);
    return { ok: true };
  });