// Server-only secret encryption using AES-256-GCM with APP_ENCRYPTION_KEY.
// All ciphertexts are stored as strings of the form: enc:v1:<iv_b64>:<tag_b64>:<ct_b64>
import nodeCrypto from "node:crypto";
const { createCipheriv, createDecipheriv, createHash, randomBytes } = nodeCrypto;

const PREFIX = "enc:v1:";

function getKey(): Buffer {
  const raw = process.env.APP_ENCRYPTION_KEY;
  if (!raw || raw.trim().length < 8) {
    throw new Error(
      "APP_ENCRYPTION_KEY manquant — impossible de chiffrer/déchiffrer les secrets côté serveur.",
    );
  }
  // Derive a stable 32-byte key from the configured secret.
  return createHash("sha256").update(raw, "utf8").digest();
}

export function isCipherString(value: unknown): value is string {
  return typeof value === "string" && value.startsWith(PREFIX);
}

export function encryptSecret(plaintext: string): string {
  if (plaintext == null) throw new Error("encryptSecret: empty input");
  const key = getKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${PREFIX}${iv.toString("base64")}:${tag.toString("base64")}:${ct.toString("base64")}`;
}

export function decryptSecret(payload: string | null | undefined): string | null {
  if (!payload) return null;
  if (!isCipherString(payload)) {
    // Treat unknown values as legacy/plaintext that we cannot use safely.
    return null;
  }
  try {
    const parts = payload.slice(PREFIX.length).split(":");
    if (parts.length !== 3) return null;
    const [ivB64, tagB64, ctB64] = parts;
    const key = getKey();
    const iv = Buffer.from(ivB64, "base64");
    const tag = Buffer.from(tagB64, "base64");
    const ct = Buffer.from(ctB64, "base64");
    const decipher = createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
    return pt.toString("utf8");
  } catch (e: any) {
    console.error("[crypto] decryptSecret failed:", e?.message ?? e);
    return null;
  }
}

// Encrypt selected fields inside a config jsonb (currently webhook_secret).
// Mutates a copy of the input. Idempotent on already-encrypted values.
export function encryptConfigSecrets(config: Record<string, any> | null | undefined): Record<string, any> {
  const out: Record<string, any> = { ...(config ?? {}) };
  const ws = out.webhook_secret;
  if (typeof ws === "string" && ws.length > 0 && !isCipherString(ws)) {
    out.webhook_secret = encryptSecret(ws);
  }
  return out;
}

export function decryptConfigSecrets(config: Record<string, any> | null | undefined): Record<string, any> {
  const out: Record<string, any> = { ...(config ?? {}) };
  const ws = out.webhook_secret;
  if (typeof ws === "string" && isCipherString(ws)) {
    out.webhook_secret = decryptSecret(ws);
  }
  return out;
}