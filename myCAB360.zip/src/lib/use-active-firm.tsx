import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./use-auth";

export interface Firm {
  id: string;
  name: string;
  owner_id: string;
  logo_url: string | null;
  primary_color: string | null;
}

interface Ctx {
  firms: Firm[];
  activeFirm: Firm | null;
  setActiveFirmId: (id: string) => void;
  loading: boolean;
  refetch: () => void;
}

const ActiveFirmContext = createContext<Ctx>({
  firms: [], activeFirm: null, setActiveFirmId: () => {}, loading: true, refetch: () => {},
});

const STORAGE_KEY = "mycab360.activeFirmId";

export function ActiveFirmProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [activeFirmId, setActiveFirmIdState] = useState<string | null>(null);

  const { data: firms = [], isLoading, refetch } = useQuery({
    queryKey: ["firms", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("firms")
        .select("id,name,owner_id,logo_url,primary_color")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data as Firm[];
    },
  });

  useEffect(() => {
    if (!firms.length) return;
    const stored = typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null;
    if (stored && firms.some(f => f.id === stored)) {
      setActiveFirmIdState(stored);
    } else {
      setActiveFirmIdState(firms[0].id);
    }
  }, [firms]);

  const setActiveFirmId = (id: string) => {
    setActiveFirmIdState(id);
    if (typeof window !== "undefined") localStorage.setItem(STORAGE_KEY, id);
  };

  const activeFirm = firms.find(f => f.id === activeFirmId) ?? null;

  return (
    <ActiveFirmContext.Provider value={{ firms, activeFirm, setActiveFirmId, loading: isLoading, refetch }}>
      {children}
    </ActiveFirmContext.Provider>
  );
}

export const useActiveFirm = () => useContext(ActiveFirmContext);