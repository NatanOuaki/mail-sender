import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  renderTemplate, sendViaProvider, verifyProviderConnection,
} from "./emails.server";
import { saveFirmSmtpPassword, saveFirmProviderApiKey } from "./emails.server";

const TEMPLATE_KEYS = [
  "signature_send",
  "signature_reminder",
  "signature_completed",
  "signature_expired",
  "document_shared",
] as const;
export type EmailTemplateKey = typeof TEMPLATE_KEYS[number];

// =====================================================================
// Default templates — seeded on demand. Branded but minimal HTML.
// =====================================================================
const DEFAULT_TEMPLATES: Record<EmailTemplateKey, { subject: string; body_html: string; body_text: string }> = {
  signature_send: {
    subject: "Document à signer : {{document_name}}",
    body_html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px">
<h2 style="color:#111">Bonjour {{signer_firstname}},</h2>
<p>{{firm_name}} vous invite à signer le document <strong>{{document_name}}</strong> concernant {{company_name}}.</p>
<p style="margin:24px 0"><a href="{{signature_link}}" style="display:inline-block;background:#111;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none">Signer le document</a></p>
<p style="color:#666;font-size:13px">Date d'expiration : {{expiration_date}}</p>
<hr style="border:none;border-top:1px solid #eee;margin:24px 0"/>
<p style="color:#999;font-size:12px">Envoyé par {{firm_name}}</p>
</div>`,
    body_text: "Bonjour {{signer_firstname}},\n\n{{firm_name}} vous invite à signer le document \"{{document_name}}\" pour {{company_name}}.\n\nLien : {{signature_link}}\nExpiration : {{expiration_date}}",
  },
  signature_reminder: {
    subject: "Rappel : document à signer — {{document_name}}",
    body_html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px">
<h2 style="color:#111">Rappel — Bonjour {{signer_firstname}},</h2>
<p>Le document <strong>{{document_name}}</strong> est toujours en attente de votre signature.</p>
<p style="margin:24px 0"><a href="{{signature_link}}" style="display:inline-block;background:#111;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none">Signer maintenant</a></p>
<p style="color:#666;font-size:13px">Date limite : {{expiration_date}}</p>
<hr style="border:none;border-top:1px solid #eee;margin:24px 0"/>
<p style="color:#999;font-size:12px">{{firm_name}}</p>
</div>`,
    body_text: "Rappel : le document {{document_name}} est en attente de votre signature.\n\nLien : {{signature_link}}",
  },
  signature_completed: {
    subject: "Document signé : {{document_name}}",
    body_html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px">
<h2>Le document est signé ✓</h2>
<p>Le document <strong>{{document_name}}</strong> pour {{company_name}} a été signé par toutes les parties.</p>
<p><a href="{{portal_link}}">Accéder au document signé</a></p>
<p style="color:#999;font-size:12px">{{firm_name}}</p>
</div>`,
    body_text: "Le document {{document_name}} a été signé.\n\n{{portal_link}}",
  },
  signature_expired: {
    subject: "Document expiré : {{document_name}}",
    body_html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px">
<h2>Document expiré</h2>
<p>La demande de signature pour <strong>{{document_name}}</strong> a expiré.</p>
<p>Contactez {{firm_name}} pour relancer la procédure.</p>
</div>`,
    body_text: "La demande de signature pour {{document_name}} a expiré.",
  },
  document_shared: {
    subject: "Document partagé : {{document_name}}",
    body_html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px">
<h2>Bonjour {{signer_firstname}},</h2>
<p>{{firm_name}} a partagé un document avec vous : <strong>{{document_name}}</strong>.</p>
<p><a href="{{portal_link}}">Consulter</a></p>
</div>`,
    body_text: "{{firm_name}} a partagé : {{document_name}}\n{{portal_link}}",
  },
};

async function assertFirmAccess(supabase: any, firmId: string, userId: string) {
  const { data, error } = await supabase.rpc("has_firm_access", { _firm_id: firmId, _user_id: userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Accès refusé à ce cabinet");
}
async function assertFirmAdmin(supabase: any, firmId: string, userId: string) {
  const { data, error } = await supabase.rpc("has_firm_role", {
    _firm_id: firmId, _user_id: userId, _roles: ["owner", "admin"],
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Réservé aux administrateurs du cabinet");
}

// =====================================================================
// Settings
// =====================================================================
export const getEmailSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string }) =>
    z.object({ firmId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAccess(supabase, data.firmId, userId);
    const { data: row } = await supabase
      .from("firm_email_settings")
      .select("firm_id, sender_name, sender_email, smtp_host, smtp_port, smtp_username, smtp_secure, status, last_test_at, last_error, oauth_provider, native_provider_email_enabled, custom_firm_email_enabled, email_provider, provider_config")
      .eq("firm_id", data.firmId).maybeSingle();
    const flags = row ? await hasSecretsSet(data.firmId) : { hasPassword: false, hasApiKey: false };
    return { settings: row, hasPassword: flags.hasPassword, hasApiKey: flags.hasApiKey };
  });

async function hasSecretsSet(firmId: string): Promise<{ hasPassword: boolean; hasApiKey: boolean }> {
  const { data } = await (supabaseAdmin as any)
    .from("firm_email_settings")
    .select("smtp_password_cipher, provider_api_key_cipher")
    .eq("firm_id", firmId).maybeSingle();
  return {
    hasPassword: !!data?.smtp_password_cipher,
    hasApiKey: !!data?.provider_api_key_cipher,
  };
}

export const saveEmailSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    firmId: string;
    email_provider?: "smtp" | "resend" | "sendgrid" | "mailgun" | "postmark";
    sender_name?: string; sender_email: string;
    smtp_host?: string; smtp_port?: number; smtp_username?: string;
    smtp_password?: string; // optional (keep existing if missing)
    smtp_secure?: boolean;
    provider_api_key?: string; // optional (keep existing if missing)
    provider_config?: Record<string, any>;
    native_provider_email_enabled?: boolean;
    custom_firm_email_enabled?: boolean;
  }) => z.object({
    firmId: z.string().uuid(),
    email_provider: z.enum(["smtp","resend","sendgrid","mailgun","postmark"]).optional(),
    sender_name: z.string().trim().max(100).optional(),
    sender_email: z.string().trim().email().max(255),
    smtp_host: z.string().trim().max(255).optional(),
    smtp_port: z.number().int().min(1).max(65535).optional(),
    smtp_username: z.string().trim().max(255).optional(),
    smtp_password: z.string().max(500).optional(),
    smtp_secure: z.boolean().optional(),
    provider_api_key: z.string().max(500).optional(),
    provider_config: z.record(z.string(), z.any()).optional(),
    native_provider_email_enabled: z.boolean().optional(),
    custom_firm_email_enabled: z.boolean().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAdmin(supabase, data.firmId, userId);

    await (supabaseAdmin as any).from("firm_email_settings").upsert({
      firm_id: data.firmId,
      email_provider: data.email_provider ?? "smtp",
      sender_name: data.sender_name ?? null,
      sender_email: data.sender_email,
      smtp_host: data.smtp_host ?? null,
      smtp_port: data.smtp_port ?? null,
      smtp_username: data.smtp_username ?? null,
      smtp_secure: data.smtp_secure ?? true,
      provider_config: data.provider_config ?? {},
      native_provider_email_enabled: data.native_provider_email_enabled ?? true,
      custom_firm_email_enabled: data.custom_firm_email_enabled ?? true,
      status: "disconnected",
      updated_by: userId,
    }, { onConflict: "firm_id" });

    if (data.smtp_password !== undefined && data.smtp_password.length > 0) {
      try {
        await saveFirmSmtpPassword(data.firmId, data.smtp_password);
      } catch (e: any) {
        throw new Error(e?.message ?? "Échec du chiffrement du mot de passe SMTP");
      }
    }
    if (data.provider_api_key !== undefined && data.provider_api_key.length > 0) {
      try {
        await saveFirmProviderApiKey(data.firmId, data.provider_api_key);
      } catch (e: any) {
        throw new Error(e?.message ?? "Échec du chiffrement de la clé API");
      }
    }

    await (supabaseAdmin as any).from("audit_logs").insert({
      firm_id: data.firmId, user_id: userId,
      action: "email.settings_updated", entity_type: "firm_email_settings",
      metadata: {
        provider: data.email_provider ?? "smtp",
        host: data.smtp_host ?? null,
        sender_email: data.sender_email,
      },
    });
    return { ok: true };
  });

export const testEmailConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string }) =>
    z.object({ firmId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAdmin(supabase, data.firmId, userId);
    const { data: row } = await (supabaseAdmin as any)
      .from("firm_email_settings").select("*").eq("firm_id", data.firmId).maybeSingle();
    if (!row) throw new Error("Aucun paramètre email configuré");
    const res = await verifyProviderConnection({ row, firmId: data.firmId });
    await (supabaseAdmin as any).from("firm_email_settings").update({
      status: res.ok ? "connected" : "error",
      last_test_at: new Date().toISOString(),
      last_error: res.ok ? null : res.error,
    }).eq("firm_id", data.firmId);
    if (!res.ok) throw new Error(res.error);
    return { ok: true };
  });

export const sendTestEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; to: string }) =>
    z.object({ firmId: z.string().uuid(), to: z.string().trim().email() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAdmin(supabase, data.firmId, userId);
    const result = await sendInternal({
      firmId: data.firmId, to: data.to,
      subject: "Email de test — configuration validée",
      html: "<p>Cet email confirme que votre configuration d'envoi d'emails fonctionne.</p>",
      text: "Cet email confirme que votre configuration d'envoi d'emails fonctionne.",
      templateKey: null, companyId: null, signatureRequestId: null, userId,
    });
    if (!result.ok) throw new Error(result.error ?? "Envoi échoué");
    return { ok: true };
  });

// =====================================================================
// Templates
// =====================================================================
export const listEmailTemplates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string }) =>
    z.object({ firmId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAccess(supabase, data.firmId, userId);
    const { data: rows } = await supabase
      .from("firm_email_templates").select("*").eq("firm_id", data.firmId);
    const byKey = new Map((rows ?? []).map((r: any) => [r.template_key, r]));
    const all = TEMPLATE_KEYS.map((key) => {
      const r: any = byKey.get(key);
      if (r) return r;
      const def = DEFAULT_TEMPLATES[key];
      return {
        id: null, firm_id: data.firmId, template_key: key,
        subject: def.subject, body_html: def.body_html, body_text: def.body_text,
        enabled: true, _is_default: true,
      };
    });
    return { templates: all };
  });

export const saveEmailTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    firmId: string; templateKey: string;
    subject: string; body_html: string; body_text?: string; enabled?: boolean;
  }) => z.object({
    firmId: z.string().uuid(),
    templateKey: z.enum(TEMPLATE_KEYS),
    subject: z.string().trim().min(1).max(255),
    body_html: z.string().min(1).max(50000),
    body_text: z.string().max(20000).optional(),
    enabled: z.boolean().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAdmin(supabase, data.firmId, userId);
    await (supabaseAdmin as any).from("firm_email_templates").upsert({
      firm_id: data.firmId, template_key: data.templateKey,
      subject: data.subject, body_html: data.body_html, body_text: data.body_text ?? null,
      enabled: data.enabled ?? true, updated_by: userId,
    }, { onConflict: "firm_id,template_key" });
    return { ok: true };
  });

export const resetEmailTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; templateKey: string }) =>
    z.object({ firmId: z.string().uuid(), templateKey: z.enum(TEMPLATE_KEYS) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAdmin(supabase, data.firmId, userId);
    await (supabaseAdmin as any).from("firm_email_templates")
      .delete().eq("firm_id", data.firmId).eq("template_key", data.templateKey);
    return { ok: true };
  });

// =====================================================================
// Email logs
// =====================================================================
export const listEmailLogs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; companyId?: string; limit?: number }) =>
    z.object({
      firmId: z.string().uuid(),
      companyId: z.string().uuid().optional(),
      limit: z.number().int().min(1).max(200).optional(),
    }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAccess(supabase, data.firmId, userId);
    let q = supabase.from("email_logs").select("*").eq("firm_id", data.firmId)
      .order("created_at", { ascending: false }).limit(data.limit ?? 50);
    if (data.companyId) q = q.eq("company_id", data.companyId);
    const { data: rows } = await q;
    return { logs: rows ?? [] };
  });

// =====================================================================
// Internal send helper — used by sendTestEmail and from signatures.functions
// =====================================================================
export type InternalSendInput = {
  firmId: string;
  to: string;
  subject: string;
  html: string;
  text?: string;
  templateKey: EmailTemplateKey | null;
  companyId: string | null;
  signatureRequestId: string | null;
  userId: string;
};

export async function sendInternal(input: InternalSendInput): Promise<{ ok: boolean; error?: string; logId: string }> {
  // Insert queued log first.
  const { data: log } = await (supabaseAdmin as any).from("email_logs").insert({
    firm_id: input.firmId, company_id: input.companyId,
    signature_request_id: input.signatureRequestId,
    template_key: input.templateKey, recipient_email: input.to,
    subject: input.subject, status: "queued",
  }).select().single();

  const { data: row } = await (supabaseAdmin as any)
    .from("firm_email_settings").select("*").eq("firm_id", input.firmId).maybeSingle();

  const provider = (row?.email_provider ?? "smtp") as string;
  const missing = !row || !row.sender_email
    || (provider === "smtp" && !row.smtp_host);
  if (missing) {
    await (supabaseAdmin as any).from("email_logs").insert({
      firm_id: input.firmId, company_id: input.companyId,
      signature_request_id: input.signatureRequestId,
      template_key: input.templateKey, recipient_email: input.to,
      subject: input.subject, status: "skipped",
      error_message: "Email non configuré",
    });
    return { ok: false, error: "Email non configuré", logId: log?.id };
  }

  const res = await sendViaProvider({
    row, firmId: input.firmId,
    to: input.to, subject: input.subject, html: input.html, text: input.text,
  });

  await (supabaseAdmin as any).from("email_logs").insert({
    firm_id: input.firmId, company_id: input.companyId,
    signature_request_id: input.signatureRequestId,
    template_key: input.templateKey, recipient_email: input.to,
    subject: input.subject,
    status: res.ok ? "sent" : "failed",
    provider_message_id: res.ok ? res.messageId : null,
    error_message: res.ok ? null : res.error,
    sent_at: res.ok ? new Date().toISOString() : null,
  });

  return { ok: res.ok, error: res.ok ? undefined : res.error, logId: log?.id };
}

// Render+send a templated email. Loads firm template (or default fallback)
// and resolves variables. Used by signature flows.
export async function sendTemplatedEmail(input: {
  firmId: string;
  templateKey: EmailTemplateKey;
  to: string;
  variables: Record<string, string | null | undefined>;
  companyId: string | null;
  signatureRequestId: string | null;
  userId: string;
}): Promise<{ ok: boolean; error?: string }> {
  // Check feature flag — custom_firm_email_enabled at signature_request level
  const { data: settingsRow } = await (supabaseAdmin as any)
    .from("firm_email_settings").select("custom_firm_email_enabled").eq("firm_id", input.firmId).maybeSingle();
  if (settingsRow && settingsRow.custom_firm_email_enabled === false) {
    await (supabaseAdmin as any).from("email_logs").insert({
      firm_id: input.firmId, company_id: input.companyId,
      signature_request_id: input.signatureRequestId,
      template_key: input.templateKey, recipient_email: input.to,
      status: "skipped", error_message: "Emails personnalisés désactivés",
    });
    return { ok: false, error: "Emails personnalisés désactivés" };
  }

  const { data: tplRow } = await (supabaseAdmin as any)
    .from("firm_email_templates").select("*")
    .eq("firm_id", input.firmId).eq("template_key", input.templateKey).maybeSingle();
  const tpl = tplRow ?? DEFAULT_TEMPLATES[input.templateKey];
  if (tplRow && tplRow.enabled === false) {
    return { ok: false, error: "Modèle désactivé" };
  }

  const subject = renderTemplate(tpl.subject, input.variables);
  const html = renderTemplate(tpl.body_html, input.variables);
  const text = tpl.body_text ? renderTemplate(tpl.body_text, input.variables) : undefined;

  return sendInternal({
    firmId: input.firmId, to: input.to, subject, html, text,
    templateKey: input.templateKey,
    companyId: input.companyId,
    signatureRequestId: input.signatureRequestId,
    userId: input.userId,
  });
}

export const previewEmailTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { firmId: string; templateKey: string; variables?: Record<string, string> }) =>
    z.object({
      firmId: z.string().uuid(),
      templateKey: z.enum(TEMPLATE_KEYS),
      variables: z.record(z.string(), z.string()).optional(),
    }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    await assertFirmAccess(supabase, data.firmId, userId);
    const { data: tplRow } = await supabase
      .from("firm_email_templates").select("*")
      .eq("firm_id", data.firmId).eq("template_key", data.templateKey).maybeSingle();
    const tpl = tplRow ?? DEFAULT_TEMPLATES[data.templateKey as EmailTemplateKey];
    const vars = {
      firm_name: "Mon Cabinet",
      company_name: "Acme SAS",
      signer_firstname: "Jean",
      signer_lastname: "Dupont",
      document_name: "Lettre de mission 2026",
      signature_link: "https://example.com/sign/abc",
      expiration_date: "31/12/2026",
      portal_link: "https://example.com/portal",
      ...(data.variables ?? {}),
    };
    return {
      subject: renderTemplate(tpl.subject, vars),
      body_html: renderTemplate(tpl.body_html, vars),
      body_text: tpl.body_text ? renderTemplate(tpl.body_text, vars) : null,
    };
  });